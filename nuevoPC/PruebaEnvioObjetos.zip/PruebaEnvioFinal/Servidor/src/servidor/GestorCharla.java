package servidor;

import java.io.*;
import java.net.*;
import java.util.StringTokenizer;

/**
 * Clase que espera mensajes de los clientes, se crea un hilo por cada cliente
 * @author Manuel Domingo Mora Martinez, Francisco Javier Arellano Maule�n y Jes�s Pati�o G�mez
 * @version 2.0
 */

class GestorCharla
    extends Thread {

  /**
   * Clase para gestionar las salas
   */
  private GestorUsuarios gestorUsuarios;

  /**
   * Buffer de entrada
   */
  private BufferedReader in;


  /**
   * Stream de entrada
   */
  private ObjectInputStream in2;

  /**
   * Stream de salida
   */
  private ObjectOutputStream out,out2;

  /**
   * Sockets del cliente
   */
  private Socket alCliente, alCliente2;

  /**
   * Constructor de la clase
   * @param s Socket del cliente a crear
   * @param gestUsuarios Gestor de Usuarios
   */
  public GestorCharla (Socket s, Socket s2, GestorUsuarios gestUsuarios) {
    alCliente = s;
    alCliente2 = s2;
    gestorUsuarios = gestUsuarios;
  }

  /**
   * Metodo run de la superclase Thread con el que en un hilo aparte de ejecucion espero mensajes de los clientes
   */
  public void run() {
    try {
      // Crea los flujos de entrada y salida por medio de los
      // sockets que se obtuvo cuando se creo el gestor
      // Da la bienvenida

      in = new BufferedReader(new InputStreamReader(alCliente.getInputStream()));
      out = new ObjectOutputStream(alCliente.getOutputStream());
      in2 = new ObjectInputStream(alCliente2.getInputStream());
      out2 = new ObjectOutputStream(alCliente2.getOutputStream());
      //Envia todos los usuarios
      out.writeObject(gestorUsuarios.getUsuarios());
      out.flush();
      // Lee lineas y las envia para su difusion
      while (true)  {

        String s = in.readLine().trim();

        //Se recibe un objeto y se envia al destinatario
        if (s.charAt(0) == 'T' && s.charAt(1) == 'O')
        {
          Object s2 = in2.readObject();
          Servidor.difusion(s);
          out2.writeObject(s2);
          out2.flush();
        }


        // Desconecto un cliente
        if (s.charAt(0) == 'D' && s.charAt(1) == 'I') {
          gestorUsuarios.removeUser(s.substring(2));
          Servidor.difusion(s);
          break;
        }

        //Creo nuevo usuario
        if (s.charAt(0) == 'N' && s.charAt(1) == 'U') {
          StringTokenizer st = new StringTokenizer(s.substring(2), "#");
          String nomUsuario = st.nextToken();
          gestorUsuarios.addUser(nomUsuario);
          Servidor.difusion(s);
        }

        //Envia mensaje a todos los usuarios
        if (s.charAt(0) == 'N' && s.charAt(1) == 'M') {
          Servidor.difusion(s);
        }

        //Borra el nick del usuario que cierra su conversaci�n
        if (s.charAt(0) == 'D' && s.charAt(1) == 'U') {
          StringTokenizer st = new StringTokenizer(s.substring(2), "#");
          String nomUsuario = st.nextToken();
          gestorUsuarios.removeUser(nomUsuario);
          Servidor.difusion(s);
        }

        //Crea una nueva ventana de conversaci�n privada
        if (s.charAt(0) == 'N' && s.charAt(1) == 'P') {
          Servidor.difusion(s);
        }

        //Desactiva la conversaci�n privada correspondiente
        if (s.charAt(0) == 'D' && s.charAt(1) == 'P') {
          Servidor.difusion(s);
        }

        //Envia un mensaje privado al usuario correspondiente
        if (s.charAt(0) == 'M' && s.charAt(1) == 'P') {
          Servidor.difusion(s);
        }

      }
      Servidor.eliminar(alCliente);
      alCliente2.close();
      alCliente.close();
    }
    catch (Exception e) {
      System.out.println("Error del gestor de charla: " + e);
    }
  }

}
