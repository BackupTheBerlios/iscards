package carta;


/**
 * <p>T�tulo: GENESIS</p>
 * <p>Descripci�n: Clase abstracta que extenderan todos los objetos de tipo carta</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Empresa: </p>
 * @author Tony
 * @version 1.0
 */

//****************************************************************************************************//
//****************************************************************************************************//
//*************************************HAY QUE QUITARLA***********************************************//
//****************************************************************************************************//
//****************************************************************************************************//

public class CMana extends CACarta {

  /**
   *
   */
  private int cantidadM;

  /**
   * Constructora de la clase de Carta Mana
   * @param niv
   * @param cost
   * @param punt
   * @param cod
   * @param nom
   * @param idR
   * @param idT
   * @param coment
   * @param hab
   */
  public CMana(int niv, int cost, int punt, String cod, String nom, String idR, String idT, String coment, String hab){

    nivel=niv;
    coste=cost;
    puntos=punt;
    codigo=cod;
    nombre=nom;
    idRaza=idR;
    idTipo=idT;
    comentarios=coment;
    habilidades=hab;
//    estado=true;
  }


  /** Creates a new instance of CMana */
  public void  CMana(int poder) {
    cantidadM = poder;
  }

  /**
   *
   * @return
   */
  public int getMana(){
    return cantidadM;
  }

  /**
   *
   */
  public void setMana(int m){

  }

  /**
   *
   * @return
   */
  public boolean ejecuta() { //propiedades especiales si las tiene �?
//    estado = !estado;
    return false;
  }
}
