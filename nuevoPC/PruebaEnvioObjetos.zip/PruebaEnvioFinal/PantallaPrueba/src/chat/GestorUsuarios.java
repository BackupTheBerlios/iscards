package chat;

import java.util.Vector;

/*
 * <p>T�tulo: GENESIS</p>
 * <p>Descripci�n: Clase del Gestor de Usuarios</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Empresa: </p>
 * @author Manuel Domingo Mora Martinez, Francisco Javier Arellano Maule�n y Jes�s Pati�o G�mez
 * @version 1.0
 */
public class GestorUsuarios
{
        /**
        * Vector de usuarios registrados en el chat
        * antes de conectarme, no tienen porque estar en una sala
        */
        private Vector usersConectados = new Vector();

        /**
        * Procedimiento para asignar el vector de usuarios
        * @param uReg Vector de usuarios registrados
        */
        public void setVectorUsuarios(Vector uReg)
        {
                usersConectados=uReg;
        }

        /**
        * Funcion para registrar un usuario
        * @param nick Nombre del usuario
        * @return boolean Verdadero si el usuario ha sido registrado
        */
        public boolean registrarUser(String nick)
        {
                if(!usersConectados.contains(nick))
                {
                        usersConectados.add(nick);
                        return true;
                }
                return false;
        }

        /**
         * Funcion para comprobar que un usuario esta conectado
         * @param nick Nombre del usuario
         * @return boolean Verdadero si el usuario esta conectado
         */
        public boolean existeUser(String nick) {
          if (usersConectados.contains(nick))
            return true;
          else
            return false;
        }

        /**
        * Funcion para obtener el vector de usuarios
        * @return Vector de usuarios registrados
        */
        public Vector getUsers()
        {
                return usersConectados;
        }

        /**
        * Borra el nick de la sala especificada
        * @param n Nick a borrar
        */
        public synchronized void removeUser(String n)
        {
                usersConectados.remove(n);
        }

}
