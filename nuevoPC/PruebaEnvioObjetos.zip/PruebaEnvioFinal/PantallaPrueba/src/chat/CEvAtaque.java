package chat;

import java.io.*;

/**
 * Clase evento de ataque, implementa la interfaz IEvento y Serializable
 * @author Francisco Javier Arellano Maule�n y Jes�s Pati�o G�mez
 * @version 1.0
 */

public class CEvAtaque implements IEvento, Serializable
{
  /**
   * Identidad de la victima
   */
  private int idVictima;

  /**
   * Potencia del ataque
   */
  private int potencia;

  /**
   * Constructor de la clase
   * @param id Identidad de la victima
   * @param pot Potencia del ataque
   */
  public CEvAtaque(int id, int pot)
  {
    idVictima=id;
    potencia=pot;
  }

  /**
  * Funcion que me devuelve la identidad de la victima
  * @return int Id de la victima
  */
  public int getId()
  {
    return idVictima;
  }
}
