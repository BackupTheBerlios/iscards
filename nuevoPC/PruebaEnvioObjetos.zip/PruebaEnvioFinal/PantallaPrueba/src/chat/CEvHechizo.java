package chat;

import java.io.*;

/**
 * Clase evento hechizo, implementa la interfaz IEvento y Serializable
 * @author Francisco Javier Arellano Maule�n y Jes�s Pati�o G�mez
 * @version 1.0
 */

public class CEvHechizo implements IEvento, Serializable
{

  /**
   * Identidad de la victima
   */
  private int idHechizo;

  /**
   * Constructor de la clase
   * @param id Identidad de la victima
   */
  public CEvHechizo(int id)
  {
    idHechizo=id;
  }

  /**
  * Funcion que me devuelve la identidad de la victima
  * @return int Id de la victima
  */
  public int getId()
  {
    return idHechizo;
  }
}
