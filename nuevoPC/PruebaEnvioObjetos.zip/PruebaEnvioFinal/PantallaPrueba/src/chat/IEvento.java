package chat;

/**
 * Interface IEvento para poder implementar los eventos de comunicaci�n
 * @author Francisco Javier Arellano Maule�n y Jes�s Pati�o G�mez
 * @version 1.0
 */

public interface IEvento
{

  /**
  * Funcion que me devuelve la identidad de la victima
  * @return int Id de la victima
  */
  public int getId();
}
