package chat;

import java.io.*;

/**
 * Clase evento convocaci�n, implementa la interfaz IEvento y Serializable
 * @author Francisco Javier Arellano Maule�n y Jes�s Pati�o G�mez
 * @version 1.0
 */

public class CEvConvocacion implements IEvento, Serializable
{

  /**
   * Identidad de la victima
   */
  private int idCriatura;

  /**
   * Constructor de la clase
   * @param id Identidad de la victima
   */
  public CEvConvocacion(int id)
  {
    idCriatura=id;
  }

  /**
  * Funcion que me devuelve la identidad de la victima
  * @return int Id de la victima
  */
  public int getId()
  {
    return idCriatura;
  }

}
