package chat;

import coleccion.*;
import configuracion.*;

import java.io.*;
import java.util.*;
import javax.swing.*;

/**
 *
 * <p>T�tulo: GENESIS</p>
 * <p>Descripci�n: </p>
 * <p>Copyright: Copyright (c) 2005</p>
 * <p>Empresa: </p>
 * @author Manuel Domingo Mora Martinez, Jes�s Pati�o G�mez y Francisco Javier Arellano Maule�n
 * @version 2.0
 */
public class Comunicacion
    extends Thread {

  private Coleccion coleccion;

  /**
   * Ventana principal del programa
   */
  private VentanaPrincipal ventPrinc;

  /**
   * Ventana padre
   */
  private JFrame ventPadre;

  /**
   * Controlador del programa
   */
  private Controlador controlador;

  /**
   * Constructor de la clase comunicacion, la cual espera mensajes del servidor
   * @param controler Le inserto el controlador del programa
   * @param vPrinc Le inserto la ventana principal del programa
   */
  public Comunicacion(Controlador controler, VentanaPrincipal vPrinc) {
    ventPrinc = vPrinc;
    controlador = controler;
  }

  /**
   * Metodo run de la superclase Thread con el que en un hilo aparte de ejecucion espero mensajes del servidor
   */
  public void run() {
    try {
      GestorUsuarios gestorUsuarios = controlador.getGestorUsuarios();
      String user, s, nomUsuario, mensaje = null;
      StringTokenizer st;
      BufferedReader in = new BufferedReader(new InputStreamReader( (
          controlador.getSocket()).getInputStream()));
      ObjectInputStream in2 = new ObjectInputStream((controlador.getSocket2()).getInputStream());
      // Lee lineas y las envia para su difusion
      user = ventPrinc.getNick();
      while (true) {
        s = in.readLine().trim();

        //Se recibe un objeto
        if (s.charAt(0) == 'T' && s.charAt(1) == 'O') {
          //Object s2 = in2.readObject();
          Object p=in2.readObject();
          CEvAtaque evAtaque = null;
          CEvConvocacion evConvocacion = null;
          CEvHechizo evHechizo = null;
          //Si es un ataque
          if (p instanceof CEvAtaque)
          {
            evAtaque = (CEvAtaque)p;
            System.out.println("Has recibido un movimiento de la carta 1 - evento ataque con id: "+evAtaque.getId());
            JOptionPane.showMessageDialog(null, "Evento ataque con id: "+evAtaque.getId(),
                              "Has recibido un movimiento de la carta 1",
                              JOptionPane.INFORMATION_MESSAGE);
          }else
          //Si es una convocacion
          if (p instanceof CEvConvocacion)
          {
            evConvocacion = (CEvConvocacion)p;
            System.out.println("Has recibido un movimiento de la carta 3 - evento convocacion con id: " + evConvocacion.getId());
            JOptionPane.showMessageDialog(null, "Evento convocacion con id: "+evConvocacion.getId(),
                              "Has recibido un movimiento de la carta 3",
                              JOptionPane.INFORMATION_MESSAGE);
          }else
          //Si es un hechizo
          if (p instanceof CEvHechizo)
          {
            evHechizo = (CEvHechizo) p;
            System.out.println("Has recibido un movimiento de la carta 2 - evento hechizo con id:  " + evHechizo.getId());
            JOptionPane.showMessageDialog(null, "Evento hechizo con id: "+evHechizo.getId(),
                              "Has recibido un movimiento de la carta 2",
                              JOptionPane.INFORMATION_MESSAGE);
          }
        }


        //Creo nuevo usuario
        if (s.charAt(0) == 'N' && s.charAt(1) == 'U') {
          st = new StringTokenizer(s.substring(2), "#");
          nomUsuario = st.nextToken();
          gestorUsuarios.registrarUser(nomUsuario);
          ventPrinc.ActualizarListaUsuarios();
        }

        //Elimino un usuario
        if (s.charAt(0) == 'D' && s.charAt(1) == 'U') {
          st = new StringTokenizer(s.substring(2), "#");
          nomUsuario = st.nextToken();
          gestorUsuarios.removeUser(nomUsuario);
          ventPrinc.ActualizarListaUsuarios();
          //String nomUsuarioPrivado=user;
          //En caso de que el usuario que se elimina estuviese hablando con
          //nosotros nos informa de que ha abandonado la comunicaci�n.
          controlador.removePrivado(nomUsuario);
          ArrayList vprivadas = controlador.getPrivados();
          VentanaPrivada vPAux;
          for (int i = 0; i < vprivadas.size(); i++) {
            vPAux = (VentanaPrivada) vprivadas.get(i);
            if ((nomUsuario.equals(vPAux.getNameOtherUser()))
                /*&& (nomUsuarioPrivado.equals(vPAux.getNameUser()))*/) {
              vPAux.addMensaje("Administrador: El usuario " + nomUsuario +
                               " ha abandonado la conversaci�n.");
            }
          }
        }


        //Crea las correspondientes ventanas de conversaci�n privada
        if (s.charAt(0) == 'N' && s.charAt(1) == 'P') {
          st = new StringTokenizer(s.substring(2), "#");
          nomUsuario = st.nextToken();
          String nomUsuarioPrivado = st.nextToken();//Si el nombre del usuario q establece la comunicaci�n
          //o el nombre del usuario con el que se quiere conectar coinciden con el nick de este cliente
          //se abre una nueva ventana de conversaci�n privada
          if (nomUsuario.equals(user)) {
            VentanaPrivada vPrivada1 = new VentanaPrivada(nomUsuario,
                nomUsuarioPrivado, controlador);
           controlador.addPrivado(vPrivada1);
           configuracionImp config1=new configuracionImp(ventPrinc.getVentanaPadre(), coleccion,controlador);
           config1.show();
          }
          if (nomUsuarioPrivado.equals(user)) {
            VentanaPrivada vPrivada2 = new VentanaPrivada(nomUsuarioPrivado,
                nomUsuario, controlador);
            controlador.addPrivado(vPrivada2);
            configuracionImp config2=new configuracionImp(ventPrinc.getVentanaPadre(), coleccion,controlador);
            config2.show();
         }
          ventPrinc.setCerrarVentanaAuto(true); /*Le decimos a la ventana principal que se
              va ha cerrar automaticamente cuando pulsemos sobre el bot�n conectar*/
          ventPrinc.dispose(); // Y la cerramos
        }

        //Deshabilita la conversacion privada
        //NO SE NECESITA, SE HACE DIRECTAMENTE AL BORRAR EL USUARIO
        if (s.charAt(0) == 'D' && s.charAt(1) == 'P') {
          //st = new StringTokenizer(s.substring(2), "#");
          //String nomUsuarioPrivado = st.nextToken();
          //nomUsuario = st.nextToken();
          //controlador.removePrivado(nomUsuario);
          /*ArrayList vprivadas = controlador.getPrivados();
          VentanaPrivada vPAux;
          for (int i = 0; i < vprivadas.size(); i++) {
            vPAux = (VentanaPrivada) vprivadas.get(i);
            if ((nomUsuario.equals(vPAux.getNameOtherUser()))
                && (nomUsuarioPrivado.equals(vPAux.getNameUser()))) {
              vPAux.addMensaje("Administrador: El usuario " + nomUsuario +
                               " ha abandonado la conversaci�n.");
            }
          }*/
        }

        //Recibo un mensaje privado y lo reparto entre ambos usuarios
        if (s.charAt(0) == 'M' && s.charAt(1) == 'P') {
          st = new StringTokenizer(s.substring(2), "#");
          String nomUsuarioPrivado = st.nextToken();
          nomUsuario = st.nextToken();
          mensaje = st.nextToken();
          ArrayList vprivadas = controlador.getPrivados();
          VentanaPrivada vPAux;
          for (int i = 0; i < vprivadas.size(); i++) {
            vPAux = (VentanaPrivada) vprivadas.get(i);
            //Un usuario
            if ( (nomUsuario.equals(vPAux.getNameUser()))
                && (nomUsuarioPrivado.equals(vPAux.getNameOtherUser()))) {
              vPAux.addMensaje(nomUsuario + ": " + mensaje);
            }
            //Otro usuario
            if ( (nomUsuario.equals(vPAux.getNameOtherUser()))
                && (nomUsuarioPrivado.equals(vPAux.getNameUser()))) {
              vPAux.addMensaje(nomUsuario + ": " + mensaje);
            }
          }
        }

        // Desconecto un cliente
        if (s.charAt(0) == 'D' && s.charAt(1) == 'I') {
          nomUsuario = s.substring(2);
          if (user.equals(nomUsuario))
            break;
        }

      }
    }
    catch (Exception e) {
      JOptionPane.showMessageDialog(null, "El servidor se ha caido",
                                    "Error en la conexi�n",
                                    JOptionPane.ERROR_MESSAGE);
      System.exit(0);
    }
  }

}
