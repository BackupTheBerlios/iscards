
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.net.URL;

/**
 * <p>T�tulo: GENESIS</p>
 * <p>Descripci�n: Interfaz Gr�fico del frame de inicio</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Empresa: </p>
 * @author Rui Miguel
 * @version 1.0
 */

abstract public class frameIntroGUI extends JFrame {
  JPanel contentPane;
  GridBagLayout gridBagLayout1 = new GridBagLayout();
  private JPanel jPanel1 = new JPanel();
  private JButton botonJuegoRed = new JButton();
  private JButton botonEditar = new JButton();
  private JPanel contentPane1 = new JPanel();
  private JButton botonDemo = new JButton();
  private GridBagLayout gridBagLayout2 = new GridBagLayout();
  private JButton boton1Jugador = new JButton();
  private JButton botonAyuda = new JButton();
  private JButton botonReglas = new JButton();
  private JButton botonSalir = new JButton();
  private JLabel jLabel1 = new JLabel();

  /**
   * Constructora de la clase
   */
  public frameIntroGUI() {
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    try {
      jbInit();
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  /**
   * Funci�n de inicializaci�n de los componentes
   * @throws java.lang.Exception
   */
  private void jbInit() throws Exception {
    contentPane = (JPanel)this.getContentPane();
    contentPane.setLayout(gridBagLayout1);
    ImageIcon imagen = new ImageIcon("./imagenes/Escudo_genesis_luz.jpg");
    this.setIconImage(imagen.getImage());
    this.setResizable(false);

    contentPane.setBackground(Color.black);
    //adaptamos el frame del tablero al tama�o maximo de la pantalla (con los SplitPane no se puede hacer de momento porque se desajusta)
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    this.setSize(screenSize.width, screenSize.height);
//    this.setSize(new Dimension(691, 626));
    this.setTitle("GENESIS version_1.0");


//    componente.setAccelerator(KeyStroke.getKeyStroke(tecla,0));
    botonJuegoRed.addActionListener(new frameIntroGUI_botonJuegoRed_actionAdapter(this));
    botonJuegoRed.setBackground(Color.darkGray);
    botonJuegoRed.setForeground(Color.white);
    botonJuegoRed.setText("Juego en Red");
    botonEditar.setBackground(Color.darkGray);
    botonEditar.setForeground(Color.white);
    botonEditar.setPreferredSize(new Dimension(73, 25));
    botonEditar.addActionListener(new frameIntroGUI_botonEditar_actionAdapter(this));
    botonEditar.setText("Editar Baraja");
    contentPane1.setLayout(gridBagLayout2);
    botonDemo.setBackground(Color.darkGray);
    botonDemo.setForeground(Color.white);
    botonDemo.setText("Demo");
    botonDemo.addActionListener(new frameIntroGUI_botonDemo_actionAdapter(this));
    boton1Jugador.setBackground(Color.darkGray);
    boton1Jugador.setForeground(Color.white);
    boton1Jugador.setText("1 Jugador");
    boton1Jugador.addActionListener(new frameIntroGUI_boton1Jugador_actionAdapter(this));
    botonAyuda.setBackground(Color.darkGray);
    botonAyuda.setForeground(Color.white);
    botonAyuda.setText("Ayuda");
    botonAyuda.addActionListener(new frameIntroGUI_botonAyuda_actionAdapter(this));
    botonReglas.setText("Reglas");
    botonReglas.addActionListener(new frameIntroGUI_botonReglas_actionAdapter(this));
    botonReglas.setBackground(Color.darkGray);
    botonReglas.setForeground(Color.white);
    botonReglas.setPreferredSize(new Dimension(73, 25));
    botonSalir.setBackground(Color.darkGray);
    botonSalir.setForeground(Color.white);
    botonSalir.setText("Salir");
    botonSalir.addActionListener(new frameIntroGUI_botonSalir_actionAdapter(this));
    jLabel1.setBackground(Color.black);
    jLabel1.setPreferredSize(new Dimension(80, 100));
    jLabel1.setIcon(imagen);
    contentPane1.setBackground(Color.black);
    jPanel1.setBackground(Color.black);
    contentPane.add(jPanel1,                                                               new GridBagConstraints(0, 3, 1, 2, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 3, 0), -14, -3));
    jPanel1.add(contentPane1, null);
    contentPane1.add(boton1Jugador,      new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 3, 0, 0), 5, 14));
    contentPane1.add(botonJuegoRed, new GridBagConstraints(1, 0, 1, 2, 0.0, 0.0
        , GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 14));
    contentPane1.add(botonDemo,  new GridBagConstraints(2, 0, 9, 3, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 30, 14));
    contentPane1.add(botonAyuda,  new GridBagConstraints(0, 3, 1, 1, 0.0, 0.0
            ,GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 27, 14));
    contentPane1.add(botonEditar, new GridBagConstraints(1, 2, 1, 3, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 38, 16));
    contentPane1.add(botonSalir, new GridBagConstraints(1, 5, 7, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, -1, 0, 0), 53, 14));
    contentPane1.add(botonReglas,   new GridBagConstraints(3, 3, 9, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 27, 14));
    contentPane.add(jLabel1,                         new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(12, 83, 13, 2), 336, 312));


  }

  /**
   * Funci�n WindowEvent para poder salir cuando se cierra la ventana
   * @param e
   */
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
    System.exit(0);
    }
  }

  /**
   *
   * @param e
   */
  abstract void boton1Jugador_actionPerformed(ActionEvent e);

  /**
   *
   * @param e
   */
  abstract void botonJuegoRed_actionPerformed(ActionEvent e);

  /**
   *
   * @param e
   */
  abstract void botonDemo_actionPerformed(ActionEvent e);

  /**
   *
   * @param e
   */
  abstract void botonAyuda_actionPerformed(ActionEvent e);

  /**
   *
   * @param e
   */
  abstract void botonEditar_actionPerformed(ActionEvent e);

  /**
   *
   * @param e
   */
  abstract void botonReglas_actionPerformed(ActionEvent e);

  /**
   *
   * @param e
   */
  abstract void botonSalir_actionPerformed(ActionEvent e);
}