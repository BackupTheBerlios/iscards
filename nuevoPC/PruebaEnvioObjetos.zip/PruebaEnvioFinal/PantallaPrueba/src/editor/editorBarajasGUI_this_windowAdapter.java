package editor;

import java.awt.event.*;

/**
 * <p>T�tulo: GENESIS</p>
 * <p>Descripci�n: windowAdapter del editor de barajas</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Empresa: </p>
 * @author Rui Miguel
 * @version 1.0
 */

class editorBarajasGUI_this_windowAdapter extends WindowAdapter {
  private editorBarajasGUI adaptee;

  editorBarajasGUI_this_windowAdapter(editorBarajasGUI adaptee) {
    this.adaptee = adaptee;
  }
  public void windowClosing(WindowEvent e) {
    adaptee.this_windowClosing(e);
  }
}
