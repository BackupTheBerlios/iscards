package editor;

import carta.*;
import coleccion.*;

import java.awt.event.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Hashtable;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Vector;
import javax.swing.*;

/**
 * <p>T�tulo: GENESIS</p>
 * <p>Descripci�n: Implementaci�n del interfaz gr�fico del Editor de barajas del jugador</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Empresa: </p>
 * @author Rui Miguel
 * @version 1.0
 */
public class editorBarajasImp extends editorBarajasGUI{

  javax.swing.DefaultListModel dlmCartasSeleccionadas = null;
  javax.swing.DefaultListModel dlmCartasDisponibles = null;

  JFrame padre;

  private Coleccion coleccion;

  /**
   * tabla Hash con todas las cartas seleccionadas por el usuario para personalizar una baraja .BAR
   */
  private Hashtable tablaCartasSeleccionadas;

  /**
   * tabla Hash con todas las cartas libres disponibles por el usuario (aquellas que no est�n seleccionadas para personalizar una baraja)
   */
  private Hashtable tablaCartasDisponibles;

  /**
   * Constructora de la clase
   * @param p Frame padre del Editor
   */
  public editorBarajasImp(JFrame p, Coleccion c) {

    tablaCartasSeleccionadas = new Hashtable();
    tablaCartasDisponibles = new Hashtable();
    padre = p;
    coleccion = c;
    padre.disable();

    //asignamos los ListModel a las listas de cartas del editor
    dlmCartasSeleccionadas = new javax.swing.DefaultListModel();
    dlmCartasDisponibles = new javax.swing.DefaultListModel();

//    registrar al usuario antes, para saber que barajas cargar
//    cargarColeccionUsuario(nombUsuario);

    //cargamos las cartas del usuario
    cargarColeccionUsuario();



    //mostramos la lista de disponibles y seleccionadas
    this.listDisponibles.setModel(dlmCartasDisponibles);
    this.listSeleccionadas.setModel(dlmCartasSeleccionadas);
  }

  /**
   * Funci�n que lee de un archivo una cantidad de car�cteres pedida
   * @param longitud cantidad de car�cteres que hay que leer
   * @param archivo archivo del que hay que leer
   * @return String con los datos leidos
   * @throws java.lang.Exception
   */
  private byte[] leerFrase(int longitud, FileInputStream archivo) throws Exception{
    int bytes;
    int i=0;
    byte[] frase=new byte[longitud];
    while(i<longitud){
      bytes= archivo.read();
      if (bytes==-1) //i==-1 es fin de fichero
        throw new Exception("La base de datos esta incompleta");
      frase[i]=(byte)bytes;
      i++;
    }
    return frase;
  }

  /**
   * Funci�n que descodifica los bytes leidos
   * @param fraseBytes bytes leidos
   * @return String frase descodificada
   */
  private String descodificar(byte[] fraseBytes){
    String frase = "";
    int i=0;
    while (i<fraseBytes.length){
      char a;
      if(fraseBytes[i]<0)
        //car�cter espepecial (�, �, �, �, �, �, ...)
        a = (char) (256 + fraseBytes[i] + 2);
      else
        a = (char)(fraseBytes[i] + 2);
      frase=frase+a;
      i++;
    }
    return frase;
  }

  /**
   * Funci�n que carga la colecci�n de cartas del usuario del archivo "usuario.rep"
   */
  private void cargarColeccionUsuario(){//a�adir la coleccion

//  private void cargarColeccionUsuario(String nombUsuario){
//    FileInputStream archivo1 = new FileInputStream("./documentos/" + nombUsuario + ".rep");

    try {
      FileInputStream archivo1 = new FileInputStream("./documentos/usuario.rep");
      //continuamos una colecci�n antigua luego hay que borrar lo que tenemos ahora mismo
      int numeroDeBytesALeer; //variable para controlar los bytes que se deben leer
      numeroDeBytesALeer = archivo1.read();
      tablaCartasDisponibles.clear();
      while (numeroDeBytesALeer >= 0) { // i==-1 es fin de fichero
        //los numeros de letras que hay que leer de descripMov tambi�n est�n codificado
        String cantidad = descodificar(leerFrase(numeroDeBytesALeer,archivo1));
        numeroDeBytesALeer = archivo1.read();
        String codigoCarta = descodificar(leerFrase(numeroDeBytesALeer, archivo1));
        String nombre = coleccion.pedirCarta(codigoCarta).getNombre();
        tablaCartasDisponibles.put(nombre, new Integer(cantidad));
        numeroDeBytesALeer = archivo1.read();
      }
      archivo1.close();
      //recorremos la tabla con toda la coleccion de cartas disponibles y lo a�adimos a la lista de cartas disponibles
      Enumeration nombresCartasKeys;
      String nomCartaValue;
      nombresCartasKeys = tablaCartasDisponibles.keys();
      while (nombresCartasKeys.hasMoreElements()){
        nomCartaValue = (String)nombresCartasKeys.nextElement();
        dlmCartasDisponibles.addElement(nomCartaValue + " " + ((Integer)tablaCartasDisponibles.get(nomCartaValue)).intValue());
      }
    }
    catch (Exception error) {
      //mostramos con un JOptionPane el error producido
      JOptionPane.showMessageDialog(new JOptionPane(), error.getMessage(), "Error",
                                    JOptionPane.ERROR_MESSAGE);
    }
  }

  /**
   * Funci�n que carga la baraja personalizada del usuario del archivo "baraja.bar"
   * @param fichBaraja archivo con la baraja personalizada para cargar
   */
  private void cargarBarajaUsuario(String fichBaraja){//a�adir la coleccion
    try {
      FileInputStream archivo1 = new FileInputStream("./barajas/" + fichBaraja);
      //continuamos una colecci�n antigua luego hay que borrar lo que tenemos ahora mismo
      int numeroDeBytesALeer; //variable para controlar los bytes que se deben leer
      numeroDeBytesALeer = archivo1.read();
      tablaCartasSeleccionadas.clear();
      while (numeroDeBytesALeer >= 0) { // i==-1 es fin de fichero
        String cantidad = descodificar(leerFrase(numeroDeBytesALeer,archivo1));
        numeroDeBytesALeer = archivo1.read();
        String codigoCarta = descodificar(leerFrase(numeroDeBytesALeer, archivo1));
        String nombre = coleccion.pedirCarta(codigoCarta).getNombre();
        tablaCartasSeleccionadas.put(nombre, new Integer(cantidad));
        numeroDeBytesALeer = archivo1.read();
      }
      archivo1.close();
    }
    catch (Exception error) {
      //mostramos con un JOptionPane el error producido
      JOptionPane.showMessageDialog(new JOptionPane(), error.getMessage(), "Error",
                                    JOptionPane.ERROR_MESSAGE);
    }
  }


  /**
   * Funci�n que codifica los bytes que se quieren grabar
   * @param fraseBytes bytes que se desean grabar
   * @return String frase codificada
   */
  private String codificar(byte[] fraseBytes){
    String frase = "";
    int i=0;
    while (i<fraseBytes.length){
      char a;
      if(fraseBytes[i]<0)
        //car�cter espepecial (�, �, �, �, �, �, ...)
        a = (char) (256 + fraseBytes[i] - 2);
      else
        a = (char) (fraseBytes[i] - 2);
      frase=frase+a;
      i++;
    }
    return frase;
  }


  /**
   *
   */
  private void guardarBarajaUsuario(){
    try {
      FileOutputStream archivo1 = new FileOutputStream("./barajas/demonios2_usuario.bar");
      //pedimos los codigos de todas las cartas de la colecci�n
      Enumeration nombresCartasKeys;
      String nomCartaValue;
      nombresCartasKeys =  tablaCartasSeleccionadas.keys();
      while(nombresCartasKeys.hasMoreElements()){
        String nombreCarta=(String)nombresCartasKeys.nextElement();
        String codigo=coleccion.pedirCodigo(nombreCarta);
        Integer cantidad = (Integer)tablaCartasSeleccionadas.get(nombreCarta);

        String cantidadLetra = cantidad.toString();
        archivo1.write(cantidadLetra.length());
        archivo1.write(codificar(cantidadLetra.getBytes()).getBytes());
        archivo1.write(codigo.length());
        archivo1.write(codificar(codigo.getBytes()).getBytes());
      }
      archivo1.close();
    }
    catch (Exception error) {
      //mostramos con un JOptionPane el error producido
      JOptionPane.showMessageDialog(new JOptionPane(), error.getMessage(), "Error",
                                    JOptionPane.ERROR_MESSAGE);
    }
  }

  /**
   *
   */
  private void guardarColeccionUsuario(){
    try {
      FileOutputStream archivo1 = new FileOutputStream("./documentos/usuario.rep");
      //pedimos los codigos de todas las cartas de la colecci�n
      Enumeration nombresCartasKeys;
      String nomCartaValue;
      nombresCartasKeys =  tablaCartasDisponibles.keys();
      while(nombresCartasKeys.hasMoreElements()){
        String nombreCarta=(String)nombresCartasKeys.nextElement();
        String codigo=coleccion.pedirCodigo(nombreCarta);
        Integer cantidad = (Integer)tablaCartasDisponibles.get(nombreCarta);

        String cantidadLetra = cantidad.toString();
        archivo1.write(cantidadLetra.length());
        archivo1.write(codificar(cantidadLetra.getBytes()).getBytes());
        archivo1.write(codigo.length());
        archivo1.write(codificar(codigo.getBytes()).getBytes());
      }
      archivo1.close();
    }
    catch (Exception error) {
      //mostramos con un JOptionPane el error producido
      JOptionPane.showMessageDialog(new JOptionPane(), error.getMessage(), "Error",
                                    JOptionPane.ERROR_MESSAGE);
    }
  }

  /**
   * Funci�n para controlar el evento del mouse en la lista de cartas seleccionadas
   * @param e
   */
  void listSeleccionadas_mouseClicked(MouseEvent e) {
    //observamos el indice seleccionado
    int indice=listSeleccionadas.getSelectedIndex();
    if(indice!=-1){
      String cartaSelec = (String)dlmCartasSeleccionadas.elementAt(indice);
      //hay que leer el nombre de la carta correctamente
      String cartaSelecAux = new String();
      int longitud=cartaSelec.length();
      int i=longitud - 1;
      while (cartaSelec.charAt(i)!=' '){
        i--;
      }
      cartaSelecAux=cartaSelec.substring(0, i);
      //en la tabla tendremos que guardar (carta,num_repetic)
      int numeroCartasSel = ((Integer)tablaCartasSeleccionadas.get(cartaSelecAux)).intValue();
      dlmCartasSeleccionadas.removeElement(cartaSelecAux + " " + numeroCartasSel);
      numeroCartasSel = numeroCartasSel - 1;
      if (numeroCartasSel != 0) {
        tablaCartasSeleccionadas.put(cartaSelecAux, new Integer(numeroCartasSel));
        dlmCartasSeleccionadas.addElement(cartaSelecAux + " " + numeroCartasSel);
      }
      else { //si se quedan 0 repeticiones de la carta seleccionada la eliminamos
        tablaCartasSeleccionadas.remove(cartaSelecAux);
      }
      //a�adimos la carta a la tabla de las disponibles
      if (tablaCartasDisponibles.containsKey(cartaSelecAux)) {
        //se mira en la lista de cartas disponibles la carta seleccionada
        numeroCartasSel = ((Integer)tablaCartasDisponibles.get(cartaSelecAux)).intValue();
        dlmCartasDisponibles.removeElement(cartaSelecAux + " " + numeroCartasSel);
        numeroCartasSel = numeroCartasSel + 1;
        //a�adimos la carta al dlm y tabla de Seleccionadas
        dlmCartasDisponibles.addElement(cartaSelecAux + " " + numeroCartasSel);
        tablaCartasDisponibles.put(cartaSelecAux, new Integer(numeroCartasSel));
      }
      else { //si la carta no se encontraba entre las disponibles
        tablaCartasDisponibles.put(cartaSelecAux, new Integer(1));
        dlmCartasDisponibles.addElement(cartaSelecAux + " " + 1);
      }
    }
  }

  /**
   * Funci�n para controlar el evento del mouse en la lista de cartas disponibles
   * @param e
   */
  void listDisponibles_mouseClicked(MouseEvent e) {
    int indice=listDisponibles.getSelectedIndex();
    if(indice!=-1){
      String cartaSelec = (String)dlmCartasDisponibles.elementAt(indice);
      //hay que leer el nombre de la carta correctamente
      String cartaSelecAux = new String();
      int longitud=cartaSelec.length();
      int i=longitud - 1;
      while (cartaSelec.charAt(i)!=' '){
        i--;
      }
      cartaSelecAux=cartaSelec.substring(0, i);
      //actualizamos en la lista de Disponibles la carta del indice
      int numeroCartasDisp = ((Integer)tablaCartasDisponibles.get(cartaSelecAux)).intValue();
      dlmCartasDisponibles.removeElement(cartaSelecAux + " " + numeroCartasDisp);
      numeroCartasDisp = numeroCartasDisp - 1;
      if (numeroCartasDisp != 0) {
        tablaCartasDisponibles.put(cartaSelecAux, new Integer(numeroCartasDisp));
        dlmCartasDisponibles.addElement(cartaSelecAux + " " + numeroCartasDisp);
      }
      else { //si se quedan 0 repeticiones de la carta seleccionada la eliminamos de la tabla
        tablaCartasDisponibles.remove(cartaSelecAux);
      }
      //a�adimos la carta a la tabla de las seleccionadas
      if (tablaCartasSeleccionadas.containsKey(cartaSelecAux)) {
        //se mira en la lista de cartas seleccionadas la carta seleccionada
        numeroCartasDisp = ((Integer)tablaCartasSeleccionadas.get(cartaSelecAux)).intValue();
        dlmCartasSeleccionadas.removeElement(cartaSelecAux + " " + numeroCartasDisp);
        numeroCartasDisp = numeroCartasDisp + 1;
        //a�adimos la carta al dlm y tabla de Seleccionadas
        dlmCartasSeleccionadas.addElement(cartaSelecAux + " " + numeroCartasDisp);
        tablaCartasSeleccionadas.put(cartaSelecAux, new Integer(numeroCartasDisp));
      }
      else { //si la carta no se encontraba entre las Seleccionadas
        tablaCartasSeleccionadas.put(cartaSelecAux, new Integer(1));
        dlmCartasSeleccionadas.addElement(cartaSelecAux + " " + 1);
      }
    }
  }

  /**
   * Funci�n actionPerformed para guardar una baraja configurada
   * @param e
   */
  void botonGuardar_actionPerformed(ActionEvent e) {
    //si la lista de cartas seleccionadas no est� vacio
    if(!dlmCartasSeleccionadas.isEmpty()){
      //usamos un filtro para guardar las barajas
      JFileChooser fichero = new JFileChooser("./barajas");
      FiltroURL filtro = new FiltroURL("usuario.bar");
      fichero.setFileFilter(filtro);
      int valor = fichero.showSaveDialog(this);
      if (valor == JFileChooser.APPROVE_OPTION) {
        guardarBarajaUsuario();
        guardarColeccionUsuario();
      }
    }
  }

  /**
   * Funci�n actionPerformed para cargar una baraja configurada
   * @param e
   */
  void botonCargar_actionPerformed(ActionEvent e) {
    dlmCartasSeleccionadas.clear();
    dlmCartasDisponibles.clear();
    cargarColeccionUsuario();
    //usamos un filtro para cargar las barajas
    JFileChooser fichero = new JFileChooser("./barajas");
    FiltroURL filtro = new FiltroURL("usuario.bar");
    fichero.setFileFilter(filtro);
    int valor = fichero.showOpenDialog(this);
    if (valor == JFileChooser.APPROVE_OPTION){
      String nombreFichero;
      nombreFichero =(fichero.getSelectedFile()).getName();
      cargarBarajaUsuario(nombreFichero);
      //recorremos la tabla con toda la coleccion de cartas y lo a�adimos a la lista de cartas disponibles
      Enumeration nombresCartasKeys;
      String nomCartaValue;
      nombresCartasKeys =  tablaCartasSeleccionadas.keys();
      //escribimos en el dlm de Seleccionadas todas las cartas cargadas de la baraja
      while (nombresCartasKeys.hasMoreElements()){
        nomCartaValue = (String)nombresCartasKeys.nextElement();
        int numeroCartasSel = ((Integer)tablaCartasSeleccionadas.get(nomCartaValue)).intValue();
        dlmCartasSeleccionadas.addElement(nomCartaValue + " " + numeroCartasSel);
      }
    }
  }

  /**
   * Funci�n actionPerformed para el bot�n Aceptar
   * @param e
   */
  void botonAceptar_actionPerformed(ActionEvent e) {
    this.dispose();
    padre.enable();
    padre.show();
  }

  /**
   *
   * @param e
   */
  void this_windowClosing(WindowEvent e) {
    padre.enable();
  }
}