package chat;

import java.io.*;
import java.net.*;
import java.util.*;
import javax.swing.*;

/**
 *
 * <p>T�tulo: GENESIS</p>
 * <p>Descripci�n: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Empresa: </p>
 * @author Manuel Domingo Mora Martinez y Jes�s Pati�o G�mez
 * @version 1.0
 */
public class Controlador {

  /**
   * GestorUsuarios del programa (Modelo)
   */
  private GestorUsuarios gestorUsuarios;

  /**
   * ArrayList con las ventanas privadas que estan actualmente abiertas
   */
  private ArrayList ventanasPrivados = new ArrayList();

  /**
   * Socket de conexi�n de cliente
   */
  Socket sCliente = null;
  /**
   * Flujo de salida
   */
  private PrintWriter salida;

  /**
   * Buffer de lectura
   */
  private ObjectInputStream entrada;

  public Controlador(GestorUsuarios u) {
    gestorUsuarios = u;
  }

  public boolean aniadirUser(String nick) {
    if (gestorUsuarios.registrarUser(nick)){
      salida.println("NU" + "#" + nick);
      salida.flush();
      return true;
    }
    else
      return false;
  }


  /**
   * Obtiene la lista de los nick de los usuarios conectados
   * @return DefaultListModel lista de los nicks de los usuarios conectados
   */
  public DefaultListModel getNicks(String nick) {
    DefaultListModel listNicks = new DefaultListModel();
    Vector userAux = gestorUsuarios.getUsers();
    for (int i = 0; i < userAux.size(); i++)
      if(!nick.equals((userAux.get(i))))//Modificado para que en la lista de usuarios
        //conectados el usuario no se vea a s� mismo puesto q con �l mismo no puede hablar ;)
        listNicks.addElement(userAux.get(i));
    return listNicks;
  }

  public void borrarUser(String nick) {
    gestorUsuarios.removeUser(nick);
    salida.println("DU" + "#" + nick);
    salida.flush();
  }

  /**
   * Conecta el programa al servidor de chat
   */
  public boolean conectar() {
    try {

      //Creamos el socket en el puerto
      InetAddress address = InetAddress.getByName("147.96.84.152");/*getLocalHost();*/
      sCliente = new Socket(address, 4999);
      System.out.println("Conectado a " +
                         sCliente.getInetAddress().getHostName());

      Vector uReg = new Vector();//vector con los Usuarios registrados

      salida = new PrintWriter(sCliente.getOutputStream(), true);
      entrada = new ObjectInputStream(sCliente.getInputStream());

      //Consiguo los usuarios existentes en el servidor
      //y los almaceno en mi vector de usuarios
      uReg = (Vector) entrada.readObject();
      gestorUsuarios.setVectorUsuarios(uReg);
      return true;

    }
    catch (Exception e) {
      JOptionPane.showMessageDialog(null, "El servidor est� caido.",
                                    "Error en la conexi�n",
                                    JOptionPane.ERROR_MESSAGE);
      return false;
    }
  }

  /**
   * Funcion para ejecutar Comunicacion en otra hebra de ejecuci�n
   * @param ventPrinc Ventana principal del programa
   */
  public void ejecutarComunicacion(VentanaPrincipal ventPrinc) {
    new Comunicacion(this, ventPrinc).start();
  }

  /**
   * Funcion para desconectar a un usuario
   * @param nomUsuario nombre del usuario a desconectar
   */
  public void desconectar(String nomUsuario) {
    salida.println("DI" + nomUsuario);
    salida.flush();
    System.out.println("Desconectado");
  }

  /**
   * getSocket
   *
   * @return Object
   */
  public synchronized Socket getSocket() {
    return sCliente;
  }

  /**
   * A�ade una ventana de privado al vector de ventanas privadas
   * @param ventPriv Ventana a a�adir
   */
  public synchronized void addPrivado(VentanaPrivada ventPriv) {
    ventanasPrivados.add(ventPriv);
  }

  /**
   * Abre desde el servidor la ventana privada correspondiente.
   * @param nomUsuario nombre del usuario que soy
   * @param nomUsuarioPrivado nombre del otro usuario con el que quiero hacer la conversaci�n privada
   */
  public void activarPrivado(String nomUsuario,
                             String nomUsuarioPrivado) {
    salida.println("NP" + "#" + nomUsuario + "#" + nomUsuarioPrivado);
    salida.flush();
  }



  /**
   * Desactiva desde el servidor la ventana privada correspondiente.
   * @param nomUsuario nombre del usuario que soy
   * @param nomUsuarioPrivado nombre del otro usuario con el que quiero hacer la conversaci�n privada
   */
  public void desactivarPrivado(String nomUsuario,
                                String nomUsuarioPrivado) {
    salida.println("DP" + "#" + nomUsuarioPrivado + "#" + nomUsuario);
    salida.flush();
  }

  /**
   * Borra un privado del vector de privados de un determinado usuario, ademas de cerrar la ventana
   * @param user Usuario del que se desea eliminar el privado
   */
  public synchronized void removePrivado(String user) {
    for (int i = 0; i < ventanasPrivados.size(); i++) {
      if ( ( (VentanaPrivada) ventanasPrivados.get(i)).getNameUser().equals(
          user)) {
        ( (JFrame) ventanasPrivados.get(i)).dispose();
        ventanasPrivados.remove(i);
      }
    }
  }

  /**
   * Funcion que me devuelve un ArrayList con las ventanas privadas que hay actualmente abiertas
   * @return ArrayList de ventanas de privadas
   */
  public synchronized ArrayList getPrivados() {
    return ventanasPrivados;
  }

  /**
   * Funcion que me devuelve la clase GestorUsuarios
   * @return GestorUsuarios
   */
  public synchronized GestorUsuarios getGestorUsuarios() {
    return gestorUsuarios;
  }

  /**
   * Envia un nuevo mensaje privado al servidor
   * @param nomUsuario nombre del usuario que soy
   * @param nomOtroUser nombre del otro usuario con el que estoy conversando en privado
   * @param mens mensaje a enviar a los demas usuarios
   */
  public void enviarPrivadoAServidor(String nomUsuario, String nomOtroUser,
                                     String mens) {
    salida.println("MP" + "#" + nomOtroUser + "#" + nomUsuario + "#" + mens);
    salida.flush();
  }

}
