package chat;

import java.io.*;

/**
 *
 * <p>T�tulo: GENESIS</p>
 * <p>Descripci�n: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Empresa: </p>
 * @author Manuel Domingo Mora Martinez y Jes�s Pati�o G�mez
 * @version 1.0
 */
public class Cliente  {
 public void Cliente()
 {
//   GestorUsuarios gestorUsuarios = new GestorUsuarios();
//   Controlador controlador = new Controlador(gestorUsuarios);
//   GUI ventana = new GUI(controlador);
 }
  /*
   public static void main(String args[]) throws IOException
    {
      GestorUsuarios gestorUsuarios = new GestorUsuarios();
      Controlador controlador = new Controlador(gestorUsuarios);
      GUI ventana = new GUI(controlador);
    }//main*/
}

