package configuracion;

import tablero.*;
import editor.*;
import carta.*;
import coleccion.*;

import java.awt.event.*;
import javax.swing.*;
import java.util.Vector;

/**
 * <p>T�tulo: GENESIS</p>
 * <p>Descripci�n: Implementaci�n del interfaz gr�fico del frame de Configuraci�n de la partida</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Empresa: </p>
 * @author Rui Miguel
 * @version 1.0
 */

public class configuracionImp extends configuracionGUI{

  JFrame padre;

  private editorBarajasImp editor;

  private Coleccion coleccion;

  private CMazo mazoCartasJuego;


  int barajaInd;

  char raza =' ';

  javax.swing.DefaultListModel dlmBarajasDisponibles;

  /**
   * Constructora de la clase
   * @param p Frame padre del frame Configuraci�n
   */
  public configuracionImp(JFrame p, Coleccion c) {
    padre = p;
    coleccion = c;
    padre.disable();
    dlmBarajasDisponibles = new javax.swing.DefaultListModel();

    cargarBarajas();

//*****************************
//BARAJAS DE PRUEBAS INICIALES
    Vector barajasPrueba = new Vector();
    barajasPrueba.addElement("barajaAngeles");
    barajasPrueba.addElement("barajaDemonios");
    barajasPrueba.addElement("barajaHumanos");
    barajasPrueba.addElement("barajaInmortales");

    for(int i=0; i<barajasPrueba.size(); i++)
      dlmBarajasDisponibles.addElement(barajasPrueba.get(i));

//*****************************

    this.listBarajas.setModel(dlmBarajasDisponibles);
  }

  /**
   * Funci�n que muestra todas las barajas personalizadas disponibles para el usuario
   */
  private void cargarBarajas(){
//    dlmBarajasDisponibles.addElement();
  }

  /**
   * Funci�n para controlar la baraja seleccionada con la que se jugar�
   * @param e
   */
  void listBarajas_mouseClicked(MouseEvent e) {
    barajaInd=listBarajas.getSelectedIndex();
    if(barajaInd!=-1){
      String barajaSelec=(String)dlmBarajasDisponibles.elementAt(barajaInd);

//****************
      if(barajaSelec.equals("barajaAngeles")) {
        raza = 'A';
      }
      else if(barajaSelec.equals("barajaDemonios")) {
        raza = 'D';
      }
      else if(barajaSelec.equals("barajaHumanos")) {
        raza = 'H';
      }
      else if(barajaSelec.equals("barajaInmortales")) {
        raza = 'I';
      }
//***************
    }
  }

  /**
   * Funci�n actionPerformed del bot�n Editar barajas
   * @param e
   */
  void botonEditar_actionPerformed(ActionEvent e) {
    editor = new editorBarajasImp(this,coleccion);
    editor.show();
  }

  /**
   * Funci�n actionPerformed del bot�n Aceptar
   * @param e
   */
  void botonAceptar_actionPerformed(ActionEvent e) {

    //creamos el tablero del juego seg�n la baraja seleccionada
    if(barajaInd!=-1){
      String barajaSelec=(String)dlmBarajasDisponibles.elementAt(barajaInd);
      mazoCartasJuego = new CMazo();

//****************************
//      Enumeration keysCartasDelMazo = tablaCartasSeleccionadas.keys();
//      while (keysCartasDelMazo.hasMoreElements()){
//        String nombreCarta = (String)keysCartasDelMazo.nextElement();
//crear la carta
//      CACarta carta;
//      mazoCartas.anadeCarta(carta);
//      }
//       mazoCartasJuego = crearMazo(barajaSelec);
//****************************

      tableroJuegoImp tablero = new tableroJuegoImp(padre,coleccion, raza, mazoCartasJuego);
      tablero.show();
      this.dispose();
    }
    else
      //se tiene que seleccionar una baraja previamente de la lista de barajas
      JOptionPane.showMessageDialog(this, "Tienes que elegir una baraja antes!!", "Baraja", JOptionPane.INFORMATION_MESSAGE);
  }

  /**
   * Funci�n actionPerformed del bot�n Cancelar
   * @param e
   */
  void botonCancelar_actionPerformed(ActionEvent e) {
    this.dispose();
    padre.enable();
    padre.show();
  }

  /**
   *
   * @param e
   */
  void this_windowClosing(WindowEvent e) {
    padre.enable();
  }
}