
import java.awt.*;

// Implementaci�n de un controlador de posicionamiento propio, que va
// a permitir colocar los componenetes en cualquier lugar de su dominio
// Tenemos que sobrecargar o definir los m�todos que se utilizan en los
// LayoutManager para que todo funcione, aunque no hagan nada, porque
// aunque nosotros no llamemos expl�citamente a esos m�todos en ninguna
// ocasi�n, es el propio sistema el que puede hacerlo
public class MiLayout implements LayoutManager {

    // Constructor
    public MiLayout() {
        }


    // M�todo para la incorporaci�n de componentes
    public void addLayoutComponent( String name,Component comp ) {
        }


    // M�todo para eliminar componentes del controlador
    public void removeLayoutComponent( Component comp ) {
        }


    // Fija la dimensi�n del controaldor en funci�n de la dimensi�n
    // de los componentes y su posici�n, para que se vean todos en
    // el espacio de pantalla destinado al controlador
    public Dimension preferredLayoutSize( Container parent ) {
        Insets insets = parent.insets();
        int numero = parent.countComponents();
        int ancho = 0;
        int alto = 0;

        for( int i=0; i < numero; i++ )
            {
            Component comp = parent.getComponent( i );
            Dimension d = comp.preferredSize();
            Point p = comp.location();

            if( ( p.x + d.width ) > ancho )
                ancho = p.x + d.width;
            if( ( p.y + d.height ) > alto )
                alto = p.y + d.height;
            }

        return( new Dimension( insets.left + insets.right + ancho,
            insets.top + insets.bottom + alto ) );
        }


    // Controlamos la dimensi�n m�nima que debe tener el controlador
    public Dimension minimumLayoutSize( Container parent ) {
        Insets insets = parent.insets();
        int numero = parent.countComponents();
        int ancho = 0;
        int alto = 0;

        for( int i=0; i < numero; i++ )
            {
            Component comp = parent.getComponent( i );
            Dimension d = comp.preferredSize();
            Point p = comp.location();

            if( ( p.x + d.width ) > ancho )
                ancho = p.x + d.width;
            if( ( p.y + d.height ) > alto )
                alto = p.y + d.height;
            }

        return( new Dimension( insets.left + insets.right + ancho,
            insets.top + insets.bottom + alto ) );
        }



    // Reescala los componentes a su tama�o preferido en caso de que
    // se pueda hacer
    public void layoutContainer( Container parent ) {
        int numero = parent.countComponents();

        for( int i=0; i < numero; i++ )
            {
            Component comp = parent.getComponent( i );
            Dimension d = comp.preferredSize();
            comp.resize(d.width,d.height);
            }
        }
    }

//--------------------------------------- Final del fichero MiLayout.java
