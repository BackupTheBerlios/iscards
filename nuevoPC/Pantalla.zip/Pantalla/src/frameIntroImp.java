import carta.*;
import editor.*;
import coleccion.*;
import configuracion.*;
import tablero.*;

import java.awt.event.*;
import javax.swing.*;
import java.io.File;
import java.net.URL;
import java.awt.Dimension;
import java.awt.Color;

/**
 * <p>T�tulo: GENESIS</p>
 * <p>Descripci�n: Implementaci�n del interfaz gr�fico del frame de inicio</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Empresa: </p>
 * @author Rui Miguel
 * @version 1.0
 */

public class frameIntroImp extends frameIntroGUI {

  private Coleccion coleccion;
  /**
   * Constructora de la clase
   */
  public frameIntroImp() {
    coleccion=new Coleccion();//TODAS
  }

  /**
   * Funci�n actionPerformed del bot�n 1 Jugador
   * @param e
   */
  void boton1Jugador_actionPerformed(ActionEvent e) {
    //mostramos el frame de Configuraci�n de la partida
     configuracionImp conf = new configuracionImp(this,coleccion);
     conf.show();
   }

   /**
    * Funci�n actionPerformed del bot�n Juego en Red
    * @param e
    */
   void botonJuegoRed_actionPerformed(ActionEvent e) {
     //mostramos el frame de Configuraci�n de la partida
     configuracionImp conf = new configuracionImp(this,coleccion);
     conf.show();
   }

   /**
    * Funci�n actionPerformed del bot�n Demo
    * @param e
    */
   void botonDemo_actionPerformed(ActionEvent e) {

//************************
//*******CAMBIAR**********
 //************************
     CMazo mazoDemo = new CMazo();
     //mostramos el frame del Tablero de juego
     tableroJuegoImp tablero = new tableroJuegoImp(this,coleccion, 'D', mazoDemo);
     tablero.show();
   }

   /**
    * Funci�n actionPerformed del bot�n mostrar Ayuda
    * @param e
    */
   void botonAyuda_actionPerformed(ActionEvent e) {
     //creamos el pane para mostrar el archivo
     JEditorPane ayuda = new JEditorPane();
     ImageIcon escudo = new ImageIcon("./imagenes/Escudo_genesis_luz.jpg");
     //cargamos el archivo de ayuda
     try{
       ayuda.setPage("file:./documentos/ayuda.txt");
       ayuda.setEditable(false);
       JTextPane texto = new JTextPane();
       texto.setEditable(false);
       texto.setText(ayuda.getText());
       JPanel panelAyuda = new JPanel();
       panelAyuda.add(texto);
       JScrollPane scrollAyuda = new JScrollPane(panelAyuda);
       scrollAyuda.setPreferredSize(new Dimension(600,300));
       JOptionPane.showMessageDialog(this, scrollAyuda, "AYUDA", JOptionPane.INFORMATION_MESSAGE,escudo);
     }
     catch(Exception ex){
       //mostramos con un JOptionPane el error producido
       JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE,escudo);
     }
   }

   /**
    * Funci�n actionPerformed del bot�n Editar barajas
    * @param e
    */
   void botonEditar_actionPerformed(ActionEvent e) {
     //mostramos el frame del Editor de barajas
     editorBarajasImp editor = new editorBarajasImp(this,coleccion);
     editor.show();
   }

   /**
    * Funci�n actionPerformed del bot�n mostrar Reglas
    * @param e
    */
   void botonReglas_actionPerformed(ActionEvent e) {
     //creamos el pane para mostrar el archivo
     JEditorPane reglas = new JEditorPane();
     ImageIcon escudo = new ImageIcon("./imagenes/Escudo_genesis_luz.jpg");
     //cargamos el archivo de reglas
      try{
        reglas.setPage("file:./documentos/reglas.txt");
        reglas.setEditable(false);
        JTextPane texto = new JTextPane();
        texto.setEditable(false);
        texto.setText(reglas.getText());
        JPanel panelReglas = new JPanel();
        panelReglas.add(texto);
        panelReglas.setSize(500,500);
        JScrollPane scrollReglas = new JScrollPane(panelReglas);
        scrollReglas.setPreferredSize(new Dimension(700,500));
        JOptionPane.showMessageDialog(this, scrollReglas, "REGLAS version_1.0", JOptionPane.INFORMATION_MESSAGE,escudo);
      }
        catch(Exception ex){
                //mostramos con un JOptionPane el error producido
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
      }
    }

   /**
    * Funci�n actionPerformed del bot�n Salir
    * @param e
    */
   void botonSalir_actionPerformed(ActionEvent e) {
     //solicitamos confirmaci�n para salir
     int salir = JOptionPane.showConfirmDialog(this, "Desea salir?", "GENESIS version_1.0",
                                               JOptionPane.YES_NO_OPTION,
                                               JOptionPane.QUESTION_MESSAGE);
     switch (salir) {
       case JOptionPane.YES_OPTION:
         System.exit(0);
       case JOptionPane.NO_OPTION:
         ;
     }
   }

}