package configuracion;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import com.borland.jbcl.layout.*;

/**
 * <p>T�tulo: GENESIS</p>
 * <p>Descripci�n: Interfaz Gr�fico del frame de Configuraci�n de la partida</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Empresa: </p>
 * @author Rui Miguel
 * @version 1.0
 */

 abstract public class configuracionGUI extends JFrame{

   JPanel jPanel1 = new JPanel();
   JList listBarajas = new JList();
   JLabel jLabel1 = new JLabel();
   JButton botonEditar = new JButton();
   JButton botonAceptar = new JButton();
   JButton botonCancelar = new JButton();
   BorderLayout borderLayout1 = new BorderLayout();
   XYLayout xYLayout1 = new XYLayout();

   /**
    * Constructora de la clase
    */
   public configuracionGUI() {
     try {
       jbInit();
     }
     catch (Exception e) {
       e.printStackTrace();
     }
   }

   /**
    * Funci�n de inicializaci�n del frame Configuraci�n
    * @throws java.lang.Exception
    */
   private void jbInit() throws Exception {
     this.setResizable(false);
     this.setTitle("Configuracion");
     this.addWindowListener(new configuracionGUI_this_windowAdapter(this));
     this.setSize(new Dimension(394, 402));
     this.getContentPane().setLayout(borderLayout1);

     jLabel1.setFont(new java.awt.Font("Dialog", 0, 17));
     jLabel1.setText("BARAJAS GUARDADAS");
     botonEditar.setText("Editar Baraja");
     botonAceptar.setText("Aceptar");
     botonCancelar.setText("Cancelar");

     //a�adimos los actionListener a los botones del frame
     botonEditar.addActionListener(new configuracionGUI_botonEditar_actionAdapter(this));
     botonAceptar.addActionListener(new configuracionGUI_botonAceptar_actionAdapter(this));
     botonCancelar.addActionListener(new configuracionGUI_botonCancelar_actionAdapter(this));
     listBarajas.addMouseListener(new configuracionGUI_listBarajas_mouseAdapter(this));

     jPanel1.setLayout(xYLayout1);
     jPanel1.add(botonAceptar, new XYConstraints(234, 139, -1, -1));
     jPanel1.add(botonCancelar, new XYConstraints(234, 187, -1, 29));
     jPanel1.add(listBarajas, new XYConstraints(25, 72, 193, 273));
     jPanel1.add(jLabel1, new XYConstraints(25, 21, 189, 40));
     jPanel1.add(botonEditar, new XYConstraints(234, 69, 97, 29));

     this.getContentPane().add(jPanel1, BorderLayout.CENTER);
   }

   /**
    *
    * @param e
    */
   abstract void listBarajas_mouseClicked(MouseEvent e);

   /**
    *
    * @param e
    */
   abstract void botonEditar_actionPerformed(ActionEvent e);

   /**
    *
    * @param e
    */
   abstract void botonAceptar_actionPerformed(ActionEvent e);

   /**
    *
    * @param e
    */
   abstract void botonCancelar_actionPerformed(ActionEvent e);

   /**
    *
    * @param e
    */
   abstract void this_windowClosing(WindowEvent e);
 }