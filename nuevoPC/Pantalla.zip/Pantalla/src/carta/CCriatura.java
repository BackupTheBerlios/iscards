package carta;

/**
 * <p>T�tulo: GENESIS</p>
 * <p>Descripci�n: Clase abstracta que extenderan todos los objetos de tipo carta</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Empresa: </p>
 * @author Tony
 * @version 1.0
 */

public class CCriatura extends CACarta{

  /**
   * Variable con la vida de la criatura
   */
  private int vida;

  /**
   * Variable con el valor del ataque de la criatura
   */
  private int ataque;

  /**
   * Variable con el valor de defensa de la criatura
   */
  private int defensa;

  /**
   * Cosntructora de la clase Carta Criatura
   * @param niv
   * @param cost
   * @param punt
   * @param cod
   * @param nom
   * @param idR
   * @param idT
   * @param coment
   * @param hab
   */
  public CCriatura(int niv, int cost, int punt,int at, int def, String cod, String nom, String idR, String idT, String coment, String hab){

    nivel=niv;
    coste=cost;
    puntos=punt;
    ataque = at;
    defensa = def;
    codigo=cod;
    nombre=nom;
    idRaza=idR;
    idTipo=idT;
    comentarios=coment;
    habilidades=hab;
//    estado=true;
  }

  /**
   *
   * @return
   */
  public int getVida(){
    return vida;
  }

  /**
   *
   */
  public int getAtaque(){
    return ataque;
  }

  /**
   *
   */
  public int getDefensa(){
    return defensa;
  }

  /**
   *
   * @param at
   */
  public void setAtaque(int at){

  }

  /**
   *
   */
  public void setDefensa(int def){

  }

  /**
   *
   * @param v
   */
  public void setVida(int v){

  }

  /**
   *
   * @return
   */
  public boolean ataca(){
    return false;
  }

  /**
   *
   * @return
   */
  public boolean defiende(){
    return false;
  }

  /**
   *
   * @param da�o
   * @return
   */
  public boolean restaVida(int da�o){
    this.setVida(this.getVida() - da�o);
    if(this.getVida() < 0)
      return false; //ha muerto
    else return true;          //aun vive
  }

  /**
   *
   * @return
   */
  public boolean ejecuta() {  //puede tener hab especiales
//      estado = !estado;
    return false;
  }
}
