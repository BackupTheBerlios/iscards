package carta;

/**
 * <p>T�tulo: GENESIS</p>
 * <p>Descripci�n: Clase abstracta que extenderan todos los objetos de tipo carta</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Empresa: </p>
 * @author Tony
 * @version 1.0
 */

public class CHechizo extends CACarta {

  /**
   *
   */
  protected int idHab;

  /**
   *Constructora de la clase Carta Hechizo
   * @param cod
   * @param raz
   * @param tip
   * @param nom
   * @param niv
   * @param punt
   * @param cost
   * @param coment
   * @param hab
   */
  public CHechizo(int niv, int cost, int punt, String nom, String cod, String idR, String idT, String coment, String hab){

    nivel=niv;
    coste=cost;
    puntos=punt;
    codigo=cod;
    nombre=nom;
    idRaza=idR;
    idTipo=idT;
    comentarios=coment;
    habilidades=hab;
//    estado=true;
  }

  /**
   * Ejecuta las propiedades del hechizo en cuesti�n seg�n su habilidad
   */
  public boolean ejecuta() {
//    estado = !estado;
    return false;
  }
}
