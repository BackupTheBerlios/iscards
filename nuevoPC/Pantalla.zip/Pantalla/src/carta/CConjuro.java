package carta;

/**
 * <p>T�tulo: GENESIS</p>
 * <p>Descripci�n: Clase abstracta que extenderan todos los objetos de tipo carta</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Empresa: </p>
 * @author Tony
 * @version 1.0
 */

public class CConjuro extends CACarta {

  /**
   *
   */
  private int duracion;

  /**
   * Constructora de la clase Carta Conjuro
   * @param niv
   * @param cost
   * @param punt
   * @param cod
   * @param nom
   * @param idR
   * @param idT
   * @param coment
   * @param hab
   */
  public CConjuro(int niv, int cost, int punt, String cod, String nom, String idR, String idT, String coment, String hab){

    nivel=niv;
    coste=cost;
    puntos=punt;
    codigo=cod;
    nombre=nom;
    idRaza=idR;
    idTipo=idT;
    comentarios=coment;
    habilidades=hab;
//    estado=true;
  }

  /** Creates a new instance of CConjuro */
  public CConjuro(int dur) {
    duracion = dur;
  }

  /**
   *
   * @return
   */
  public boolean ejecuta() {
//    estado= !estado;
    return false;
  }

}
