package carta;

import java.util.Vector;

/**
 * <p>T�tulo: GENESIS</p>
 * <p>Descripci�n: Clase abstracta que extenderan todos los objetos de tipo carta</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Empresa: </p>
 * @author Tony
 * @version 1.0
 */

public class CMano {

  /**
   * Variable Vector con todas las cartas
   */
  private Vector vectorCartas;

    /**
     * Constructora de la clase CMano
     */
    public CMano() {
        vectorCartas = new Vector();
    }

    /**
     *
     */
    public Vector getCartas(){
      return vectorCartas;
    }

    /**
     * Funci�n que roba hasta completar 8 cartas en la mano de un mazo
     */
    public void roba(CMazo mazo){
       while (this.getCartas().size() < 8){
           Object carta = mazo.robaCarta();
           if (carta != null){
           this.getCartas().add(carta);
           }
       }
    }
}
