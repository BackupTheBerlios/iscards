package carta;

import java.util.LinkedList;

/**
 * <p>T�tulo: GENESIS</p>
 * <p>Descripci�n: Clase para representar el mazo de cartas del que robar� un usuario para jugar</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Empresa: </p>
 * @author Tony
 * @version 1.0
 */

public class CMazo {

  /**
   * Variable que guardar� las cartas en una lista
   */
  private LinkedList listaCartas;

  /**
   * Variable con el tama�o del mazo
   */
  private int tamano;

  /**
   * Constructora de la clase CMazo con el mazo de las cartas
   */
  public CMazo() {
    listaCartas = new LinkedList();
    tamano = 0;
  }

  /**
   *
   * @return
   */
  public LinkedList getCartas(){
    return listaCartas;
  }

  /**
   *
   * @param c
   */
  public void anadeCarta(CACarta c){
    this.getCartas().add(c);
    tamano++;
  }

  public Object robaCarta(){
    tamano--;
    if (this.getCartas().size()!=0)
      return this.getCartas().getLast();
    else return null; //mazo terminado
  }
}
