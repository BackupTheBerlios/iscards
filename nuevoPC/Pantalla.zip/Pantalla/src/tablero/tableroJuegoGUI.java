package tablero;

import carta.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * <p>T�tulo: GENESIS</p>
 * <p>Descripci�n: Interfaz Gr�fico del tablero de juego</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Empresa: </p>
 * @author Rui Miguel
 * @version 1.0
 */

abstract public class tableroJuegoGUI extends JFrame {
  //a�adimos las pesta�as para separar los tableros de Mazo del jugador,Mesa del jugador y Mesa del contrario
  JTabbedPane jTabbedPane1 = new JTabbedPane();
  JPanel panelJugador = new JPanel();
  JPanel panelContrario = new JPanel();
  JPanel panelMazo = new JPanel();

  BorderLayout borderLayout1 = new BorderLayout();
  BorderLayout borderLayout2 = new BorderLayout();
  BorderLayout borderLayout3 = new BorderLayout();

  //creamos los SplitPane que formar�n el tablero
  JSplitPane jSplitPane1 = new JSplitPane();
  JSplitPane jSplitPane2 = new JSplitPane();
  JSplitPane jSplitPane3 = new JSplitPane();
  JSplitPane jSplitPane4 = new JSplitPane();
  JSplitPane jSplitPane5 = new JSplitPane();
  JSplitPane jSplitPane6 = new JSplitPane();
  JSplitPane jSplitPane7 = new JSplitPane();
  JSplitPane jSplitPane8 = new JSplitPane();
  JSplitPane jSplitPane9 = new JSplitPane();
  JSplitPane jSplitPane10 = new JSplitPane();
  JSplitPane jSplitPane11 = new JSplitPane();
  JSplitPane jSplitPane12 = new JSplitPane();
  JSplitPane jSplitPane13 = new JSplitPane();
  JSplitPane jSplitPane14 = new JSplitPane();
  JSplitPane jSplitPane15 = new JSplitPane();
  JSplitPane jSplitPane16 = new JSplitPane();
  JSplitPane jSplitPane17 = new JSplitPane();
  JSplitPane jSplitPane18 = new JSplitPane();
  JSplitPane jSplitPane19 = new JSplitPane();
  JSplitPane jSplitPane20 = new JSplitPane();
  JSplitPane jSplitPane21 = new JSplitPane();
  JSplitPane jSplitPane22 = new JSplitPane();
  JSplitPane jSplitPane23 = new JSplitPane();
  JSplitPane jSplitPane24 = new JSplitPane();
  JSplitPane jSplitPane25 = new JSplitPane();
  JSplitPane jSplitPane26 = new JSplitPane();
  JSplitPane jSplitPane27 = new JSplitPane();
  JSplitPane jSplitPane28 = new JSplitPane();
  JSplitPane jSplitPane29 = new JSplitPane();
  JSplitPane jSplitPane30 = new JSplitPane();
  JSplitPane jSplitPane31 = new JSplitPane();
  JSplitPane jSplitPane32 = new JSplitPane();
  JSplitPane jSplitPane33 = new JSplitPane();
  JSplitPane jSplitPane34 = new JSplitPane();
  JSplitPane jSplitPane35 = new JSplitPane();
  JSplitPane jSplitPane36 = new JSplitPane();
  JSplitPane jSplitPane37 = new JSplitPane();
  JSplitPane jSplitPane38 = new JSplitPane();
  JSplitPane jSplitPane39 = new JSplitPane();
  JSplitPane jSplitPane40 = new JSplitPane();
  JSplitPane jSplitPane41 = new JSplitPane();
  JSplitPane jSplitPane42 = new JSplitPane();
  JSplitPane jSplitPane43 = new JSplitPane();
  JSplitPane jSplitPane44 = new JSplitPane();
  JSplitPane jSplitPane45 = new JSplitPane();
  JSplitPane jSplitPane46 = new JSplitPane();
  JSplitPane jSplitPane47 = new JSplitPane();
  JSplitPane jSplitPane48 = new JSplitPane();
  JSplitPane jSplitPane49 = new JSplitPane();
  JSplitPane jSplitPane50 = new JSplitPane();
  JSplitPane jSplitPane51 = new JSplitPane();
  JSplitPane jSplitPane52 = new JSplitPane();
  JSplitPane jSplitPane53 = new JSplitPane();
  JSplitPane jSplitPane54 = new JSplitPane();
  JSplitPane jSplitPane55 = new JSplitPane();
  JSplitPane jSplitPane56 = new JSplitPane();
  JSplitPane jSplitPane57 = new JSplitPane();
  JSplitPane jSplitPane58 = new JSplitPane();
  JSplitPane jSplitPane59 = new JSplitPane();
  JSplitPane jSplitPane60 = new JSplitPane();
  JSplitPane jSplitPane61 = new JSplitPane();
  JSplitPane jSplitPane62 = new JSplitPane();
  JSplitPane jSplitPane63 = new JSplitPane();
  JSplitPane jSplitPane64 = new JSplitPane();

  Box box1;
  Box box2;
  Box box3;
  Box box4;
  Box box5;
  Box box6;
  Box box7;
  Box box8;
  Box box9;
  Box box10;
  Box box11;
  Box box12;
  Box box13;
  Box box14;

  JPanel jPanel1 = new JPanel();
  JPanel jPanel2 = new JPanel();
  JPanel jPanel3 = new JPanel();
  JPanel jPanel4 = new JPanel();
  JPanel jPanel5 = new JPanel();

  //a�adimos los label para mostrar el ataque y defensa de las cartas de criatura
  JLabel labelAtaque1 = new JLabel();
  JLabel labelDefensa1 = new JLabel();
  JLabel labelAtaque2 = new JLabel();
  JLabel labelDefensa2 = new JLabel();
  JLabel labelAtaque3 = new JLabel();
  JLabel labelDefensa3 = new JLabel();
  JLabel labelAtaque4 = new JLabel();
  JLabel labelDefensa4 = new JLabel();
  JLabel labelAtaque5 = new JLabel();
  JLabel labelDefensa5 = new JLabel();
  JLabel labelAtaque6 = new JLabel();
  JLabel labelDefensa6 = new JLabel();
  JLabel labelAtaque7 = new JLabel();
  JLabel labelDefensa7 = new JLabel();
  JLabel labelAtaque8 = new JLabel();
  JLabel labelDefensa8 = new JLabel();
  JLabel labelAtaque9 = new JLabel();
  JLabel labelDefensa9 = new JLabel();
  JLabel labelAtaque10 = new JLabel();
  JLabel labelDefensa10 = new JLabel();
  JLabel labelAtaque11 = new JLabel();
  JLabel labelDefensa11 = new JLabel();
  JLabel labelAtaque12 = new JLabel();
  JLabel labelDefensa12 = new JLabel();
  JLabel labelAtaque13 = new JLabel();
  JLabel labelDefensa13 = new JLabel();
  JLabel labelAtaque14 = new JLabel();
  JLabel labelDefensa14 = new JLabel();

  //a�adimos los botones para el Servidor, Chat y Finalizar partida
  private JButton botonServidor = new JButton();
  private JButton botonChat = new JButton();
  private JButton botonFinalizar = new JButton();

  //a�adimos los botones del Mazo, Jugador y Contrario (representan las cartas, pero se tiene que cambiar por iconos con coordenadas)
  JButton botonMazo1 = new JButton();
  JButton botonMazo2 = new JButton();
  JButton botonMazo3 = new JButton();
  JButton botonMazo4 = new JButton();
  JButton botonMazo5 = new JButton();
  JButton botonMazo6 = new JButton();
  JButton botonMazo7 = new JButton();
  JButton botonMazo8 = new JButton();
  JButton botonJugador1 = new JButton();
  JButton botonJugador2 = new JButton();
  JButton botonJugador3 = new JButton();
  JButton botonJugador4 = new JButton();
  JButton botonJugador5 = new JButton();
  JButton botonJugador6 = new JButton();
  JButton botonJugador7 = new JButton();
  JButton botonJugador8 = new JButton();
  JButton botonJugador9 = new JButton();
  JButton botonJugador10 = new JButton();
  JButton botonJugador11 = new JButton();
  JButton botonJugador12 = new JButton();
  JButton botonJugador13 = new JButton();
  JButton botonJugador14 = new JButton();
  JButton botonJugador15 = new JButton();
  JButton botonJugador16 = new JButton();
  JButton botonJugador17 = new JButton();
  JButton botonJugador18 = new JButton();

  //variable para mostrar el menu PopUp
  private static JPopupMenu menuMazo;

  //variables para almacenar que bot�n hemos pulsado y su tipo( se tiene que cambiar cuando se metan las clases Carta,Mazo,...)
  static JButton botonActual = null;
  static boolean jugador = false;
  static boolean girada = true;
  static boolean mana = false;
  static boolean mazo = false;


  /**
   * Constructora de la clase
   */
  public tableroJuegoGUI() {
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  /**
   * Funci�n para inicializar los componentes del frame del tablero de juego
   * @throws java.lang.Exception
   */
  private void jbInit() throws Exception {

    box1 = Box.createHorizontalBox();
    box2 = Box.createHorizontalBox();
    box3 = Box.createHorizontalBox();
    box4 = Box.createHorizontalBox();
    box5 = Box.createHorizontalBox();
    box6 = Box.createHorizontalBox();
    box7 = Box.createHorizontalBox();
    box8 = Box.createHorizontalBox();
    box9 = Box.createHorizontalBox();
    box10 = Box.createHorizontalBox();
    box11 = Box.createHorizontalBox();
    box12 = Box.createHorizontalBox();
    box13 = Box.createHorizontalBox();
    box14 = Box.createHorizontalBox();

    jTabbedPane1.setPreferredSize(new Dimension(150, 50));
    this.setResizable(false);
    this.setState(Frame.NORMAL);
    this.setTitle("GENESIS version_1.0");
    this.addWindowListener(new java.awt.event.WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        this_windowClosing(e);
      }
    });

    this.setSize(1024,768);

//adaptamos el frame del tablero al tama�o maximo de la pantalla (con los SplitPane no se puede hacer de momento porque se desajusta)
//    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
//    this.setSize(screenSize.width, screenSize.height);

    //inicializamos el menu PopUp para poder "Usar" y "Visualizar" cada carta
    menuMazo = new JPopupMenu();
    JMenuItem iUsar = new JMenuItem("Usar");
    JMenuItem iVisualizar = new JMenuItem("Visualizar");
    menuMazo.add(iUsar);
    menuMazo.add(iVisualizar);

    //a�adimos los actionListener a los botones del tablero del jugador
    botonJugador1.addActionListener(new tableroJuegoGUI_botonJugador1_actionAdapter(this));
    botonJugador2.addActionListener(new tableroJuegoGUI_botonJugador2_actionAdapter(this));
    botonJugador3.addActionListener(new tableroJuegoGUI_botonJugador3_actionAdapter(this));
    botonJugador4.addActionListener(new tableroJuegoGUI_botonJugador4_actionAdapter(this));
    botonJugador5.addActionListener(new tableroJuegoGUI_botonJugador5_actionAdapter(this));
    botonJugador6.addActionListener(new tableroJuegoGUI_botonJugador6_actionAdapter(this));
    botonJugador9.addActionListener(new tableroJuegoGUI_botonJugador9_actionAdapter(this));
    botonJugador10.addActionListener(new tableroJuegoGUI_botonJugador10_actionAdapter(this));
    botonJugador12.addActionListener(new tableroJuegoGUI_botonJugador12_actionAdapter(this));
    botonJugador13.addActionListener(new tableroJuegoGUI_botonJugador13_actionAdapter(this));

    //impedimos que se pueda modificar el tama�o de los SplitPane
    jSplitPane1.setEnabled(false);
    jSplitPane2.setEnabled(false);
    jSplitPane5.setEnabled(false);
    jSplitPane4.setEnabled(false);
    jSplitPane3.setEnabled(false);
    jSplitPane6.setEnabled(false);
    jSplitPane7.setEnabled(false);
    jSplitPane8.setEnabled(false);
    jSplitPane9.setEnabled(false);
    jSplitPane10.setEnabled(false);
    jSplitPane13.setEnabled(false);
    jSplitPane14.setEnabled(false);
    jSplitPane11.setEnabled(false);
    jSplitPane12.setEnabled(false);
    jSplitPane15.setEnabled(false);
    jSplitPane16.setEnabled(false);
    jSplitPane17.setEnabled(false);
    jSplitPane18.setEnabled(false);
    jSplitPane19.setEnabled(false);
    jSplitPane20.setEnabled(false);
    jSplitPane21.setEnabled(false);
    jSplitPane22.setEnabled(false);
    jSplitPane23.setEnabled(false);
    jSplitPane24.setEnabled(false);
    jSplitPane25.setEnabled(false);
    jSplitPane26.setEnabled(false);
    jSplitPane27.setEnabled(false);
    jSplitPane28.setEnabled(false);
    jSplitPane29.setEnabled(false);
    jSplitPane30.setEnabled(false);
    jSplitPane31.setEnabled(false);
    jSplitPane32.setEnabled(false);
    jSplitPane33.setEnabled(false);
    jSplitPane34.setEnabled(false);
    jSplitPane35.setEnabled(false);
    jSplitPane36.setEnabled(false);
    jSplitPane37.setEnabled(false);
    jSplitPane38.setEnabled(false);
    jSplitPane39.setEnabled(false);
    jSplitPane40.setEnabled(false);
    jSplitPane41.setEnabled(false);
    jSplitPane42.setEnabled(false);
    jSplitPane43.setEnabled(false);
    jSplitPane44.setEnabled(false);
    jSplitPane45.setEnabled(false);
    jSplitPane46.setEnabled(false);
    jSplitPane47.setEnabled(false);
    jSplitPane48.setEnabled(false);
    jSplitPane49.setEnabled(false);
    jSplitPane50.setEnabled(false);
    jSplitPane51.setEnabled(false);
    jSplitPane52.setEnabled(false);
    jSplitPane53.setEnabled(false);
    jSplitPane54.setEnabled(false);
    jSplitPane55.setEnabled(false);
    jSplitPane56.setEnabled(false);
    jSplitPane57.setEnabled(false);
    jSplitPane58.setEnabled(false);
    jSplitPane59.setEnabled(false);
    jSplitPane60.setEnabled(false);
    jSplitPane61.setEnabled(false);
    jSplitPane62.setEnabled(false);
    jSplitPane63.setEnabled(false);
    jSplitPane64.setEnabled(false);


    panelJugador.setLayout(borderLayout1);
    panelContrario.setLayout(borderLayout2);
    panelMazo.setLayout(borderLayout3);

    //colocamos y dimensionamos los SplitPane del tablero
    jSplitPane1.setOrientation(JSplitPane.HORIZONTAL_SPLIT);
    jSplitPane5.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane6.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane6.setDividerSize(5);
    jSplitPane7.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane3.setOrientation(JSplitPane.HORIZONTAL_SPLIT);
    jSplitPane8.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane9.setOrientation(JSplitPane.HORIZONTAL_SPLIT);
    jSplitPane13.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane14.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane10.setOrientation(JSplitPane.HORIZONTAL_SPLIT);
    jSplitPane15.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane16.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane11.setOrientation(JSplitPane.HORIZONTAL_SPLIT);
    jSplitPane17.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane19.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane21.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane23.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane25.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane27.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane28.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane20.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane29.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane30.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane31.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane22.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane32.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane24.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane33.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane34.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane26.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane35.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane36.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane18.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane37.setOrientation(JSplitPane.HORIZONTAL_SPLIT);
    jSplitPane41.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane42.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane38.setOrientation(JSplitPane.HORIZONTAL_SPLIT);
    jSplitPane43.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane44.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane45.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane39.setOrientation(JSplitPane.HORIZONTAL_SPLIT);
    jSplitPane47.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane49.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane51.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane53.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane54.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane55.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane56.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane57.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane46.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane58.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane59.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane48.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane60.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane61.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane50.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane62.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane63.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane52.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane64.setOrientation(JSplitPane.VERTICAL_SPLIT);

    //inicializamos los label de ataque y defensa de las cartas
    labelAtaque1.setFont(new java.awt.Font("Dialog", 0, 20));
    labelAtaque1.setForeground(Color.red);
    labelAtaque1.setText("ATAQUE");
    labelAtaque1.setVerticalAlignment(SwingConstants.CENTER);
    labelDefensa1.setFont(new java.awt.Font("Dialog", 0, 20));
    labelDefensa1.setForeground(Color.green);
    labelDefensa1.setToolTipText("");
    labelDefensa1.setHorizontalAlignment(SwingConstants.LEADING);
    labelDefensa1.setHorizontalTextPosition(SwingConstants.TRAILING);
    labelDefensa1.setText("DEFENSA");
    labelDefensa1.setVerticalAlignment(SwingConstants.CENTER);
    labelDefensa1.setVerticalTextPosition(SwingConstants.CENTER);
    labelAtaque2.setVerticalAlignment(SwingConstants.CENTER);
    labelAtaque2.setText("ATAQUE");
    labelAtaque2.setForeground(Color.red);
    labelAtaque2.setFont(new java.awt.Font("Dialog", 0, 20));
    labelDefensa2.setVerticalTextPosition(SwingConstants.CENTER);
    labelDefensa2.setVerticalAlignment(SwingConstants.CENTER);
    labelDefensa2.setText("DEFENSA");
    labelDefensa2.setHorizontalTextPosition(SwingConstants.TRAILING);
    labelDefensa2.setHorizontalAlignment(SwingConstants.LEADING);
    labelDefensa2.setToolTipText("");
    labelDefensa2.setForeground(Color.green);
    labelDefensa2.setFont(new java.awt.Font("Dialog", 0, 20));
    labelAtaque3.setFont(new java.awt.Font("Dialog", 0, 20));
    labelAtaque3.setForeground(Color.red);
    labelAtaque3.setText("ATAQUE");
    labelAtaque3.setVerticalAlignment(SwingConstants.CENTER);
    labelDefensa3.setFont(new java.awt.Font("Dialog", 0, 20));
    labelDefensa3.setForeground(Color.green);
    labelDefensa3.setToolTipText("");
    labelDefensa3.setHorizontalAlignment(SwingConstants.LEADING);
    labelDefensa3.setHorizontalTextPosition(SwingConstants.TRAILING);
    labelDefensa3.setText("DEFENSA");
    labelDefensa3.setVerticalAlignment(SwingConstants.CENTER);
    labelDefensa3.setVerticalTextPosition(SwingConstants.CENTER);
    labelAtaque4.setFont(new java.awt.Font("Dialog", 0, 20));
    labelAtaque4.setForeground(Color.red);
    labelAtaque4.setText("ATAQUE");
    labelAtaque4.setVerticalAlignment(SwingConstants.CENTER);
    labelDefensa4.setFont(new java.awt.Font("Dialog", 0, 20));
    labelDefensa4.setForeground(Color.green);
    labelDefensa4.setToolTipText("");
    labelDefensa4.setHorizontalAlignment(SwingConstants.LEADING);
    labelDefensa4.setHorizontalTextPosition(SwingConstants.TRAILING);
    labelDefensa4.setText("DEFENSA");
    labelDefensa4.setVerticalAlignment(SwingConstants.CENTER);
    labelDefensa4.setVerticalTextPosition(SwingConstants.CENTER);
    labelAtaque5.setFont(new java.awt.Font("Dialog", 0, 20));
    labelAtaque5.setForeground(Color.red);
    labelAtaque5.setText("ATAQUE");
    labelAtaque5.setVerticalAlignment(SwingConstants.CENTER);
    labelDefensa5.setFont(new java.awt.Font("Dialog", 0, 20));
    labelDefensa5.setForeground(Color.green);
    labelDefensa5.setToolTipText("");
    labelDefensa5.setHorizontalAlignment(SwingConstants.LEADING);
    labelDefensa5.setHorizontalTextPosition(SwingConstants.TRAILING);
    labelDefensa5.setText("DEFENSA");
    labelDefensa5.setVerticalAlignment(SwingConstants.CENTER);
    labelDefensa5.setVerticalTextPosition(SwingConstants.CENTER);
    labelAtaque6.setFont(new java.awt.Font("Dialog", 0, 20));
    labelAtaque6.setForeground(Color.red);
    labelAtaque6.setText("ATAQUE");
    labelAtaque6.setVerticalAlignment(SwingConstants.CENTER);
    labelDefensa6.setFont(new java.awt.Font("Dialog", 0, 20));
    labelDefensa6.setForeground(Color.green);
    labelDefensa6.setToolTipText("");
    labelDefensa6.setHorizontalAlignment(SwingConstants.LEADING);
    labelDefensa6.setHorizontalTextPosition(SwingConstants.TRAILING);
    labelDefensa6.setText("DEFENSA");
    labelDefensa6.setVerticalAlignment(SwingConstants.CENTER);
    labelDefensa6.setVerticalTextPosition(SwingConstants.CENTER);
    labelAtaque7.setFont(new java.awt.Font("Dialog", 0, 20));
    labelAtaque7.setForeground(Color.red);
    labelAtaque7.setText("ATAQUE");
    labelAtaque7.setVerticalAlignment(SwingConstants.CENTER);
    labelDefensa7.setFont(new java.awt.Font("Dialog", 0, 20));
    labelDefensa7.setForeground(Color.green);
    labelDefensa7.setToolTipText("");
    labelDefensa7.setHorizontalAlignment(SwingConstants.LEADING);
    labelDefensa7.setHorizontalTextPosition(SwingConstants.TRAILING);
    labelDefensa7.setText("DEFENSA");
    labelDefensa7.setVerticalAlignment(SwingConstants.CENTER);
    labelDefensa7.setVerticalTextPosition(SwingConstants.CENTER);
    labelAtaque8.setVerticalAlignment(SwingConstants.CENTER);
    labelAtaque8.setText("ATAQUE");
    labelAtaque8.setForeground(Color.red);
    labelAtaque8.setFont(new java.awt.Font("Dialog", 0, 20));
    labelDefensa8.setFont(new java.awt.Font("Dialog", 0, 20));
    labelDefensa8.setForeground(Color.green);
    labelDefensa8.setToolTipText("");
    labelDefensa8.setHorizontalAlignment(SwingConstants.LEADING);
    labelDefensa8.setHorizontalTextPosition(SwingConstants.TRAILING);
    labelDefensa8.setText("DEFENSA");
    labelDefensa8.setVerticalAlignment(SwingConstants.CENTER);
    labelDefensa8.setVerticalTextPosition(SwingConstants.CENTER);
    labelAtaque9.setVerticalAlignment(SwingConstants.CENTER);
    labelAtaque9.setText("ATAQUE");
    labelAtaque9.setForeground(Color.red);
    labelAtaque9.setFont(new java.awt.Font("Dialog", 0, 20));
    labelDefensa9.setFont(new java.awt.Font("Dialog", 0, 20));
    labelDefensa9.setForeground(Color.green);
    labelDefensa9.setToolTipText("");
    labelDefensa9.setHorizontalAlignment(SwingConstants.LEADING);
    labelDefensa9.setHorizontalTextPosition(SwingConstants.TRAILING);
    labelDefensa9.setText("DEFENSA");
    labelDefensa9.setVerticalAlignment(SwingConstants.CENTER);
    labelDefensa9.setVerticalTextPosition(SwingConstants.CENTER);
    labelAtaque10.setVerticalAlignment(SwingConstants.CENTER);
    labelAtaque10.setText("ATAQUE");
    labelAtaque10.setForeground(Color.red);
    labelAtaque10.setFont(new java.awt.Font("Dialog", 0, 20));
    labelDefensa10.setFont(new java.awt.Font("Dialog", 0, 20));
    labelDefensa10.setForeground(Color.green);
    labelDefensa10.setToolTipText("");
    labelDefensa10.setHorizontalAlignment(SwingConstants.LEADING);
    labelDefensa10.setHorizontalTextPosition(SwingConstants.TRAILING);
    labelDefensa10.setText("DEFENSA");
    labelDefensa10.setVerticalAlignment(SwingConstants.CENTER);
    labelDefensa10.setVerticalTextPosition(SwingConstants.CENTER);
    labelAtaque11.setVerticalAlignment(SwingConstants.CENTER);
    labelAtaque11.setText("ATAQUE");
    labelAtaque11.setForeground(Color.red);
    labelAtaque11.setFont(new java.awt.Font("Dialog", 0, 20));
    labelDefensa11.setFont(new java.awt.Font("Dialog", 0, 20));
    labelDefensa11.setForeground(Color.green);
    labelDefensa11.setToolTipText("");
    labelDefensa11.setHorizontalAlignment(SwingConstants.LEADING);
    labelDefensa11.setHorizontalTextPosition(SwingConstants.TRAILING);
    labelDefensa11.setText("DEFENSA");
    labelDefensa11.setVerticalAlignment(SwingConstants.CENTER);
    labelDefensa11.setVerticalTextPosition(SwingConstants.CENTER);
    labelAtaque12.setVerticalAlignment(SwingConstants.CENTER);
    labelAtaque12.setText("ATAQUE");
    labelAtaque12.setForeground(Color.red);
    labelAtaque12.setFont(new java.awt.Font("Dialog", 0, 20));
    labelDefensa12.setFont(new java.awt.Font("Dialog", 0, 20));
    labelDefensa12.setForeground(Color.green);
    labelDefensa12.setToolTipText("");
    labelDefensa12.setHorizontalAlignment(SwingConstants.LEADING);
    labelDefensa12.setHorizontalTextPosition(SwingConstants.TRAILING);
    labelDefensa12.setText("DEFENSA");
    labelDefensa12.setVerticalAlignment(SwingConstants.CENTER);
    labelDefensa12.setVerticalTextPosition(SwingConstants.CENTER);
    labelAtaque13.setVerticalAlignment(SwingConstants.CENTER);
    labelAtaque13.setText("ATAQUE");
    labelAtaque13.setForeground(Color.red);
    labelAtaque13.setFont(new java.awt.Font("Dialog", 0, 20));
    labelDefensa13.setFont(new java.awt.Font("Dialog", 0, 20));
    labelDefensa13.setForeground(Color.green);
    labelDefensa13.setToolTipText("");
    labelDefensa13.setHorizontalAlignment(SwingConstants.LEADING);
    labelDefensa13.setHorizontalTextPosition(SwingConstants.TRAILING);
    labelDefensa13.setText("DEFENSA");
    labelDefensa13.setVerticalAlignment(SwingConstants.CENTER);
    labelDefensa13.setVerticalTextPosition(SwingConstants.CENTER);
    labelAtaque14.setVerticalAlignment(SwingConstants.CENTER);
    labelAtaque14.setText("ATAQUE");
    labelAtaque14.setForeground(Color.red);
    labelAtaque14.setFont(new java.awt.Font("Dialog", 0, 20));
    labelDefensa14.setFont(new java.awt.Font("Dialog", 0, 20));
    labelDefensa14.setForeground(Color.green);
    labelDefensa14.setToolTipText("");
    labelDefensa14.setHorizontalAlignment(SwingConstants.LEADING);
    labelDefensa14.setHorizontalTextPosition(SwingConstants.TRAILING);
    labelDefensa14.setText("DEFENSA");
    labelDefensa14.setVerticalAlignment(SwingConstants.CENTER);
    labelDefensa14.setVerticalTextPosition(SwingConstants.CENTER);


   //a�adimos actionListener a los botones de Servidor de internet
    botonServidor.setText("Servidor de Internet");
    botonServidor.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        botonServidor_actionPerformed(e);
      }
    });
    //de sala de Chat
    botonChat.setText("Sala de Chat");
    botonChat.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        botonChat_actionPerformed(e);
      }
    });
    //y de Finalizar partida
    botonFinalizar.setText("Finalizar Partida");
    botonFinalizar.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        botonFinalizar_actionPerformed(e);
      }
    });

    //a�adimos los mouseListener a los botones del Mazo del jugador
    botonMazo1.setName("botonMazo1");
    botonMazo1.addMouseListener(new PopupListener());
    botonMazo2.setName("botonMazo2");
    botonMazo2.addMouseListener(new PopupListener());
    botonMazo3.setName("botonMazo3");
    botonMazo3.addMouseListener(new PopupListener());
    botonMazo4.setName("botonMazo4");
    botonMazo4.addMouseListener(new PopupListener());
    botonMazo5.setName("botonMazo5");
    botonMazo5.addMouseListener(new PopupListener());
    botonMazo6.setName("botonMazo6");
    botonMazo6.addMouseListener(new PopupListener());
    botonMazo7.setName("botonMazo7");
    botonMazo7.addMouseListener(new PopupListener());
    botonMazo8.setName("botonMazo8");
    botonMazo8.addMouseListener(new PopupListener());

    botonMazo1.addActionListener(new tableroJuegoGUI_botonMazo1_actionAdapter(this));
    botonMazo2.addActionListener(new tableroJuegoGUI_botonMazo2_actionAdapter(this));
    botonMazo3.addActionListener(new tableroJuegoGUI_botonMazo3_actionAdapter(this));
    botonMazo4.addActionListener(new tableroJuegoGUI_botonMazo4_actionAdapter(this));
    botonMazo5.addActionListener(new tableroJuegoGUI_botonMazo5_actionAdapter(this));
    botonMazo6.addActionListener(new tableroJuegoGUI_botonMazo6_actionAdapter(this));
    botonMazo7.addActionListener(new tableroJuegoGUI_botonMazo7_actionAdapter(this));
    botonMazo8.addActionListener(new tableroJuegoGUI_botonMazo8_actionAdapter(this));

    //a�adimos mouseListener a los botones del Tablero del jugador
    botonJugador1.addMouseListener(new PopupListener());
    botonJugador2.addMouseListener(new PopupListener());
    botonJugador3.addMouseListener(new PopupListener());
    botonJugador4.addMouseListener(new PopupListener());
    botonJugador5.addMouseListener(new PopupListener());
    botonJugador6.addMouseListener(new PopupListener());
    botonJugador7.addMouseListener(new PopupListener());
    botonJugador8.addMouseListener(new PopupListener());
    botonJugador9.addMouseListener(new PopupListener());
    botonJugador10.addMouseListener(new PopupListener());
    botonJugador11.addMouseListener(new PopupListener());
    botonJugador12.addMouseListener(new PopupListener());
    botonJugador13.addMouseListener(new PopupListener());
    botonJugador14.addMouseListener(new PopupListener());
    botonJugador15.addMouseListener(new PopupListener());
    botonJugador16.addMouseListener(new PopupListener());
    botonJugador17.addMouseListener(new PopupListener());
    botonJugador18.addMouseListener(new PopupListener());

//a�adimos mouseListener a los botones del Tablero del contrario
//    botonContrario1.addMouseListener(new PopupListener(botonContrario1));
//    botonContrario2.addMouseListener(new PopupListener(botonContrario2));
//    botonContrario3.addMouseListener(new PopupListener(botonContrario3));
//    botonContrario4.addMouseListener(new PopupListener(botonContrario4));
//    botonContrario5.addMouseListener(new PopupListener(botonContrario5));
//    botonContrario6.addMouseListener(new PopupListener(botonContrario6));
//    botonContrario7.addMouseListener(new PopupListener(botonContrario7));
//    botonContrario8.addMouseListener(new PopupListener(botonContrario8));
//    botonContrario9.addMouseListener(new PopupListener(botonContrario9));
//    botonContrario10.addMouseListener(new PopupListener(botonContrario10));
//    botonContrario11.addMouseListener(new PopupListener(botonContrario11));
//    botonContrario12.addMouseListener(new PopupListener(botonContrario12));
//    botonContrario13.addMouseListener(new PopupListener(botonContrario13));
//    botonContrario14.addMouseListener(new PopupListener(botonContrario14));
//    botonContrario15.addMouseListener(new PopupListener(botonContrario15));
//    botonContrario16.addMouseListener(new PopupListener(botonContrario16));
//    botonContrario17.addMouseListener(new PopupListener(botonContrario17));
//    botonContrario18.addMouseListener(new PopupListener(botonContrario18));


    //a�adimos los actionListener a las opciones "Usar" y "Visualizar" del menu PopUp
    iUsar.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        iUsar_actionPerformed(e);
      }
    });

    iVisualizar.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        iVisualizar_actionPerformed(e);
      }
    });


    this.getContentPane().add(jTabbedPane1, BorderLayout.CENTER);


    //inicializamos el tablero de la Mesa del jugador
    jTabbedPane1.add(panelJugador, "MESA JUGADOR");
    panelJugador.add(jSplitPane9, BorderLayout.CENTER);

    jSplitPane9.add(jSplitPane10, JSplitPane.TOP);
    jSplitPane10.add(jSplitPane13, JSplitPane.TOP);
    jSplitPane13.add(jSplitPane18, JSplitPane.TOP);
    jSplitPane18.add(jSplitPane35, JSplitPane.LEFT);
    jSplitPane35.add(jPanel1, JSplitPane.BOTTOM);
    jSplitPane35.add(botonJugador1, JSplitPane.TOP);
    jSplitPane18.add(jSplitPane36, JSplitPane.RIGHT);
    jSplitPane36.add(jPanel2, JSplitPane.BOTTOM);
    jSplitPane36.add(botonJugador2, JSplitPane.TOP);
    jSplitPane13.add(jSplitPane19, JSplitPane.BOTTOM);
    jSplitPane19.add(botonJugador3, JSplitPane.TOP);
    jSplitPane19.add(botonJugador4, JSplitPane.BOTTOM);
    jSplitPane10.add(jSplitPane14, JSplitPane.BOTTOM);
    jSplitPane14.add(jSplitPane20, JSplitPane.TOP);
    jSplitPane20.add(jSplitPane28, JSplitPane.LEFT);
    jSplitPane28.add(box2, JSplitPane.BOTTOM);
    box2.add(labelAtaque1, null);
    box2.add(labelDefensa1, null);
    jSplitPane20.add(jSplitPane29, JSplitPane.RIGHT);
    jSplitPane29.add(box4, JSplitPane.BOTTOM);
    jSplitPane14.add(jSplitPane21, JSplitPane.BOTTOM);
    jSplitPane21.add(botonJugador12, JSplitPane.TOP);
    jSplitPane21.add(botonJugador16, JSplitPane.BOTTOM);
    jSplitPane9.add(jSplitPane11, JSplitPane.BOTTOM);
    jSplitPane11.add(jSplitPane12, JSplitPane.TOP);
    jSplitPane12.add(jSplitPane15, JSplitPane.LEFT);
    jSplitPane15.add(jSplitPane22, JSplitPane.TOP);
    jSplitPane22.add(jSplitPane30, JSplitPane.LEFT);
    jSplitPane30.add(box3, JSplitPane.BOTTOM);
    jSplitPane22.add(jSplitPane31, JSplitPane.RIGHT);
    jSplitPane31.add(box7, JSplitPane.BOTTOM);
    jSplitPane15.add(jSplitPane23, JSplitPane.BOTTOM);
    jSplitPane23.add(botonJugador13, JSplitPane.TOP);
    jSplitPane23.add(botonJugador17, JSplitPane.BOTTOM);
    jSplitPane12.add(jSplitPane16, JSplitPane.RIGHT);
    jSplitPane16.add(jSplitPane24, JSplitPane.TOP);
    jSplitPane24.add(jSplitPane32, JSplitPane.LEFT);
    jSplitPane32.add(box5, JSplitPane.BOTTOM);
    jSplitPane24.add(jSplitPane33, JSplitPane.RIGHT);
    jSplitPane33.add(box8, JSplitPane.BOTTOM);
    jSplitPane16.add(jSplitPane25, JSplitPane.BOTTOM);
    jSplitPane25.add(botonJugador14, JSplitPane.TOP);
    jSplitPane25.add(botonJugador18, JSplitPane.BOTTOM);
    jSplitPane11.add(jSplitPane17, JSplitPane.BOTTOM);
    jSplitPane17.add(jSplitPane26, JSplitPane.TOP);
    jSplitPane26.add(jSplitPane34, JSplitPane.LEFT);
    jSplitPane34.add(box6, JSplitPane.BOTTOM);
    jSplitPane17.add(jSplitPane27, JSplitPane.BOTTOM);
    jSplitPane27.add(botonJugador15, JSplitPane.TOP);


    //inicializamos el tablero de la Mesa del contrario
    jTabbedPane1.add(panelContrario, "MESA CONTRARIO");
    panelContrario.add(jSplitPane37, BorderLayout.CENTER);

    jSplitPane37.add(jSplitPane38, JSplitPane.TOP);
    jSplitPane38.add(jSplitPane41, JSplitPane.TOP);
    jSplitPane41.add(jSplitPane46, JSplitPane.TOP);
    jSplitPane46.add(jSplitPane56, JSplitPane.LEFT);
    jSplitPane56.add(jPanel3, JSplitPane.BOTTOM);
    jSplitPane46.add(jSplitPane57, JSplitPane.RIGHT);
    jSplitPane57.add(jPanel4, JSplitPane.BOTTOM);
    jSplitPane41.add(jSplitPane47, JSplitPane.BOTTOM);
    jSplitPane38.add(jSplitPane42, JSplitPane.BOTTOM);
    jSplitPane42.add(jSplitPane48, JSplitPane.TOP);
    jSplitPane48.add(jSplitPane58, JSplitPane.LEFT);
    jSplitPane58.add(box1, JSplitPane.BOTTOM);
    box1.add(labelAtaque8, null);
    box1.add(labelDefensa8, null);
    jSplitPane48.add(jSplitPane59, JSplitPane.RIGHT);
    jSplitPane59.add(box9, JSplitPane.BOTTOM);
    box9.add(labelAtaque12, null);
    box9.add(labelDefensa12, null);
    jSplitPane42.add(jSplitPane49, JSplitPane.BOTTOM);
    jSplitPane37.add(jSplitPane39, JSplitPane.BOTTOM);
    jSplitPane39.add(jSplitPane40, JSplitPane.TOP);
    jSplitPane40.add(jSplitPane43, JSplitPane.LEFT);
    jSplitPane43.add(jSplitPane50, JSplitPane.TOP);
    jSplitPane50.add(jSplitPane60, JSplitPane.LEFT);
    jSplitPane60.add(box10, JSplitPane.BOTTOM);
    box10.add(labelAtaque9, null);
    box10.add(labelDefensa9, null);
    jSplitPane50.add(jSplitPane61, JSplitPane.RIGHT);
    jSplitPane61.add(box11, JSplitPane.BOTTOM);
    box11.add(labelAtaque13, null);
    box11.add(labelDefensa13, null);
    jSplitPane43.add(jSplitPane51, JSplitPane.BOTTOM);
    jSplitPane40.add(jSplitPane44, JSplitPane.RIGHT);
    jSplitPane44.add(jSplitPane52, JSplitPane.TOP);
    jSplitPane52.add(jSplitPane62, JSplitPane.LEFT);
    jSplitPane62.add(box12, JSplitPane.BOTTOM);
    box12.add(labelAtaque10, null);
    box12.add(labelDefensa10, null);
    jSplitPane52.add(jSplitPane63, JSplitPane.RIGHT);
    jSplitPane63.add(box13, JSplitPane.BOTTOM);
    box13.add(labelAtaque14, null);
    box13.add(labelDefensa14, null);
    jSplitPane44.add(jSplitPane53, JSplitPane.BOTTOM);
    jSplitPane39.add(jSplitPane45, JSplitPane.BOTTOM);
    jSplitPane45.add(jSplitPane54, JSplitPane.TOP);
    jSplitPane54.add(jSplitPane64, JSplitPane.TOP);
    jSplitPane64.add(box14, JSplitPane.BOTTOM);
    box14.add(labelAtaque11, null);
    box14.add(labelDefensa11, null);
    jSplitPane45.add(jSplitPane55, JSplitPane.BOTTOM);

    //inicializamos el tablero de la Mazo del jugador
    jTabbedPane1.add(panelMazo, "MAZO");
    panelMazo.add(jSplitPane1, BorderLayout.CENTER);

    jSplitPane1.add(jSplitPane2, JSplitPane.TOP);
    jSplitPane2.add(jSplitPane5, JSplitPane.RIGHT);
    jSplitPane5.add(botonMazo1, JSplitPane.TOP);
    jSplitPane5.add(botonMazo5, JSplitPane.BOTTOM);
    jSplitPane2.add(jPanel5, JSplitPane.LEFT);
    jPanel5.add(botonServidor, null);
    jPanel5.add(botonChat, null);
    jPanel5.add(botonFinalizar, null);
    jSplitPane1.add(jSplitPane3, JSplitPane.BOTTOM);
    jSplitPane3.add(jSplitPane4, JSplitPane.TOP);
    jSplitPane4.add(jSplitPane6, JSplitPane.LEFT);
    jSplitPane6.add(botonMazo2, JSplitPane.TOP);
    jSplitPane6.add(botonMazo6, JSplitPane.BOTTOM);
    jSplitPane4.add(jSplitPane7, JSplitPane.RIGHT);
    jSplitPane7.add(botonMazo3, JSplitPane.TOP);
    jSplitPane7.add(botonMazo7, JSplitPane.BOTTOM);
    jSplitPane3.add(jSplitPane8, JSplitPane.BOTTOM);
    jSplitPane8.add(botonMazo4, JSplitPane.TOP);
    jSplitPane8.add(botonMazo8, JSplitPane.BOTTOM);


    box3.add(labelAtaque2, null);
    box3.add(labelDefensa2, null);
    box5.add(labelAtaque3, null);
    box5.add(labelDefensa3, null);
    box6.add(labelAtaque4, null);
    box6.add(labelDefensa4, null);
    box4.add(labelAtaque5, null);
    box4.add(labelDefensa5, null);
    box7.add(labelAtaque6, null);
    box7.add(labelDefensa6, null);
    box8.add(labelAtaque7, null);
    box8.add(labelDefensa7, null);

    jSplitPane33.add(botonJugador11, JSplitPane.TOP);
    jSplitPane28.add(botonJugador5, JSplitPane.TOP);
    jSplitPane30.add(botonJugador6, JSplitPane.TOP);
    jSplitPane32.add(botonJugador7, JSplitPane.TOP);
    jSplitPane34.add(botonJugador8, JSplitPane.TOP);
    jSplitPane29.add(botonJugador9, JSplitPane.TOP);
    jSplitPane31.add(botonJugador10, JSplitPane.TOP);

    //colocamos los divisores de los SplitPane
    jSplitPane1.setDividerLocation(400);
    jSplitPane2.setDividerLocation(200);
    jSplitPane3.setDividerLocation(400);
    jSplitPane4.setDividerLocation(200);
    jSplitPane5.setDividerLocation(360);
    jSplitPane6.setDividerLocation(360);
    jSplitPane7.setDividerLocation(360);
    jSplitPane8.setDividerLocation(360);
    jSplitPane9.setDividerLocation(400);
    jSplitPane10.setDividerLocation(200);
    jSplitPane11.setDividerLocation(400);
    jSplitPane12.setDividerLocation(200);
    jSplitPane13.setDividerLocation(408);
    jSplitPane14.setDividerLocation(408);
    jSplitPane15.setDividerLocation(408);
    jSplitPane16.setDividerLocation(408);
    jSplitPane18.setDividerLocation(210);
    jSplitPane19.setDividerLocation(150);
    jSplitPane20.setDividerLocation(210);
    jSplitPane21.setDividerLocation(150);
    jSplitPane22.setDividerLocation(210);
    jSplitPane23.setDividerLocation(150);
    jSplitPane24.setDividerLocation(210);
    jSplitPane25.setDividerLocation(150);
    jSplitPane26.setDividerLocation(210);
    jSplitPane27.setDividerLocation(150);
    jSplitPane28.setDividerLocation(170);
    jSplitPane29.setDividerLocation(150);
    jSplitPane30.setDividerLocation(170);
    jSplitPane31.setDividerLocation(150);
    jSplitPane32.setDividerLocation(170);
    jSplitPane33.setDividerLocation(150);
    jSplitPane34.setDividerLocation(170);
    jSplitPane17.setDividerLocation(408);
    jSplitPane35.setDividerLocation(170);
    jSplitPane36.setDividerLocation(150);
    jSplitPane37.setDividerLocation(400);
    jSplitPane38.setDividerLocation(200);
    jSplitPane39.setDividerLocation(400);
    jSplitPane40.setDividerLocation(200);
    jSplitPane41.setDividerLocation(408);
    jSplitPane42.setDividerLocation(408);
    jSplitPane43.setDividerLocation(408);
    jSplitPane44.setDividerLocation(408);
    jSplitPane45.setDividerLocation(408);
    jSplitPane46.setDividerLocation(210);
    jSplitPane47.setDividerLocation(150);
    jSplitPane48.setDividerLocation(210);
    jSplitPane49.setDividerLocation(150);
    jSplitPane50.setDividerLocation(210);
    jSplitPane51.setDividerLocation(150);
    jSplitPane52.setDividerLocation(210);
    jSplitPane53.setDividerLocation(150);
    jSplitPane54.setDividerLocation(210);
    jSplitPane55.setDividerLocation(150);
    jSplitPane56.setDividerLocation(170);
    jSplitPane57.setDividerLocation(150);
    jSplitPane58.setDividerLocation(170);
    jSplitPane59.setDividerLocation(150);
    jSplitPane60.setDividerLocation(170);
    jSplitPane61.setDividerLocation(150);
    jSplitPane62.setDividerLocation(170);
    jSplitPane63.setDividerLocation(150);
    jSplitPane64.setDividerLocation(170);
  }

  /**
   *
   * @param e
   */
  abstract void botonServidor_actionPerformed(ActionEvent e);

  abstract void botonChat_actionPerformed(ActionEvent e);

  abstract void botonFinalizar_actionPerformed(ActionEvent e);

  /**
   *
   * @param e
   */
  abstract void botonMazo1_actionPerformed(ActionEvent e);

  abstract void botonMazo2_actionPerformed(ActionEvent e);

  abstract void botonMazo3_actionPerformed(ActionEvent e);

  abstract void botonMazo4_actionPerformed(ActionEvent e);

  abstract void botonMazo5_actionPerformed(ActionEvent e);

  abstract void botonMazo6_actionPerformed(ActionEvent e);

  abstract void botonMazo7_actionPerformed(ActionEvent e);

  abstract void botonMazo8_actionPerformed(ActionEvent e);

  /**
   *
   * @param e
   */
  abstract void botonJugador1_actionPerformed(ActionEvent e);

  abstract void botonJugador2_actionPerformed(ActionEvent e);

  abstract void botonJugador3_actionPerformed(ActionEvent e);

  abstract void botonJugador4_actionPerformed(ActionEvent e);

  abstract void botonJugador5_actionPerformed(ActionEvent e);

  abstract void botonJugador6_actionPerformed(ActionEvent e);

  abstract void botonJugador9_actionPerformed(ActionEvent e);

  abstract void botonJugador10_actionPerformed(ActionEvent e);

  abstract void botonJugador12_actionPerformed(ActionEvent e);

  abstract void botonJugador13_actionPerformed(ActionEvent e);

  /**
   *
   * @param e
   */
  abstract void iUsar_actionPerformed(ActionEvent e);

  /**
   *
   * @param e
   */
  abstract void iVisualizar_actionPerformed(ActionEvent e);

  abstract void this_windowClosing(WindowEvent e);




//************************************************************//
//***************CLASE PRIVADA DE MENU POPUP******************//
//************************************************************//

   /**
    *
    * <p>T�tulo: GENESIS</p>
    * <p>Descripci�n: Clase privada del menu popup</p>
    * <p>Copyright: Copyright (c) 2004</p>
    * <p>Empresa: </p>
    * @author Rui Miguel
    * @version 1.0
    */
    private static class PopupListener extends MouseAdapter{

      public void mousePressed(MouseEvent e){
        maybeShowPopup(e);
      }

      public void maybeShowPopup(MouseEvent e){
          menuMazo.show(e.getComponent(), e.getX(), e.getY());
      }
    }

}


//***********************************************
//***********************************************
//***********************************************
//***********************************************
//clases para representar los actionAdapter (hay que separar estos archivos,solo est�n los de botonMazo de momento)



class tableroJuegoGUI_botonJugador5_actionAdapter implements java.awt.event.ActionListener {
  tableroJuegoGUI adaptee;

  tableroJuegoGUI_botonJugador5_actionAdapter(tableroJuegoGUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.botonJugador5_actionPerformed(e);
  }
}

class tableroJuegoGUI_botonJugador6_actionAdapter implements java.awt.event.ActionListener {
  tableroJuegoGUI adaptee;

  tableroJuegoGUI_botonJugador6_actionAdapter(tableroJuegoGUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.botonJugador6_actionPerformed(e);
  }
}

class tableroJuegoGUI_botonJugador9_actionAdapter implements java.awt.event.ActionListener {
  tableroJuegoGUI adaptee;

  tableroJuegoGUI_botonJugador9_actionAdapter(tableroJuegoGUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.botonJugador9_actionPerformed(e);
  }
}

class tableroJuegoGUI_botonJugador10_actionAdapter implements java.awt.event.ActionListener {
  tableroJuegoGUI adaptee;

  tableroJuegoGUI_botonJugador10_actionAdapter(tableroJuegoGUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.botonJugador10_actionPerformed(e);
  }
}

class tableroJuegoGUI_botonJugador3_actionAdapter implements java.awt.event.ActionListener {
  tableroJuegoGUI adaptee;

  tableroJuegoGUI_botonJugador3_actionAdapter(tableroJuegoGUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.botonJugador3_actionPerformed(e);
  }
}

class tableroJuegoGUI_botonJugador4_actionAdapter implements java.awt.event.ActionListener {
  tableroJuegoGUI adaptee;

  tableroJuegoGUI_botonJugador4_actionAdapter(tableroJuegoGUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.botonJugador4_actionPerformed(e);
  }
}

class tableroJuegoGUI_botonJugador1_actionAdapter implements java.awt.event.ActionListener {
  tableroJuegoGUI adaptee;

  tableroJuegoGUI_botonJugador1_actionAdapter(tableroJuegoGUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.botonJugador1_actionPerformed(e);
  }
}

class tableroJuegoGUI_botonJugador2_actionAdapter implements java.awt.event.ActionListener {
  tableroJuegoGUI adaptee;

  tableroJuegoGUI_botonJugador2_actionAdapter(tableroJuegoGUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.botonJugador2_actionPerformed(e);
  }
}

class tableroJuegoGUI_botonJugador12_actionAdapter implements java.awt.event.ActionListener {
  tableroJuegoGUI adaptee;

  tableroJuegoGUI_botonJugador12_actionAdapter(tableroJuegoGUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.botonJugador12_actionPerformed(e);
  }
}

class tableroJuegoGUI_botonJugador13_actionAdapter implements java.awt.event.ActionListener {
  tableroJuegoGUI adaptee;

  tableroJuegoGUI_botonJugador13_actionAdapter(tableroJuegoGUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.botonJugador13_actionPerformed(e);
  }
}




