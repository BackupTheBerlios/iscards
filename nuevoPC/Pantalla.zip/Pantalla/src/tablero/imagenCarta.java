package tablero;

import java.awt.image.ImageObserver;
import java.awt.image.ImageProducer;
import java.awt.Image;
import java.awt.Graphics;

/**
 * <p>T�tulo: GENESIS</p>
 * <p>Descripci�n: Clase para representar las imagenes de las cartas</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Empresa: </p>
 * @author Rui Miguel
 * @version 1.0
 */

public class imagenCarta extends Image{

/******************************************
/******************************************
//De momento no se usa,hay que conseguir que las imagenes se redimensionen sin problemas
/******************************************
/******************************************


  /**
   * Variable para almacenar la imagen de la carta
   */
  String imagen;

  /**
   * Constructora de la clase
   */
  public imagenCarta() {
  }

  /**
   *
   * @param filename
   */
  public imagenCarta(String filename){
    imagen= filename;
  }

  /**
   *
   */
  public void flush(){

  }

  /**
   *
   * @return
   */
  public Graphics getGraphics(){
    return null;
  }

  /**
   *
   * @param observer
   * @return
   */
  public int getHeight(ImageObserver observer){
    return  observer.HEIGHT;
  }

  /**
   *
   * @param observer
   * @return
   */
  public int getWidth(ImageObserver observer){
    return observer.WIDTH;
  }

  /**
   *
   * @param name
   * @param observer
   * @return
   */
  public Object getProperty(String name, ImageObserver observer){
    return null;
  }
/*
  public Image getScaledInstance(int widht, int height, int hints){

  }
*/

  /**
   *
   * @return
   */
  public ImageProducer getSource(){
    return null;
  }

}