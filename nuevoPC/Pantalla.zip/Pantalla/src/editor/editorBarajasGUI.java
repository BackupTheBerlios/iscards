package editor;

import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.awt.*;
import java.awt.event.*;

/**
 * <p>T�tulo: GENESIS</p>
 * <p>Descripci�n: Interfaz Gr�fico del Editor de barajas del jugador</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Empresa: </p>
 * @author Rui Miguel
 * @version 1.0
 */

abstract public class editorBarajasGUI extends JFrame{
  JPanel jPanel1 = new JPanel();
  XYLayout xYLayout1 = new XYLayout();
  JLabel labelNombreBaraja = new JLabel();
  JTextField textNombreBaraja = new JTextField();
  JLabel labelCartas = new JLabel();
  JButton botonGuardar = new JButton();
  JButton botonAceptar = new JButton();
  JLabel labelCartasSelec = new JLabel();
  JButton botonCargar = new JButton();
  JScrollPane jScrollPane1 = new JScrollPane();
  JScrollPane jScrollPane2 = new JScrollPane();
  JList listSeleccionadas = new JList();
  JList listDisponibles = new JList();

  /**
   * Constructora de la clase
   */
  public editorBarajasGUI() {
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  /**
   * Funci�n de inicializaci�n del frame del Editor de barajas
   * @throws java.lang.Exception
   */
  private void jbInit() throws Exception {
    this.setLocale(java.util.Locale.getDefault());
    this.setResizable(false);
    jPanel1.setLayout(xYLayout1);
    this.setSize(new Dimension(505, 511));
    this.addWindowListener(new editorBarajasGUI_this_windowAdapter(this));

    labelNombreBaraja.setFont(new java.awt.Font("Dialog", 0, 20));
    labelNombreBaraja.setText("Nombre de la Baraja");
    labelCartas.setFont(new java.awt.Font("Dialog", 0, 20));
    labelCartas.setText("Cartas Disponibles");
    botonGuardar.setText("Guardar Baraja");
    botonGuardar.addActionListener(new editorBarajasGUI_botonGuardar_actionAdapter(this));
    botonAceptar.setText("Aceptar");
    botonAceptar.addActionListener(new editorBarajasGUI_botonAceptar_actionAdapter(this));
    textNombreBaraja.setText("");

    jPanel1.setMinimumSize(new Dimension(370, 500));
    jPanel1.setPreferredSize(new Dimension(370, 500));
    labelCartasSelec.setText("Cartas Seleccionadas");
    labelCartasSelec.setFont(new java.awt.Font("Dialog", 0, 20));
    botonCargar.setText("Cargar Baraja");
    botonCargar.addActionListener(new editorBarajasGUI_botonCargar_actionAdapter(this));


    listSeleccionadas.addMouseListener(new editorBarajasGUI_listSeleccionadas_mouseAdapter(this));
    listDisponibles.addMouseListener(new editorBarajasGUI_listDisponibles_mouseAdapter(this));
    jPanel1.add(textNombreBaraja,  new XYConstraints(28, 77, 175, 30));
    jPanel1.add(labelNombreBaraja,   new XYConstraints(27, 26, 188, 30));
    this.getContentPane().add(jPanel1, BorderLayout.SOUTH);
    jPanel1.add(labelCartasSelec,  new XYConstraints(30, 145, 202, 30));
    jPanel1.add(labelCartas, new XYConstraints(278, 145, 202, 30));
    jPanel1.add(botonGuardar, new XYConstraints(229, 35, -1, -1));
    jPanel1.add(botonCargar,  new XYConstraints(361, 35, -1, -1));
    jPanel1.add(botonAceptar, new XYConstraints(228, 81, -1, -1));
    jPanel1.add(jScrollPane1,    new XYConstraints(272, 179, 195, 279));
    jScrollPane1.getViewport().add(listDisponibles, null);
    jPanel1.add(jScrollPane2, new XYConstraints(35, 179, 199, 282));
    jScrollPane2.getViewport().add(listSeleccionadas, null);
  }

  /**
   *
   * @param e
   */
  abstract void listSeleccionadas_mouseClicked(MouseEvent e);

  /**
   *
   * @param e
   */
  abstract void listDisponibles_mouseClicked(MouseEvent e);

  /**
   *
   * @param e
   */
  abstract void botonGuardar_actionPerformed(ActionEvent e);

  /**
   *
   * @param e
   */
  abstract void botonCargar_actionPerformed(ActionEvent e);

  /**
   *
   * @param e
   */
  abstract void botonAceptar_actionPerformed(ActionEvent e);

  /**
   *
   * @param e
   */
  abstract void this_windowClosing(WindowEvent e);
}