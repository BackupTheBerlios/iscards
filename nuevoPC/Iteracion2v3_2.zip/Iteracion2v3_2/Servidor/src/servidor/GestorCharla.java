package servidor;

import java.io.*;
import java.net.*;
import java.util.Vector;
import java.util.StringTokenizer;

/**
 * Clase que espera mensajes de los clientes, se crea un hilo por cada cliente
 * @author Manuel Domingo Mora Martinez
 * @version 1.0
 */

class GestorCharla
    extends Thread {

  /**
   * Clase para gestionar las salas
   */
  private GestorUsuarios gestorUsuarios;

  /**
   * Buffer de entrada
   */
  private BufferedReader in;

  /**
   * Stream de salida
   */
  private ObjectOutputStream out;

  /**
   * Socket del cliente
   */
  private Socket alCliente;

  /**
   * Constructor de la clase
   * @param s Socket del cliente a crear
   * @param gestUsuarios Gestor de Usuarios
   */
  GestorCharla(Socket s, GestorUsuarios gestUsuarios) {
    alCliente = s;
    gestorUsuarios = gestUsuarios;
  }

  /**
   * Metodo run de la superclase Thread con el que en un hilo aparte de ejecucion espero mensajes de los clientes
   */
  public void run() {
    try {
      // Crea los flujos de entrada y salida por medio del
      // socket que se obtuvo cuando se creo el gestor
      // Da la bienvenida

      in = new BufferedReader(new InputStreamReader(alCliente.getInputStream()));
      out = new ObjectOutputStream(alCliente.getOutputStream());

      //Envia todos los usuarios
      out.writeObject(gestorUsuarios.getUsuarios());
      out.flush();

      // Lee lineas y las envia para su difusion
      while (true) {

        String s = in.readLine().trim();

        // Desconecto un cliente
        if (s.charAt(0) == 'D' && s.charAt(1) == 'I') {
          gestorUsuarios.removeUser(s.substring(2));
          Servidor.difusion(s);
          break;
        }

        //Creo nuevo usuario
        if (s.charAt(0) == 'N' && s.charAt(1) == 'U') {
          StringTokenizer st = new StringTokenizer(s.substring(2), "#");
          String nomUsuario = st.nextToken();
          gestorUsuarios.addUser(nomUsuario);
          Servidor.difusion(s);
        }

        //Envia mensaje a todos los usuarios
        if (s.charAt(0) == 'N' && s.charAt(1) == 'M') {
          Servidor.difusion(s);
        }

        //Borra el nick del usuario que cierra su conversaci�n
        if (s.charAt(0) == 'D' && s.charAt(1) == 'U') {
          StringTokenizer st = new StringTokenizer(s.substring(2), "#");
          String nomUsuario = st.nextToken();
          gestorUsuarios.removeUser(nomUsuario);
          Servidor.difusion(s);
        }

        //Crea una nueva ventana de conversaci�n privada
        if (s.charAt(0) == 'N' && s.charAt(1) == 'P') {
          Servidor.difusion(s);
        }

        //Desactiva la conversaci�n privada correspondiente
        if (s.charAt(0) == 'D' && s.charAt(1) == 'P') {
          Servidor.difusion(s);
        }

        //Envia un mensaje privado al usuario correspondiente
        if (s.charAt(0) == 'M' && s.charAt(1) == 'P') {
          Servidor.difusion(s);
        }

      }
      Servidor.eliminar(alCliente);
      alCliente.close();
    }
    catch (Exception e) {
      System.out.println("Error del gestor de charla: " + e);
    }
  }

}
