package servidor;

import java.util.Vector;


/**
* Clase del Gestor de Salas
* @author Manuel Domingo Mora Martinez
* @version 1.0
*/

class GestorUsuarios
{
        /**
        * Vector de usuarios Conectados al chat
        */
        private Vector usersConectados = new Vector();


        /**
        * Procedimiento para borrar un usuario del vector de usuarios registrados
        * @param nick nombre del usuario a borrar
        */
        public synchronized void removeUser(String nick)
        {
                usersConectados.remove(nick);
        }


        /**
        * Funcion que me devuelve el vector de usuarios registrados
        * @return Vector de salas
        */
        public synchronized Vector getUsuarios()
        {
                return usersConectados;
        }

        /**
         * Comprueba si existe un usuario
         * @param nick Nick del usuario
         * @return Variable booleana, TRUE si esta existe
         */
        public boolean existeUser(String nick) {
          for (int i = 0; i < usersConectados.size(); i++) {
            if ( ( usersConectados.get(i)).equals(nick)) {
              return true;
            }
          }
          return false;
        }

        /**
         * A�ade el usuario.
         * @param nomUsuario Usuario a a�adir
         * @return Boolean FALSE si este existe y no es a�adido
         */
        public synchronized boolean addUser(String n) {
            return usersConectados.add(n);
        }

}
