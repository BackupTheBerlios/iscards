package servidor;

import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.ResourceBundle;

/**
* Clase pricipal del servidor
* @author Manuel Domingo Mora Martinez
* @version 1.0
*/

public class Servidor
{

      /**
      *Clase para gestionar usuarios
      */
      private static GestorUsuarios gestorUsuarios = new GestorUsuarios();

      /**
      * Lista de clientes conectados
      */
      private static ArrayList listaClientes = new ArrayList();

      /**
      * Para asignar una id a cada cliente
      */
      private static int id = 0;

      /**
      * Programa principal
      */
      public static void main(String[] args) throws IOException
      {
      // Definicion del puerto y creacion del Socket
         int puerto = 4999;
         ServerSocket oyente = new ServerSocket(puerto);
         System.out.println("El servidor de charla se ejecuta en el puerto "+puerto);

      // Esperar a los clientes
      // Crear un gestor para cada uno
      // Agregarlo a la lista de clientes

        while (true)
         {
            Socket cliente = oyente.accept();
            new GestorCharla(cliente,gestorUsuarios).start();
            System.out.println("Nuevo cliente no."+ id+
                               " desde "+ cliente.getInetAddress()+
                               " desde el puerto "+cliente.getPort());
            listaClientes.add(cliente);
            id++;
         }
      }

             /**
             * Procedimiento que difunde el mensaje por todos los clientes conectados
             * @param mensaje a difundir
             */
      public static synchronized void difusion(String mensaje)
      throws IOException {
      // Envia el mensaje a cada cliente, incluyendo el que lo envio
         Socket s;
         PrintWriter p;
         int k;
         for (k = 0; k < listaClientes.size(); ++k)
         {
            s = (Socket)listaClientes.get(k);
            p = new PrintWriter(s.getOutputStream(), true);
            p.println(mensaje);
         }
      }

      /**
      * Procedimiento para eliminar un cliente (Socket)
      * @param s Socket cliente
      */
      public static synchronized void eliminar(Socket s) {
      // Busca el cliente en la lista y lo elimina
         Socket t = null;
         int k;
         for (k = 0; k < listaClientes.size(); ++k)
         {
            t = (Socket)listaClientes.get(k);
            if (t.equals(s))
               break;
         }

         try
         {
                 t.close();
         }
         catch (Exception e)
         {
                 System.out.println(e);
         }

         listaClientes.remove(k);
         id--;
      }

   }

