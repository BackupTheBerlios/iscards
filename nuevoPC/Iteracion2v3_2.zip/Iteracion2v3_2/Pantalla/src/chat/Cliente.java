package chat;

import java.io.*;

public class Cliente  {
 public void Cliente()
 {
//   GestorUsuarios gestorUsuarios = new GestorUsuarios();
//   Controlador controlador = new Controlador(gestorUsuarios);
//   GUI ventana = new GUI(controlador);
 }
  /*
   public static void main(String args[]) throws IOException
    {
      GestorUsuarios gestorUsuarios = new GestorUsuarios();
      Controlador controlador = new Controlador(gestorUsuarios);
      GUI ventana = new GUI(controlador);
    }//main*/
}

