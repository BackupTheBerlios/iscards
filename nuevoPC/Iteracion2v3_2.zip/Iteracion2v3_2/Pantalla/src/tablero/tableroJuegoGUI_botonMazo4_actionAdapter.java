package tablero;

import java.awt.event.*;

/**
 * <p>T�tulo: GENESIS</p>
 * <p>Descripci�n: actionAdapter del bot�n botonMazo4 del mazo del jugador</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Empresa: </p>
 * @author Rui Miguel
 * @version 1.0
 */

class tableroJuegoGUI_botonMazo4_actionAdapter implements ActionListener {
  tableroJuegoGUI adaptee;

  tableroJuegoGUI_botonMazo4_actionAdapter(tableroJuegoGUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.botonMazo4_actionPerformed(e);
  }
}
