package tablero;

import java.awt.event.*;
import javax.swing.*;


/**
 * <p>T�tulo: GENESIS</p>
 * <p>Descripci�n: Implementaci�n del interfaz gr�fico del tablero de juego</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Empresa: </p>
 * @author Rui Miguel
 * @version 1.0
 */

public class tableroJuegoImp extends tableroJuegoGUI {

  /**
   * Frame padre con el frame de inicio
   */
  JFrame padre;

  /**
   *
   */
  char tipoMazo;

  /**
   * Constructora de la clase
   * @param p
   * @param r Variable que indica la raza de las cartas para cargar en el tablero
   */
  public tableroJuegoImp(JFrame p, char r) {
    padre = p;
    padre.disable();
    tipoMazo = r;
    inicializar(tipoMazo);
  }

  /**
   * Funci�n para inicializar el tablero de juego cargando las cartas en el mismo
   * @param m
   */
  private void inicializar(char m){

    if(tipoMazo=='A'){

//intentamos cargar las imagenes de las cartas de otra manera, para poder hacer escala del dibujo sin tener que modificarlo a mano
/*
      imagenCarta im1 = new imagenCarta("./imagenes/Angeles/Criaturas/Angel Metatron.jpg");
      im1.getScaledInstance(50,50,Image.SCALE_FAST);
      botonMazo1.setIcon(new ImageIcon(im1));
      imagenCarta im2 = new imagenCarta("./imagenes/Angeles/Criaturas/Angel Metatron.jpg");
      im2.getScaledInstance(50,50,Image.SCALE_FAST);
      botonMazo2.setIcon( new ImageIcon("./imagenes/Angeles/Criaturas/Arcangel Gabriel.jpg"));
      imagenCarta im3 = new imagenCarta("./imagenes/Angeles/Criaturas/Angel Metatron.jpg");
      im3.getScaledInstance(50,50,Image.SCALE_FAST);
      botonMazo3.setIcon( new ImageIcon("./imagenes/Angeles/Criaturas/Arcangel Miguel.jpg"));
      imagenCarta im4 = new imagenCarta("./imagenes/Angeles/Criaturas/Angel Metatron.jpg");
      im4.getScaledInstance(50,50,Image.SCALE_SMOOTH);
      botonMazo4.setIcon( new ImageIcon("./imagenes/Angeles/Conjuros/Agua de la vida.jpg"));
      imagenCarta im5 = new imagenCarta("./imagenes/Angeles/Criaturas/Angel Metatron.jpg");
      im5.getScaledInstance(50,50,Image.SCALE_SMOOTH);
      botonMazo5.setIcon( new ImageIcon("./imagenes/Angeles/Mana/Diamante.jpg"));
      imagenCarta im6 = new imagenCarta("./imagenes/Angeles/Criaturas/Angel Metatron.jpg");
      im6.getScaledInstance(50,50,Image.SCALE_SMOOTH);
      botonMazo6.setIcon( new ImageIcon("./imagenes/Angeles/Conjuros/Antisatanico.jpg"));
      imagenCarta im7 = new imagenCarta("./imagenes/Angeles/Criaturas/Angel Metatron.jpg");
      im7.getScaledInstance(50,50,Image.SCALE_SMOOTH);
      botonMazo7.setIcon( new ImageIcon("./imagenes/Angeles/Criaturas/Arcangel Raphael.jpg"));
      imagenCarta im8 = new imagenCarta("./imagenes/Angeles/Criaturas/Angel Metatron.jpg");
      im8.getScaledInstance(50,50,Image.SCALE_SMOOTH);
      botonMazo8.setIcon( new ImageIcon("./imagenes/Angeles/Mana/Diamante.jpg"));
*/
      botonJugador3.setIcon(new ImageIcon("./imagenes/Angeles/Angeles.jpg"));
      botonJugador4.setIcon(new ImageIcon("./imagenes/Angeles/Angeles.jpg"));

    }
    else if(tipoMazo=='D'){
      botonMazo1.setIcon( new ImageIcon("./imagenes/Demonios/Criaturas/Guardian del Averno2.jpg"));
      botonMazo2.setIcon( new ImageIcon("./imagenes/Demonios/Criaturas/las Furias2.jpg"));
      botonMazo3.setIcon( new ImageIcon("./imagenes/Demonios/Criaturas/Lucifer, el Angel Caido2.jpg"));
      botonMazo4.setIcon( new ImageIcon("./imagenes/Demonios/Conjuros/Circulo Protector2.jpg"));
      botonMazo5.setIcon( new ImageIcon("./imagenes/Demonios/Mana/Rubi2.jpg"));
      botonMazo6.setIcon( new ImageIcon("./imagenes/Demonios/Conjuros/Cruz del Diablo2.jpg"));
      botonMazo7.setIcon( new ImageIcon("./imagenes/Demonios/Criaturas/Astaroth2.jpg"));
      botonMazo8.setIcon( new ImageIcon("./imagenes/Demonios/Mana/Rubi2.jpg"));

      botonJugador3.setIcon(new ImageIcon("./imagenes/Demonios/Demonios2.jpg"));
      botonJugador4.setIcon(new ImageIcon("./imagenes/Demonios/Demonios2.jpg"));
    }
    else if(tipoMazo=='H'){
      botonMazo1.setIcon( new ImageIcon("./imagenes/Humanos/Criaturas/.jpg"));
      botonMazo2.setIcon( new ImageIcon("./imagenes/Humanos/Criaturas/.jpg"));
      botonMazo3.setIcon( new ImageIcon("./imagenes/Humanos/Criaturas/.jpg"));
      botonMazo4.setIcon( new ImageIcon("./imagenes/Humanos/Conjuros/.jpg"));
      botonMazo5.setIcon( new ImageIcon("./imagenes/Humanos/Mana/Esmeralda.jpg"));
      botonMazo6.setIcon( new ImageIcon("./imagenes/Humanos/Conjuros/.jpg"));
      botonMazo7.setIcon( new ImageIcon("./imagenes/Humanos/Criaturas/.jpg"));
      botonMazo8.setIcon( new ImageIcon("./imagenes/Humanos/Mana/Esmeralda.jpg"));

      botonJugador3.setIcon(new ImageIcon("./imagenes/Humanos/Humanos.jpg"));
      botonJugador4.setIcon(new ImageIcon("./imagenes/Humanos/Humanos.jpg"));
    }
    else if(tipoMazo=='I'){
      botonMazo1.setIcon( new ImageIcon("./imagenes/Inmortales/Criaturas/Dios De Lo Terrenal.jpg"));
      botonMazo2.setIcon( new ImageIcon("./imagenes/Inmortales/Criaturas/Dios Del Caos.jpg"));
      botonMazo3.setIcon( new ImageIcon("./imagenes/Inmortales/Criaturas/Diosa De La Candidez.jpg"));
      botonMazo4.setIcon( new ImageIcon("./imagenes/Inmortales/Conjuros/Nieve Legendaria.jpg"));
      botonMazo5.setIcon( new ImageIcon("./imagenes/Inmortales/Mana/Amatista.jpg"));
      botonMazo6.setIcon( new ImageIcon("./imagenes/Inmortales/Conjuros/Esfera Protectora.jpg"));
      botonMazo7.setIcon( new ImageIcon("./imagenes/Inmortales/Criaturas/Dragon Verde.jpg"));
      botonMazo8.setIcon( new ImageIcon("./imagenes/Inmortales/Mana/Amatista.jpg"));

      botonJugador3.setIcon(new ImageIcon("./imagenes/Inmortales/Inmortales.jpg"));
      botonJugador4.setIcon(new ImageIcon("./imagenes/Inmortales/Inmortales.jpg"));
    }
  }

  /**
   *
   * @param e
   */
  void botonServidor_actionPerformed(ActionEvent e)
{
      Runtime r = Runtime.getRuntime();
      Process p = null;
      try {
        p = r.exec("EXPLORER http://www.fdi.ucm.es");
      } catch (Exception q) {
         JOptionPane.showMessageDialog(null, q.getMessage(),
                                        "ERROR",
                                        JOptionPane.ERROR_MESSAGE);
      }

  }

  /**
   *
   * @param e
   */
 /* void botonChat_actionPerformed(ActionEvent e) {


  }*/

  /**
   * Funci�n actionPerformed para finalizar la partida cuando se quiera
   * @param e
   */
  void botonFinalizar_actionPerformed(ActionEvent e) {
    //solicitamos confirmaci�n para salir
    int salir = JOptionPane.showConfirmDialog(this, "Desea finalizar la partida?", "GENESIS",
                                              JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
    switch (salir) {
      case JOptionPane.YES_OPTION:{
        this.dispose();
        padre.enable();
        padre.show();
      }
      case JOptionPane.NO_OPTION:
        ;
    }
  }

//**********************************************
//**********************************************
//Funciones actionPerformed para controlar el botonActual pulsado en ultimo lugar
//**********************************************
//**********************************************

//botones del Mazo del jugador
  void botonMazo1_actionPerformed(ActionEvent e){
    botonActual = botonMazo1;
    jugador = false;
  }

  void botonMazo2_actionPerformed(ActionEvent e){
    botonActual = botonMazo2;
    jugador = false;
  }

  void botonMazo3_actionPerformed(ActionEvent e){
    botonActual = botonMazo3;
    jugador = false;
  }

  void botonMazo4_actionPerformed(ActionEvent e){
    botonActual = botonMazo4;
    jugador = false;
  }

  void botonMazo5_actionPerformed(ActionEvent e){
    botonActual = botonMazo5;
    jugador = false;
  }

  void botonMazo6_actionPerformed(ActionEvent e){
    botonActual = botonMazo6;
    jugador = false;
  }

  void botonMazo7_actionPerformed(ActionEvent e){
    botonActual = botonMazo7;
    jugador = false;
  }

  void botonMazo8_actionPerformed(ActionEvent e){
    botonActual = botonMazo8;
    jugador = false;
  }

//botones del tablero del jugador
  void botonJugador1_actionPerformed(ActionEvent e) {
    botonActual = botonJugador1;
    jugador = true;
    mana = true;
    girada = !girada;
    mazo = false;
  }

  void botonJugador2_actionPerformed(ActionEvent e) {
    botonActual = botonJugador2;
    jugador = true;
    mana = true;
    girada = !girada;
    mazo = false;
  }

  void botonJugador3_actionPerformed(ActionEvent e) {
    botonActual = botonJugador3;
    jugador = true;
    girada = !girada;
    mana = false;
    mazo = true;
  }

  void botonJugador4_actionPerformed(ActionEvent e) {
    botonActual = botonJugador4;
    jugador = true;
    girada = !girada;
    mana = false;
    mazo = true;
  }

  void botonJugador5_actionPerformed(ActionEvent e) {
    botonActual = botonJugador5;
    jugador = true;
    girada = !girada;
    mana = false;
    mazo = false;
  }

  void botonJugador6_actionPerformed(ActionEvent e) {
    botonActual = botonJugador6;
    jugador = true;
    girada = !girada;
    mana = false;
    mazo = false;
  }

  void botonJugador9_actionPerformed(ActionEvent e) {
    botonActual = botonJugador9;
    jugador = true;
    girada = !girada;
    mana = false;
    mazo = false;
  }

  void botonJugador10_actionPerformed(ActionEvent e) {
    botonActual = botonJugador10;
    jugador = true;
    girada = !girada;
    mana = false;
    mazo = false;
  }

  void botonJugador12_actionPerformed(ActionEvent e) {
    botonActual = botonJugador12;
    jugador = true;
    girada = !girada;
    mana = false;
    mazo = false;
  }

  void botonJugador13_actionPerformed(ActionEvent e) {
    botonActual = botonJugador13;
    jugador = true;
    girada = !girada;
    mana = false;
    mazo = false;
  }


  /**
   * Funci�n actionPerformed para usar la carta seleccionada
   * @param e
   */
  void iUsar_actionPerformed(ActionEvent e){
    String nomDibAux = botonActual.getIcon().toString();
    System.out.println(botonActual);

    String nomBoton = botonActual.getName();
    String nomDib = new String();
    String nomDib2 = new String();
    nomDib=nomDibAux.substring(0,nomDibAux.length()-5);
    nomDib2=nomDib + "4.jpg";
    nomDib=nomDib + "3.jpg";


//*******************************************************************
//*******************************************************************
//Hecho a lo cutre para que deje, esto hay que cambiarlo que ni de co�a funciona bien
//*******************************************************************
//*******************************************************************

    if(botonActual!=null){
      if(!jugador) {
        if(nomBoton.equals("botonMazo5") || nomBoton.equals("botonMazo8"))
          botonJugador1.setIcon(new ImageIcon(nomDib));
        else if(nomBoton.equals("botonMazo4"))
          botonJugador12.setIcon(new ImageIcon(nomDib));
        else if(nomBoton.equals("botonMazo6"))
          botonJugador13.setIcon(new ImageIcon(nomDib));
        else if(nomBoton.equals("botonMazo1"))
          botonJugador5.setIcon(new ImageIcon(nomDib));
        else if(nomBoton.equals("botonMazo2"))
          botonJugador6.setIcon(new ImageIcon(nomDib));
        else if(nomBoton.equals("botonMazo3"))
          botonJugador9.setIcon(new ImageIcon(nomDib));
        else if(nomBoton.equals("botonMazo7"))
          botonJugador10.setIcon(new ImageIcon(nomDib));
        botonActual.setIcon(null);
      }
      else
        if(!mazo)
          if(mana)
            botonJugador2.setIcon(new ImageIcon(nomDib2));
          else
            if(girada)
              botonActual.setIcon(new ImageIcon(nomDib));
            else if(!girada)
              botonActual.setIcon(new ImageIcon(nomDib2));
    }
//*******************************************************************
//*******************************************************************
//*******************************************************************
//*******************************************************************

  }


  /**
   * Funci�n actionPerformed para visualizar la carta seleccionada
   * @param e
   */
  void iVisualizar_actionPerformed(ActionEvent e){
    JPanel panelCarta = new JPanel();
    String nomDibAux=botonActual.getIcon().toString();
    String nomDib=new String();
    nomDib = nomDibAux.substring(0,nomDibAux.length()-5);
    nomDib = nomDib + ".jpg";
    ImageIcon i=new ImageIcon(nomDib);
    JOptionPane.showMessageDialog(this, panelCarta, "REGLAS", JOptionPane.INFORMATION_MESSAGE, i);
  }

  /**
   *
   * @param e
   */
  void this_windowClosing(WindowEvent e) {
    padre.enable();
  }
}
