
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.net.URL;

/**
 * <p>T�tulo: GENESIS</p>
 * <p>Descripci�n: Interfaz Gr�fico del frame de inicio</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Empresa: </p>
 * @author Rui Miguel
 * @version 1.0
 */

abstract public class frameIntroGUI extends JFrame {
  JPanel contentPane;
  GridBagLayout gridBagLayout1 = new GridBagLayout();
  JButton boton1Jugador = new JButton();
  JButton botonJuegoRed = new JButton();
  JButton botonDemo = new JButton();
  JButton botonAyuda = new JButton();
  JButton botonEditar = new JButton();
  JButton botonReglas = new JButton();
  JButton botonSalir = new JButton();

  /**
   * Constructora de la clase
   */
  public frameIntroGUI() {
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    try {
      jbInit();
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  /**
   * Funci�n de inicializaci�n de los componentes
   * @throws java.lang.Exception
   */
  private void jbInit() throws Exception {
    contentPane = (JPanel)this.getContentPane();
    contentPane.setLayout(gridBagLayout1);
    this.setSize(new Dimension(400, 243));
    this.setTitle("GENESIS version_1.0");


//    componente.setAccelerator(KeyStroke.getKeyStroke(tecla,0));

    boton1Jugador.setText("1 Jugador");
    boton1Jugador.addActionListener(new frameIntroGUI_boton1Jugador_actionAdapter(this));
    botonJuegoRed.setText("Juego en Red");
    botonJuegoRed.addActionListener(new frameIntroGUI_botonJuegoRed_actionAdapter(this));
    botonDemo.setText("Demo");
    botonDemo.addActionListener(new frameIntroGUI_botonDemo_actionAdapter(this));
    botonAyuda.setText("Ayuda");
    botonAyuda.addActionListener(new frameIntroGUI_botonAyuda_actionAdapter(this));
    botonEditar.setText("Editar Baraja");
    botonEditar.addActionListener(new frameIntroGUI_botonEditar_actionAdapter(this));
    botonEditar.setPreferredSize(new Dimension(73, 25));
    botonReglas.setText("Reglas");
    botonReglas.addActionListener(new frameIntroGUI_botonReglas_actionAdapter(this));
    botonReglas.setPreferredSize(new Dimension(73, 25));
    botonSalir.setText("Salir");
    botonSalir.addActionListener(new frameIntroGUI_botonSalir_actionAdapter(this));

    contentPane.add(boton1Jugador, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
        , GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 3, 0, 0), 0, 14));
    contentPane.add(botonJuegoRed, new GridBagConstraints(1, 0, 1, 2, 0.0, 0.0
        , GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 14));
    contentPane.add(botonDemo, new GridBagConstraints(2, 0, 6, 3, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 27, 14));
    contentPane.add(botonAyuda, new GridBagConstraints(0, 3, 1, 1, 0.0, 0.0
            ,GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 23, 14));
    contentPane.add(botonEditar, new GridBagConstraints(1, 2, 1, 3, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 38, 16));
    contentPane.add(botonSalir, new GridBagConstraints(1, 5, 7, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, -1, 0, 0), 53, 14));
    contentPane.add(botonReglas, new GridBagConstraints(3, 3, 6, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 21, 14));
  }

  /**
   * Funci�n WindowEvent para poder salir cuando se cierra la ventana
   * @param e
   */
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
    System.exit(0);
    }
  }

  /**
   *
   * @param e
   */
  abstract void boton1Jugador_actionPerformed(ActionEvent e);

  /**
   *
   * @param e
   */
  abstract void botonJuegoRed_actionPerformed(ActionEvent e);

  /**
   *
   * @param e
   */
  abstract void botonDemo_actionPerformed(ActionEvent e);

  /**
   *
   * @param e
   */
  abstract void botonAyuda_actionPerformed(ActionEvent e);

  /**
   *
   * @param e
   */
  abstract void botonEditar_actionPerformed(ActionEvent e);

  /**
   *
   * @param e
   */
  abstract void botonReglas_actionPerformed(ActionEvent e);

  /**
   *
   * @param e
   */
  abstract void botonSalir_actionPerformed(ActionEvent e);
}