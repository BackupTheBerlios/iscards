package editor;

import javax.swing.*;
import java.awt.event.*;
import javax.swing.JFileChooser;
import java.util.Vector;
import java.util.Collection;

/**
 * <p>T�tulo: GENESIS</p>
 * <p>Descripci�n: Implementaci�n del interfaz gr�fico del Editor de barajas del jugador</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Empresa: </p>
 * @author Rui Miguel
 * @version 1.0
 */

public class editorBarajasImp extends editorBarajasGUI{

  javax.swing.DefaultListModel dlmCartasSeleccionadas = null;
  javax.swing.DefaultListModel dlmCartasDisponibles = null;

  JFrame padre;

  /**
   * Constructora de la clase
   * @param p Frame padre del Editor
   */
  public editorBarajasImp(JFrame p) {
    padre = p;
    padre.disable();

    //asignamos los ListModel a las listas de cartas del editor
    dlmCartasSeleccionadas = new javax.swing.DefaultListModel();
    dlmCartasDisponibles = new javax.swing.DefaultListModel();

    this.listSeleccionadas.setModel(dlmCartasSeleccionadas);

//CARTAS DE PRUEBA: inicializaci�n
    Vector cartasPrueba = new Vector();
    cartasPrueba.addElement("criaturaAngeles1");
    cartasPrueba.addElement("criaturaAngeles2");
    cartasPrueba.addElement("conjuroAngeles");
    cartasPrueba.addElement("manaAngeles");
    cartasPrueba.addElement("criaturaDemonios1");
    cartasPrueba.addElement("criaturaDemonios2");
    cartasPrueba.addElement("conjuroDemonios1");
    cartasPrueba.addElement("manaDemonios");
    cartasPrueba.addElement("criaturaHumanos1");
    cartasPrueba.addElement("criaturaHumanos2");
    cartasPrueba.addElement("conjuroHumanos");
    cartasPrueba.addElement("manaHumanos");
    cartasPrueba.addElement("criaturaHumanos1");
    cartasPrueba.addElement("criaturaHumanos2");
    cartasPrueba.addElement("conjuroHumanos");
    cartasPrueba.addElement("manaHumanos");
    cartasPrueba.addElement("criaturaDemonios3");
    cartasPrueba.addElement("criaturaDemonios4");
    cartasPrueba.addElement("conjuroDemonios2");
    cartasPrueba.addElement("manaDemonios");


    for(int i=0; i<cartasPrueba.size(); i++)
      dlmCartasDisponibles.addElement(cartasPrueba.get(i));

    this.listDisponibles.setModel(dlmCartasDisponibles);

  }

  /**
   * Funci�n para controlar el evento del mouse en la lista de cartas seleccionadas
   * @param e
   */
  void listSeleccionadas_mouseClicked(MouseEvent e) {
    //observamos el indice seleccionado
    int indice=listSeleccionadas.getSelectedIndex();
    if(indice!=-1){
      String cartaSelec=(String)dlmCartasSeleccionadas.elementAt(indice);
      //a�adimos a las cartas disponibles la carta del indice
      dlmCartasDisponibles.addElement(dlmCartasSeleccionadas.elementAt(indice));
      try{
        //eliminamos la carta seleccionada en la lista
        dlmCartasSeleccionadas.removeElementAt(indice);
      }
      catch(Exception er){
        JOptionPane.showMessageDialog(this, new JLabel(er.getClass().toString()),"ERROR", JOptionPane.ERROR_MESSAGE);
      }
    }
  }

  /**
   * Funci�n para controlar el evento del mouse en la lista de cartas disponibles
   * @param e
   */
  void listDisponibles_mouseClicked(MouseEvent e) {
    //observamos el indice seleccionado
    int indice=listDisponibles.getSelectedIndex();
    if(indice!=-1){
      String cartaSelec = (String) dlmCartasDisponibles.elementAt(indice);
      //a�adimos a las cartas seleccionadas la carta del indice
      dlmCartasSeleccionadas.addElement(dlmCartasDisponibles.elementAt(indice));
      try {
        //eliminamos la carta seleccionada en la lista
        dlmCartasDisponibles.removeElementAt(indice);
      }
      catch (Exception er) {
        JOptionPane.showMessageDialog(this, new JLabel(er.getClass().toString()), "ERROR", JOptionPane.ERROR_MESSAGE);
      }
    }
  }

  /**
   * Funci�n actionPerformed para guardar una baraja configurada
   * @param e
   */
  void botonGuardar_actionPerformed(ActionEvent e) {
    //si la lista de cartas seleccionadas no est� vacio
    if(!dlmCartasSeleccionadas.isEmpty()){
      //usamos un filtro para guardar las barajas
      JFileChooser fichero = new JFileChooser("./barajas");
      FiltroURLAyuda filtro = new FiltroURLAyuda();
      String texto = (String) dlmCartasSeleccionadas.firstElement();
      fichero.setFileFilter(filtro);
      int valor = fichero.showSaveDialog(this);
      if (valor == JFileChooser.APPROVE_OPTION) {
//*******************************************************//
//**********GUARDAR LA BARAJA PERSONALIZADA*************//
//*******************************************************//

      }
    }
  }

  /**
   * Funci�n actionPerformed para cargar una baraja configurada
   * @param e
   */
  void botonCargar_actionPerformed(ActionEvent e) {
    //usamos un filtro para cargar las barajas
    JFileChooser fichero = new JFileChooser("./barajas");
    FiltroURLAyuda filtro = new FiltroURLAyuda();
    fichero.setFileFilter(filtro);
    int valor = fichero.showOpenDialog(this);
    if (valor == JFileChooser.APPROVE_OPTION){
//*******************************************************//
//************CARGAR LA BARAJA PERSONALIZADA*************//
//*******************************************************//

      //borramos la lista de seleccionadas que haya, para al cargar la baraja mostrarlas en la lista
      if (!dlmCartasSeleccionadas.isEmpty()) {
        for(int i=0; i<dlmCartasSeleccionadas.size(); i++)
          dlmCartasDisponibles.addElement(dlmCartasSeleccionadas.elementAt(i));
        dlmCartasSeleccionadas.removeAllElements();
     }
    }
  }

  /**
   * Funci�n actionPerformed para el bot�n Aceptar
   * @param e
   */
  void botonAceptar_actionPerformed(ActionEvent e) {
    this.dispose();
    padre.enable();
    padre.show();
  }

  /**
   *
   * @param e
   */
  void this_windowClosing(WindowEvent e) {
    padre.enable();
  }
}