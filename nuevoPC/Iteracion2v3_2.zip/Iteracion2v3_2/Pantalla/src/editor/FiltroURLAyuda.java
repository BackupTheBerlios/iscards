package editor;

import java.io.File;
import javax.swing.filechooser.FileFilter;

/**
 * <p>T�tulo: GENESIS</p>
 * <p>Descripci�n: Filtro para cargar y guardar archivos</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Empresa: </p>
 * @author Rui Miguel
 * @version 1.0
 */


/** Clase que usamos para crear un filtro de texto a la hora de cargar un archivo URL para la ayuda
 * @see javax.swing.filechooser.FileFilter
 * @see java.io.File
 */
class FiltroURLAyuda extends FileFilter{

  /**
   * Constructora de la clase, que llama a la constructora de la clase de la que hereda
   */
  public FiltroURLAyuda() {
    super();
  }

  /** Redefinici�n de la funci�n accept, para poder filtrar los archivos de tipo "*.bar"
   * @see javax.swing.filechooser.FileFilter#accept(File f)
   * @param f nombre del fichero que queremos cargar
   * @return un booleano que indica si el fichero f cumple nuestro filtro y por tanto podemos cargarlo
   */
  public boolean accept(File f) {
    String nombre = f.getName();
    try {
      //restringimos los nombre a "*.bar"
      return nombre.endsWith(".bar");
    }
    //controlamos con excepciones que no haya problemas al cargar el fichero devolviendo false
    catch (StringIndexOutOfBoundsException e) {
      return false;
    }
  }

  /** Funci�n que nos dice una breve descripci�n del tipo de los ficheros que filtramos
   * @return String con la descripci�n
   */
  public String getDescription() {
    return "barajas";
  }
}