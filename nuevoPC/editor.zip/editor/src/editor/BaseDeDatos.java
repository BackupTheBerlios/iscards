package editor;

import java.util.Hashtable;
import java.util.Enumeration;

/**
 * <p>T�tulo: Editor</p>
 * <p>Descripci�n: Editor de la base de datos de las cartas para G�nesis</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Empresa: </p>
 * @author Miguel Cayeiro Garc�a
 * @version 1.0
 */

/**
 * Clase que usamos para la base de datos de las cartas
 * @see java.util.Hashtable
 * @see java.util.Enumeration
 */
public class BaseDeDatos {
  /**
   * Variable en la cual se guardaran las cartas de la colecci�n a partir de los c�digos
   */
  private Hashtable BBDDCartas;

  /**
   * Variable en la cual se guardaran los c�digos de las cartas a partir de los nombres
   */
  private Hashtable BBDDCodigos;

  /**
   * Variables para saber el codigo de la siguiente carta a introducir
   */
  private int codigoA, codigoD, codigoH, codigoI;

  /**
   * Constructora de la clase BaseDeDatos
   */
  public BaseDeDatos() {
    //creamos una nueva tabla para la base de datos de las cartas
    BBDDCartas = new Hashtable();
    //creamos una nueva tabla para la base de datos de los c�digos
    BBDDCodigos = new Hashtable();
    //inicializamos los c�digos
    codigoA=1;
    codigoD=1;
    codigoH=1;
    codigoI=1;
  }

  /**
   * Funci�n que borra todo el contenido de la base de datos
   */
  public void borrarBD(){
    //borramos la tabla de la base de datos de las cartas
    BBDDCartas.clear();
    //borramos la tabla de la base de datos de los c�digos
    BBDDCodigos.clear();
    //inicializamos los c�digos
    codigoA=1;
    codigoD=1;
    codigoH=1;
    codigoI=1;
  }

  /**
   * Funci�n que devuelve el codigo de la pr�xima carta de los Angeles
   * @return codigo
   */
  public String getCodigoA(){
    return "A"+codigoA;
  }

  /**
   * Funci�n que devuelve el codigo de la pr�xima carta de los Demonios
   * @return codigo
   */
  public String getCodigoD(){
    return "D"+codigoD;
  }

  /**
   * Funci�n que devuelve el codigo de la pr�xima carta de los Humanos
   * @return codigo
   */
  public String getCodigoH(){
    return "H"+codigoH;
  }

  /**
   * Funci�n que devuelve el codigo de la pr�xima carta de los Inmortales
   * @return codigo
   */
  public String getCodigoI(){
    return "I"+codigoI;
  }

  /**
   * Funci�n que a�ade una nueva carta a la base de datos
   * @param c carta nueva a a�adir
   * @throws java.lang.Exception La raza no existe
   */
  public void anadir(Carta c) throws Exception{
    //se comprueba si existe una carta con el mismo nombre
    if (BBDDCodigos.containsKey(c.getNombre()))
      //se comprueba si la carta se esta modificando, si coincide el c�digo
      if (!BBDDCodigos.get(c.getNombre()).equals(c.getCodigo()))
        //no coincide, luego es otra carta
        throw new Exception("Ya hay una carta que se llama as�");
    if (!BBDDCartas.containsKey(c.getCodigo()))
      //hay que aumentar el c�digo de la raza, porque se a�ade un c�digo que no se usaba
      if (c.getRaza().equals("Angeles"))
        codigoA++;
      else if (c.getRaza().equals("Demonios"))
        codigoD++;
      else if (c.getRaza().equals("Humanos"))
        codigoH++;
      else if (c.getRaza().equals("Inmortales"))
        codigoI++;
      else
        //no se le ha podido aumentar el codigo a ninguna raza, luego la raza no existe
        throw new Exception("La raza no existe");
    BBDDCartas.put(c.getCodigo(), c);
    BBDDCodigos.put(c.getNombre(),c.getCodigo());
  }

  /**
   * Funci�n que elimina una carta por su c�digo y devuelve un booleano diciendo
   * si la ha borrado
   * @param c�digo c�digo solicitada
   * @return boolean que guarda si ha sido eliminada la carta
   */
  public boolean eliminarCarta(String codigo){
    boolean eliminado = true;
    if (!BBDDCartas.containsKey(codigo))
      //no se puede eliminar porque no existe la c�digo en la base de datos
      eliminado = false;
    BBDDCodigos.remove(((Carta)BBDDCartas.get(codigo)).getNombre());
    BBDDCartas.remove(codigo);
    return eliminado;
  }

  /**
   * Funci�n que devuelve una carta almacenada por su c�digo
   * @param c�digo c�digo solicitada
   * @return Object carta almacenada con esa c�digo
   * @throws java.lang.Exception no se dispone de dicha carta
   */
  public Carta pedirCarta(String codigo) throws Exception{
    if (!BBDDCartas.containsKey(codigo))
      //no se puede devolver la carta porque no existe la c�digo en la base de datos
      throw new Exception("Ese c�digo no existe");
    return (Carta) BBDDCartas.get(codigo);
  }

  /**
   * Funci�n que devuelve el c�digo de la carta por su nombre
   * @param nombre nombre solicitado
   * @return Object codigo de la carta almacenada con ese nombre
   * @throws java.lang.Exception no se dispone el c�digo de la carta con dicho nombre
   */
  public String pedirCodigo(String nombre) throws Exception{
    if (!BBDDCodigos.containsKey(nombre))
      //no se puede devolver el c�digo de la carta porque no existe el nombre en la base de datos
      throw new Exception("Ese nombre no existe");
    return (String) BBDDCodigos.get(nombre);
  }

  /**
   * Funci�n que devuelve una enumeracion de todas las c�digos que hay en la
   * base de datos
   * @return Enumeration con las c�digos
   */
  public Enumeration pedirCodigos(){
    return BBDDCartas.keys();
  }
}