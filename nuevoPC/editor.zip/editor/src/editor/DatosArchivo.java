package editor;

/**
 * <p>T�tulo: Editor</p>
 * <p>Descripci�n: Editor de la base de datos de las cartas para G�nesis</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Empresa: </p>
 * @author Miguel Cayeiro Garc�a
 * @version 2.0
 */

/**
 * Clase que usamos para guardar las caraster�sticas del archivo ".car"
 */
public class DatosArchivo {
  private String path,nombreArchivo;
  private int version;
  private int numCartasA, numCartasD, numCartasH, numCartasI;
  private boolean modificado;

  /**
   * Constructora de la clase DatosArchivo
   * @param path ruta del archivo ".car"
   * @param version del archivo ".car"
   * @param numA numero de �ngeles en el archivo ".car"
   * @param numD numero de demonios en el archivo ".car"
   * @param numH numero de humanos en el archivo ".car"
   * @param numI numero de inmortales en el archivo ".car"
   */
  public DatosArchivo(String path,int version, int numA, int numD, int numH, int numI) {
    this.path = path;
    int posicion = this.path.lastIndexOf("/");
    if (posicion==-1)
      posicion = this.path.lastIndexOf("\\");
    this.nombreArchivo = path.substring(posicion+1);
    this.version = version;
    this.numCartasA = numA;
    this.numCartasD = numD;
    this.numCartasH = numH;
    this.numCartasI = numI;
    this.modificado = false;
  }

  /**
   * Funci�n que actualiza la direccion (path) y el nombre del archivo que contiene
   * las cartas cargadas
   */
  public void setPath(String path){
    this.path = path;
    int posicion = this.path.lastIndexOf("/");
    if (posicion==-1)
      posicion = this.path.lastIndexOf("\\");
    this.nombreArchivo = path.substring(posicion+1);
  }

  /**
   * Funci�n que actualiza la version del archivo que contiene las cartas cargadas
   */
  public void setVersion(int version){
    this.version = version;
  }

  /**
   * Funci�n que actualiza el n�mero Cartas de los �ngeles que contiene el archivo
   */
  public void setNumCartasA(int numA){
    this.numCartasA = numA;
  }

  /**
   * Funci�n que actualiza el n�mero Cartas de los Demonios que contiene el archivo
   */
  public void setNumCartasD(int numD){
    this.numCartasD = numD;
  }

  /**
   * Funci�n que actualiza el n�mero Cartas de los Humanos que contiene el archivo
   */
  public void setNumCartasH(int numH){
    this.numCartasH = numH;
  }

  /**
   * Funci�n que actualiza el n�mero Cartas de los Inmortales que contiene el archivo
   */
  public void setNumCartasI(int numI){
    this.numCartasI = numI;
  }

  /**
   * Funci�n que actualiza el boolean modificado, para saber si el archivo no tiene lo
   * mismo que la bade de datos de las cartas en ese momento
   */
  public void setModificado(boolean modif){
    this.modificado = modif;
  }

  /**
   * Funci�n que devuelve la direccion (path) del archivo que contiene las cartas cargadas
   * @return path
   */
  public String getPath(){
    return this.path;
  }

  /**
   * Funci�n que devuelve el nombre del archivo que contiene las cartas cargadas
   * @return nombre
   */
  public String getNombre(){
    return this.nombreArchivo;
  }

  /**
   * Funci�n que devuelve la version del archivo que contiene las cartas cargadas
   * @return version
   */
  public int getVersion(){
    return this.version;
  }

  /**
   * Funci�n que devuelve el n�mero Cartas de los �ngeles que contiene el archivo
   * @return numCartasA
   */
  public int getNumCartasA(){
    return this.numCartasA;
  }

  /**
   * Funci�n que devuelve el n�mero Cartas de los Demonios que contiene el archivo
   * @return numCartasD
   */
  public int getNumCartasD(){
    return this.numCartasD;
  }

  /**
   * Funci�n que devuelve el n�mero Cartas de los Humanos que contiene el archivo
   * @return numCartasH
   */
  public int getNumCartasH(){
    return this.numCartasH;
  }

  /**
   * Funci�n que devuelve el n�mero Cartas de los Inmortales que contiene el archivo
   * @return numCartasI
   */
  public int getNumCartasI(){
    return this.numCartasI;
  }

  /**
   * Funci�n que devuelve si el archivo fue modificado y no salvado
   * @return modificado
   */
  public boolean getModificado(){
    return this.modificado;
  }
}