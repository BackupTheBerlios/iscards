package editor;

import java.io.File;
import javax.swing.filechooser.FileFilter;

/**
 * <p>T�tulo: Editor</p>
 * <p>Descripci�n: Editor de la base de datos de las cartas para G�nesis</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Empresa: </p>
 * @author Miguel Cayeiro Garc�a
 * @version 1.0
 */


/**
 * Clase que usamos para crear un filtro de texto a la hora de cargar o guardar
 * un archivo URL con la base de datos de las cartas
 * @see javax.swing.filechooser.FileFilter
 * @see java.io.File
 */
class FiltroURLCartas extends FileFilter{

  /** Constructora de la clase, que llama a la constructora de la clase de la que hereda */
  public FiltroURLCartas() {
    super();
  }

  /** Redefinici�n de la funci�n accept, para poder filtrar los archivos de tipo ".car"
   * @see javax.swing.filechooser.FileFilter#accept(File f)
   * @param f nombre del fichero que queremos cargar
   * @return un booleano que indica si el fichero f cumple nuestro filtro y por tanto podemos cargarlo
   */
  public boolean accept(File f) {
    String nombre = f.getName();
    try {
      //restringimos los nombre a ".car"
      return nombre.endsWith(".car");
    }
    //controlamos con excepciones que no haya problemas al cargar el fichero devolviendo false
    catch (StringIndexOutOfBoundsException e) {
      return false;
    }
  }

  /** Funci�n que nos dice una breve descripci�n del tipo de los ficheros que filtramos
   * @return String con la descripci�n
   */
  public String getDescription() {
    return "fichero de cartas";
  }
}