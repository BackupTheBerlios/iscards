package editor;

import java.awt.*;
import java.awt.event.*;
import java.net.URL;
import javax.swing.*;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.util.Enumeration;

/**
 * Clase EditorImp: Implementaci�n del editor
 * <p>T�tulo: Editor</p>
 * <p>Descripci�n: Editor de la base de datos de las cartas para G�nesis</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Empresa: </p>
 * @author Miguel Cayeiro Garc�a
 * @version 1.0
 */
public class EditorImp extends EditorGUI{
  /**
   * Variable para la base de datos de las cartas
   */
  BaseDeDatos BD;

  /**
   * Constructora de la aplicaci�n
   */
  public EditorImp() {
    BD = new BaseDeDatos();
    this.textoCodigo.setText(this.BD.getCodigoA());
  }

  /**
   * Funci�n actionPerfomed que controla cuando se pulsa el bot�n de jMenuFileNuevo
   * @param e
   */
  void jMenuFileNuevo_actionPerformed(ActionEvent e) {
    this.BD.borrarBD();
    this.jMenuCartasNueva_actionPerformed(e);
  }

  /**
   * Funci�n que lee de un archivo una cantidad de car�cteres pedida
   * @param longitud cantidad de car�cteres que hay que leer
   * @param archivo archivo del que hay que leer
   * @return String con los datos leidos
   * @throws java.lang.Exception
   */
  private byte[] leerFrase(int longitud, FileInputStream archivo) throws Exception{
    int bytes;
    int i=0;
    byte[] frase=new byte[longitud];
    while(i<longitud){
      bytes= archivo.read();
      if (bytes==-1) //i==-1 es fin de fichero
        throw new Exception("La base de datos esta incompleta");
      frase[i]=(byte)bytes;
      i++;
    }
    return frase;
  }

  /**
   * Funci�n que descodifica los bytes leidos
   * @param fraseBytes bytes leidos
   * @return String frase descodificada
   */
  private String descodificar(byte[] fraseBytes){
    String frase = "";
    int i=0;
    while (i<fraseBytes.length){
      char a;
      if(fraseBytes[i]<0)
        //car�cter espepecial (�, �, �, �, �, �, ...)
        a = (char) (256 + fraseBytes[i] + 2);
      else
        a = (char)(fraseBytes[i] + 2);
      frase=frase+a;
      i++;
    }
    return frase;
  }

  /**
   * Funci�n actionPerfomed que controla cuando se pulsa el bot�n de jMenuFileCargar
   * @param e
   */
  void jMenuFileCargar_actionPerformed(ActionEvent e) {
     JFileChooser archivo = new JFileChooser(".");
     //ponemos un filtro para seleccionar el archivo
     archivo.setFileFilter(new FiltroURLCartas());
     archivo.setFileSelectionMode(JFileChooser.FILES_ONLY);
     //mostramos un OpenDialog para seleccionar el fichero de cartas
     if (archivo.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
       //controlamos la carga del fichero mediante excepciones
       try {
         if (!archivo.getSelectedFile().getName().endsWith(".car"))
           //todos los archivos de colecciones de cartas son ".car"
           throw new Exception("El archivo no esta relacionado");

         FileInputStream archivo1 = new FileInputStream(archivo.getSelectedFile());
         //continuamos una colecci�n antigua luego hay que borrar lo que tenemos ahora mismo
         this.BD.borrarBD();
         int numeroDeBytesALeer; //variable para controlar los bytes que se deben leer
         numeroDeBytesALeer = archivo1.read();
         while (numeroDeBytesALeer >= 0) { // i==-1 es fin de fichero
           String codigo = descodificar(leerFrase(numeroDeBytesALeer, archivo1));

           numeroDeBytesALeer = archivo1.read();
           String raza = descodificar(leerFrase(numeroDeBytesALeer, archivo1));

           numeroDeBytesALeer = archivo1.read();
           String tipo = descodificar(leerFrase(numeroDeBytesALeer, archivo1));

           numeroDeBytesALeer = archivo1.read();
           String nombre = descodificar(leerFrase(numeroDeBytesALeer, archivo1));

           //el nivel al leerlo se descodifica solo
           Integer nivel = new Integer(archivo1.read());

           numeroDeBytesALeer = archivo1.read();
           String puntosEnLetra = descodificar(leerFrase(numeroDeBytesALeer, archivo1));
           Integer puntos = new Integer(puntosEnLetra);

           //el ataque al leerlo se descodifica solo
           Integer ataque = new Integer(archivo1.read());
           //la defensa al leerlo se descodifica solo
           Integer defensa = new Integer(archivo1.read());
           //el coste al leerlo se descodifica solo
           Integer coste = new Integer(archivo1.read());
           //la vida al leerlo se descodifica solo
           Integer vida = new Integer(archivo1.read());

           //los numeros de letras que hay que leer de descripMov tambi�n est�n codificado
           numeroDeBytesALeer = archivo1.read();
           numeroDeBytesALeer = (new Integer(descodificar(leerFrase(numeroDeBytesALeer,
               archivo1))).intValue());
           String descripMov = descodificar(leerFrase(numeroDeBytesALeer, archivo1));

           //los numeros de letras que hay que leer de descripHab tambi�n est�n codificado
           numeroDeBytesALeer = archivo1.read();
           numeroDeBytesALeer = (new Integer(descodificar(leerFrase(numeroDeBytesALeer,
               archivo1))).intValue());
           String descripHab = descodificar(leerFrase(numeroDeBytesALeer, archivo1));

           //creamos la nueva carta leida y la a�adimos
           Carta carta = new Carta(codigo, raza, tipo, nombre, nivel, puntos,
                                   ataque, defensa, coste, vida, descripMov,
                                   descripHab);
           this.BD.anadir(carta);
           numeroDeBytesALeer = archivo1.read();
         }
         archivo1.close();
         //dejamos la colecci�n cargada y la aplicaci�n lista para a�adir nuevas cartas
         jMenuCartasNueva_actionPerformed(e);
       }

       catch (Exception error) {
         //mostramos con un JOptionPane el error producido
         JOptionPane.showMessageDialog(this, error.getMessage(), "Error",
                                       JOptionPane.ERROR_MESSAGE);
       }
     }
  }

  /**
   * Funci�n que codifica los bytes que se quieren grabar
   * @param fraseBytes bytes que se desean grabar
   * @return String frase codificada
   */
  private String codificar(byte[] fraseBytes){
    String frase = "";
    int i=0;
    while (i<fraseBytes.length){
      char a;
      if(fraseBytes[i]<0)
        //car�cter espepecial (�, �, �, �, �, �, ...)
        a = (char) (256 + fraseBytes[i] - 2);
      else
        a = (char) (fraseBytes[i] - 2);
      frase=frase+a;
      i++;
    }
    return frase;
  }

  /**
   * Funci�n actionPerfomed que controla cuando se pulsa el bot�n de jMenuFileGuardar
   * @param e
   */
  void jMenuFileGuardar_actionPerformed(ActionEvent e) {
    JFileChooser archivo = new JFileChooser(".");
    //ponemos un filtro para seleccionar el archivo
    archivo.setFileFilter(new FiltroURLCartas());
    archivo.setFileSelectionMode(JFileChooser.FILES_ONLY);
    //mostramos un OpenDialog para seleccionar el fichero de cartas
    if (archivo.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
      //controlamos la carga del fichero mediante excepciones
      try {
        String nombreArchivo = archivo.getSelectedFile().getName();
        if (!nombreArchivo.endsWith(".car"))
          nombreArchivo=nombreArchivo+".car";
        //los archivos ".car" son para guardar las cartas codificadas
        FileOutputStream archivo1 = new FileOutputStream(nombreArchivo);
        //pedimos los codigos de todas las cartas de la colecci�n
        Enumeration enum = this.BD.pedirCodigos();
        while(enum.hasMoreElements()){
          String codigoCartaAGuardar = (String)enum.nextElement();

          Carta cartaAGuardar = this.BD.pedirCarta(codigoCartaAGuardar);
          //escribimos cada uno de los campos de la carta en el archivo
          archivo1.write(cartaAGuardar.getCodigo().length());
          archivo1.write(codificar(cartaAGuardar.getCodigo().getBytes()).getBytes());
          archivo1.write(cartaAGuardar.getRaza().length());
          archivo1.write(codificar(cartaAGuardar.getRaza().getBytes()).getBytes());
          archivo1.write(cartaAGuardar.getTipo().length());
          archivo1.write(codificar(cartaAGuardar.getTipo().getBytes()).getBytes());
          archivo1.write(cartaAGuardar.getNombre().length());
          archivo1.write(codificar(cartaAGuardar.getNombre().getBytes()).getBytes());
          archivo1.write(cartaAGuardar.getNivel().byteValue());
          String puntosEnLetra = cartaAGuardar.getPuntos().toString();
          archivo1.write(puntosEnLetra.length());
          archivo1.write(codificar(puntosEnLetra.getBytes()).getBytes());
          archivo1.write(cartaAGuardar.getAtaque().byteValue());
          archivo1.write(cartaAGuardar.getDefensa().byteValue());
          archivo1.write(cartaAGuardar.getCoste().byteValue());
          archivo1.write(cartaAGuardar.getVida().byteValue());

          //los numeros de letras que hay que leer de descripMov tambi�n se codifican
          String longitudDescripMov = (new Integer(cartaAGuardar.getDescripMov().length())).toString();
          archivo1.write(longitudDescripMov.length());
          archivo1.write(codificar(longitudDescripMov.getBytes()).getBytes());
          archivo1.write(codificar(cartaAGuardar.getDescripMov().getBytes()).getBytes());

          //los numeros de letras que hay que leer de descripHab tambi�n se codifican
          String longitudDescripHab = (new Integer(cartaAGuardar.getDescripHab().length())).toString();
          archivo1.write(longitudDescripHab.length());
          archivo1.write(codificar(longitudDescripHab.getBytes()).getBytes());
          archivo1.write(codificar(cartaAGuardar.getDescripHab().getBytes()).getBytes());
        }
        archivo1.close();
      }
      catch (Exception error) {
        //mostramos con un JOptionPane el error producido
        JOptionPane.showMessageDialog(this, error.getMessage(), "Error",
                                      JOptionPane.ERROR_MESSAGE);
      }
    }
  }


  /**
   * Funci�n actionPerfomed que controla cuando se pulsa el bot�n de jMenuFileExit
   * @param e
   */
  void jMenuFileExit_actionPerformed(ActionEvent e) {
    System.exit(0);
  }

  /**
   * Funci�n actionPerfomed que controla cuando se pulsa el bot�n de jMenuCartasNueva
   * @param e
   */
  void jMenuCartasNueva_actionPerformed(ActionEvent e) {
    //inicializamos todos los campos
    this.textoNombre.setText("");
    this.comboBoxRaza.setSelectedIndex(0);
    this.comboBoxTipo.setSelectedIndex(0);
    this.comboBoxAtaque.setSelectedIndex(0);
    this.comboBoxDefensa.setSelectedIndex(0);
    this.comboBoxCoste.setSelectedIndex(0);
    this.textoPuntos.setText("");
    this.textoNivel.setText("");
    this.boton1Vida.setSelected(true);
    this.boton2Vidas.setSelected(false);
    this.boton3Vidas.setSelected(false);
    this.textoComenHab.setText("");
    this.textoComenMovil.setText("");
    this.botonImagen.setIcon(null);
    this.botonImagen.setText("Pinche aqui para ver la imagen");
  }

  /**
   * Funci�n actionPerfomed que controla cuando se pulsa el bot�n de jMenuCartasModificar
   * @param e
   */
  void jMenuCartasCargar_actionPerformed(ActionEvent e) {
     try{
       String[] modo = {"Por nombre", "Por c�digo"};
       int opcion = JOptionPane.showOptionDialog(this,
                                                 "�C�mo quieres buscar la carta?",
                                                 "Eleccion de modo", -1,
                                                 JOptionPane.QUESTION_MESSAGE,
                                                 null, modo, modo[0]);
       Carta cartaSeleccionada = null;
       if (opcion == 0) {  //petici�n por nombre
         String nombreCarta = JOptionPane.showInputDialog(this,
             "�C�al es el nombre de la carta?",
             "Petici�n del nombre", JOptionPane.QUESTION_MESSAGE);
         if (nombreCarta != null) {
           String codigoCarta = this.BD.pedirCodigo(nombreCarta);
           cartaSeleccionada = this.BD.pedirCarta(codigoCarta);
         }
       }
       if (opcion == 1) {  //petici�n por c�digo
         String codigoCarta = JOptionPane.showInputDialog(this,
             "�C�al es el c�digo de la carta?",
             "Petici�n de c�digo", JOptionPane.QUESTION_MESSAGE);
         if (codigoCarta != null) {
           cartaSeleccionada = this.BD.pedirCarta(codigoCarta);
         }
       }
       if (cartaSeleccionada != null) {
         //Mostrar la carta
         this.comboBoxRaza.setSelectedItem(cartaSeleccionada.getRaza());
         this.comboBoxTipo.setSelectedItem(cartaSeleccionada.getTipo());
         this.textoNombre.setText(cartaSeleccionada.getNombre());
         this.comboBoxAtaque.setSelectedItem(cartaSeleccionada.getAtaque());
         this.comboBoxDefensa.setSelectedItem(cartaSeleccionada.getDefensa());
         this.comboBoxCoste.setSelectedItem(cartaSeleccionada.getCoste());
         this.textoPuntos.setText(cartaSeleccionada.getPuntos().toString());
         this.textoNivel.setText(cartaSeleccionada.getNivel().toString());
         if (cartaSeleccionada.getVida().intValue() == 1) {
           this.boton1Vida.setSelected(true);
           this.boton2Vidas.setSelected(false);
           this.boton3Vidas.setSelected(false);
         }
         else if (cartaSeleccionada.getVida().intValue() == 2) {
           this.boton1Vida.setSelected(false);
           this.boton2Vidas.setSelected(true);
           this.boton3Vidas.setSelected(false);
         }
         else {
           this.boton1Vida.setSelected(false);
           this.boton2Vidas.setSelected(false);
           this.boton3Vidas.setSelected(true);
         }
         this.textoComenHab.setText(cartaSeleccionada.getDescripHab());
         this.textoComenMovil.setText(cartaSeleccionada.getDescripMov());
         this.textoCodigo.setText(cartaSeleccionada.getCodigo());
         botonImagen_actionPerformed(e);
       }
     }
     catch (Exception error) {
       //mostramos con un JOptionPane el error producido
       JOptionPane.showMessageDialog(this, error.getMessage(), "Error",
                                     JOptionPane.ERROR_MESSAGE);
     }
  }

  /**
   * Funci�n actionPerfomed que controla cuando se pulsa el bot�n de jMenuCartasEliminar
   * @param e
   */
  void jMenuCartasEliminar_actionPerformed(ActionEvent e) {
     try{
       String[] modo = {"Por nombre", "Por c�digo"};
       int opcion = JOptionPane.showOptionDialog(this,
                                                 "�C�mo quieres buscar la carta?",
                                                 "Eleccion de modo", -1,
                                                 JOptionPane.QUESTION_MESSAGE,
                                                 null, modo, modo[0]);
       if (opcion == 0) {  //petici�n por nombre
         String nombreCarta = JOptionPane.showInputDialog(this,
             "�C�al es el nombre de la carta?",
             "Petici�n del nombre", JOptionPane.QUESTION_MESSAGE);
         if (nombreCarta != null) {
           String codigoCarta = this.BD.pedirCodigo(nombreCarta);
           boolean cartaBorrada = this.BD.eliminarCarta(codigoCarta);
           if (!cartaBorrada)
             JOptionPane.showMessageDialog(this, "Ese c�digo no existe", "Aviso",
                                           JOptionPane.INFORMATION_MESSAGE);
         }
       }
       if (opcion == 1) {  //petici�n por c�digo
         String codigoCarta = JOptionPane.showInputDialog(this,
             "�C�al es el c�digo de la carta?",
             "Petici�n de c�digo", JOptionPane.QUESTION_MESSAGE);
         if (codigoCarta != null) {
           boolean cartaBorrada = this.BD.eliminarCarta(codigoCarta);
           if (!cartaBorrada)
             JOptionPane.showMessageDialog(this, "Ese c�digo no existe", "Aviso",
                                           JOptionPane.INFORMATION_MESSAGE);
         }
       }
     }
     catch (Exception error) {
       //mostramos con un JOptionPane el error producido
       JOptionPane.showMessageDialog(this, error.getMessage(), "Error",
                                     JOptionPane.ERROR_MESSAGE);
     }
  }

  /**
   * Funci�n actionPerfomed que controla cuando se pulsa el bot�n de jMenuHelpAyuda
   * @param e
   */
  void jMenuHelpAyuda_actionPerformed(ActionEvent e){
    JEditorPane ayuda = new JEditorPane();
    try {
      ayuda.setPage("file:./documentos/ayuda.txt");
      ayuda.setEditable(false);
      //mostramos en un JFrame el fichero de ayuda.txt
      JTextPane texto = new JTextPane();
      texto.setEditable(false);
      texto.setText(ayuda.getText());
      JPanel panelAux = new JPanel();
      panelAux.add(texto);
      JScrollPane scrollPaneAux = new JScrollPane(panelAux);
      scrollPaneAux.setPreferredSize(new Dimension(650,600));

      //componente para mostrar el escudo de G�nesis
      JLabel escudo=new JLabel();
      escudo.setIcon(new ImageIcon("../../Cartas/Escudo_genesis.jpg"));
      JPanel panelAux2 = new JPanel();
      panelAux2.add(escudo);

      JSplitPane splitPaneAux=new JSplitPane();
      splitPaneAux.setLeftComponent(panelAux2);
      splitPaneAux.setRightComponent(scrollPaneAux);
      splitPaneAux.setOrientation(JSplitPane.HORIZONTAL_SPLIT);
      splitPaneAux.setDividerLocation(200);
      splitPaneAux.setBorder(null);
      splitPaneAux.setEnabled(false);

      JFrame frame=new JFrame();
      JPanel contentPane = (JPanel) frame.getContentPane();
      contentPane.add(splitPaneAux);
      frame.setTitle("Ayuda");
      frame.pack();
      frame.setVisible(true);
    }
    catch (Exception error) {
      //mostramos con un JOptionPane el error producido
      JOptionPane.showMessageDialog(this, error.getMessage(), "Error",
                                    JOptionPane.ERROR_MESSAGE);
    }
  }

  /**
   * Funci�n actionPerfomed que controla cuando se pulsa el bot�n de jMenuHelpAbout
   * @param e
   */
  void jMenuHelpAbout_actionPerformed(ActionEvent e) {
    JOptionPane.showMessageDialog(this,"Editor de la colecci�n de las cartas codificada para G�nesis.\n"+
                                  "Copyright (c) 2004\n"+
                                  "Version 1.0\n" +
                                  "Por: Miguel Cayeiro Garcia",
                                  "Acerca de...",
                                  JOptionPane.INFORMATION_MESSAGE,
                                  new ImageIcon("../../Cartas/Escudo_genesis.jpg"));
  }

  /**
   * Funci�n actionPerfomed que controla cuando se pulsa el bot�n de boton1Vida
   * @param e
   */
  void boton1Vida_actionPerformed(ActionEvent e) {
    //solo puede haber un bot�n de vida en cada momento
    if(!boton1Vida.isSelected()){
      this.boton1Vida.setSelected(true);
    }
    this.boton2Vidas.setSelected(false);
    this.boton3Vidas.setSelected(false);
  }

  /**
   * Funci�n actionPerfomed que controla cuando se pulsa el bot�n de boton2Vidas
   * @param e
   */
  void boton2Vidas_actionPerformed(ActionEvent e) {
    //solo puede haber un bot�n de vida en cada momento
    if(!boton2Vidas.isSelected()){
      this.boton2Vidas.setSelected(true);
    }
    this.boton1Vida.setSelected(false);
    this.boton3Vidas.setSelected(false);
  }

  /**
   * Funci�n actionPerfomed que controla cuando se pulsa el bot�n de boton3Vidas
   * @param e
   */
  void boton3Vidas_actionPerformed(ActionEvent e) {
    //solo puede haber un bot�n de vida en cada momento
    if(!boton3Vidas.isSelected()){
      this.boton3Vidas.setSelected(true);
    }
    this.boton1Vida.setSelected(false);
    this.boton2Vidas.setSelected(false);
  }

  /**
   * Funci�n actionPerfomed que controla cuando se pulsa el bot�n de comboBoxRaza
   * @param e
   */
  void comboBoxRaza_actionPerformed(ActionEvent e) {
    //para facilitar la visi�n de la raza, se ponen todos los campos en un color
    //y se actualiza su c�digo por la raza
    if(comboBoxRaza.getSelectedItem().equals("Angeles")){
      //Angeles = blanco
      this.textoNombre.setForeground(Color.white);
      this.comboBoxRaza.setForeground(Color.white);
      this.comboBoxTipo.setForeground(Color.white);
      this.comboBoxAtaque.setForeground(Color.white);
      this.comboBoxDefensa.setForeground(Color.white);
      this.comboBoxCoste.setForeground(Color.white);
      this.textoPuntos.setForeground(Color.white);
      this.textoNivel.setForeground(Color.white);
      this.textoComenHab.setForeground(Color.white);
      this.textoComenMovil.setForeground(Color.white);
      this.textoCodigo.setForeground(Color.white);
      this.textoCodigo.setText(this.BD.getCodigoA());
    }
    else if(comboBoxRaza.getSelectedItem().equals("Demonios")){
      //Demonios = rojo
      this.textoNombre.setForeground(Color.red);
      this.comboBoxRaza.setForeground(Color.red);
      this.comboBoxTipo.setForeground(Color.red);
      this.comboBoxAtaque.setForeground(Color.red);
      this.comboBoxDefensa.setForeground(Color.red);
      this.comboBoxCoste.setForeground(Color.red);
      this.textoPuntos.setForeground(Color.red);
      this.textoNivel.setForeground(Color.red);
      this.textoComenHab.setForeground(Color.red);
      this.textoComenMovil.setForeground(Color.red);
      this.textoCodigo.setForeground(Color.red);
      this.textoCodigo.setText(this.BD.getCodigoD());
    }
    else if(comboBoxRaza.getSelectedItem().equals("Humanos")){
      //Humanos = verde
      Color verde = new Color(0, 230, 70);
      this.textoNombre.setForeground(verde);
      this.comboBoxRaza.setForeground(verde);
      this.comboBoxTipo.setForeground(verde);
      this.comboBoxAtaque.setForeground(verde);
      this.comboBoxDefensa.setForeground(verde);
      this.comboBoxCoste.setForeground(verde);
      this.textoPuntos.setForeground(verde);
      this.textoNivel.setForeground(verde);
      this.textoComenHab.setForeground(verde);
      this.textoComenMovil.setForeground(verde);
      this.textoCodigo.setForeground(verde);
      this.textoCodigo.setText(this.BD.getCodigoH());
    }
    else if(comboBoxRaza.getSelectedItem().equals("Inmortales")){
      //Inmortales = morado
      Color morado = new Color(250, 50, 200);
      this.textoNombre.setForeground(morado);
      this.comboBoxRaza.setForeground(morado);
      this.comboBoxTipo.setForeground(morado);
      this.comboBoxAtaque.setForeground(morado);
      this.comboBoxDefensa.setForeground(morado);
      this.comboBoxCoste.setForeground(morado);
      this.textoPuntos.setForeground(morado);
      this.textoNivel.setForeground(morado);
      this.textoComenHab.setForeground(morado);
      this.textoComenMovil.setForeground(morado);
      this.textoCodigo.setForeground(morado);
      this.textoCodigo.setText(this.BD.getCodigoI());
    }
    else
      //mostramos con un JOptionPane el error producido
      JOptionPane.showMessageDialog(this, "La raza no existe en ComboBoxRaza", "Error",
                                    JOptionPane.ERROR_MESSAGE);
  }

  /**
   * Funci�n actionPerfomed que controla cuando se pulsa el bot�n de comboBoxTipo
   * @param e
   */
  void comboBoxTipo_actionPerformed(ActionEvent e) {
    //se anulan los campos en los cuales no puede haber nada para ese tipo
    if(comboBoxTipo.getSelectedItem().equals("Conjuro")){
      this.comboBoxAtaque.setEnabled(false);
      this.comboBoxDefensa.setEnabled(false);
      this.comboBoxCoste.setEnabled(true);
      this.boton1Vida.setEnabled(false);
      this.boton2Vidas.setEnabled(false);
      this.boton3Vidas.setEnabled(false);
      if(this.comboBoxAtaque.isLightweight())
        this.comboBoxAtaque.setSelectedIndex(0);
      if(this.comboBoxDefensa.isLightweight())
        this.comboBoxDefensa.setSelectedIndex(0);
      if(this.comboBoxCoste.isLightweight())
        this.comboBoxCoste.setSelectedIndex(0);
      this.textoPuntos.setText("");
      this.textoNivel.setText("");
      this.boton1Vida.setSelected(true);
      this.boton2Vidas.setSelected(false);
      this.boton3Vidas.setSelected(false);
    }
    else if(comboBoxTipo.getSelectedItem().equals("Criatura")){
      this.comboBoxAtaque.setEnabled(true);
      this.comboBoxDefensa.setEnabled(true);
      this.comboBoxCoste.setEnabled(true);
      this.boton1Vida.setEnabled(true);
      this.boton2Vidas.setEnabled(true);
      this.boton3Vidas.setEnabled(true);
      if(this.comboBoxAtaque.isLightweight())
        this.comboBoxAtaque.setSelectedIndex(0);
      if(this.comboBoxDefensa.isLightweight())
        this.comboBoxDefensa.setSelectedIndex(0);
      if(this.comboBoxCoste.isLightweight())
        this.comboBoxCoste.setSelectedIndex(0);
      this.textoPuntos.setText("");
      this.textoNivel.setText("");
      this.boton1Vida.setSelected(true);
      this.boton2Vidas.setSelected(false);
      this.boton3Vidas.setSelected(false);
    }
    else if(comboBoxTipo.getSelectedItem().equals("Hechizo")){
      this.comboBoxAtaque.setEnabled(false);
      this.comboBoxDefensa.setEnabled(false);
      this.comboBoxCoste.setEnabled(true);
      this.boton1Vida.setEnabled(false);
      this.boton2Vidas.setEnabled(false);
      this.boton3Vidas.setEnabled(false);
      if(this.comboBoxAtaque.isLightweight())
        this.comboBoxAtaque.setSelectedIndex(0);
      if(this.comboBoxDefensa.isLightweight())
        this.comboBoxDefensa.setSelectedIndex(0);
      if(this.comboBoxCoste.isLightweight())
        this.comboBoxCoste.setSelectedIndex(0);
      this.textoPuntos.setText("");
      this.textoNivel.setText("");
      this.boton1Vida.setSelected(true);
      this.boton2Vidas.setSelected(false);
      this.boton3Vidas.setSelected(false);
    }
    else if(comboBoxTipo.getSelectedItem().equals("Mana")){
      this.comboBoxAtaque.setEnabled(false);
      this.comboBoxDefensa.setEnabled(false);
      this.comboBoxCoste.setEnabled(false);
      this.boton1Vida.setEnabled(false);
      this.boton2Vidas.setEnabled(false);
      this.boton3Vidas.setEnabled(false);
      if(this.comboBoxAtaque.isLightweight())
        this.comboBoxAtaque.setSelectedIndex(0);
      if(this.comboBoxDefensa.isLightweight())
        this.comboBoxDefensa.setSelectedIndex(0);
      if(this.comboBoxCoste.isLightweight())
        this.comboBoxCoste.setSelectedIndex(0);
      this.textoPuntos.setText("");
      this.textoNivel.setText("");
      this.boton1Vida.setSelected(true);
      this.boton2Vidas.setSelected(false);
      this.boton3Vidas.setSelected(false);
    }
    else
      //mostramos con un JOptionPane el error producido
      JOptionPane.showMessageDialog(this, "El tipo no existe en ComboBoxTipo", "Error",
                                    JOptionPane.ERROR_MESSAGE);
  }

  /**
   * Funci�n actionPerfomed que controla cuando se pulsa el bot�n de botonImagen
   * @param e
   */
  void botonImagen_actionPerformed(ActionEvent e) {
    /*
     muestra la imagen de la carta si esta existe
     la direcci�n sera:
     ../../Cartas/"Raza"/"Tipo"/"nombre de la carta"
     */
    String direccionCarta = "../../Cartas/"+
        (String)this.comboBoxRaza.getSelectedItem()+"/"+
        (String)this.comboBoxTipo.getSelectedItem();
    //si es distinto de Mana la direcci�n del tipo esta en plural
    if (!((String)this.comboBoxTipo.getSelectedItem()).equals("Mana"))
      direccionCarta = direccionCarta+"s";
    direccionCarta = direccionCarta+"/"+this.textoNombre.getText()+".jpg";

    ImageIcon icono = new  ImageIcon(direccionCarta);
    if (icono.getIconHeight()>0 && icono.getIconWidth()>0){
      //se muestra la imagen
      this.botonImagen.setIcon(icono);
      this.botonImagen.setText("");
    }
    else{
      //la imagen no esta disponible, se muestra la parte de atras de la carta (la raza)
      direccionCarta = "../../Cartas/" + (String)this.comboBoxRaza.getSelectedItem()+"/";
      direccionCarta = direccionCarta + (String)this.comboBoxRaza.getSelectedItem()+".jpg";
      this.botonImagen.setIcon(new ImageIcon(direccionCarta));
      this.botonImagen.setText("");
    }
  }

  /**
   * Funci�n actionPerfomed que controla cuando se pulsa el bot�n de botonMostrar
   * @param e
   */
  void botonMostrar_actionPerformed(ActionEvent e) {
    int puntos;
    int coste = ((Integer)(this.comboBoxCoste.getSelectedItem())).intValue();
    if (coste == 0)
      coste = 1;
    if(this.comboBoxTipo.getSelectedItem().equals("Criatura")){
      //coste de una criatura
      int ataque = ((Integer)(this.comboBoxAtaque.getSelectedItem())).intValue();
      if (ataque == 0)
        ataque = 1;
      int defensa = ((Integer)(this.comboBoxDefensa.getSelectedItem())).intValue();
      if (defensa == 0)
        defensa = 1;
      if (this.boton1Vida.isSelected())
        puntos =( ataque * defensa * 40)/coste;
      else
        puntos =( ataque * defensa * 60)/coste;
    }
    else if(this.comboBoxTipo.getSelectedItem().equals("Conjuro")){
      //coste de un conjuro o hechizo
      if(coste==1)
        puntos = 100;
      else if(coste==2)
        puntos = 200;
      else if(coste==3)
        puntos = 300;
      else if(coste==4)
        puntos = 500;
      else if(coste==5)
        puntos = 700;
      else if(coste==6)
        puntos = 1000;
      else if(coste==7)
        puntos = 1500;
      else
        puntos = 2000;
    }
    else if (this.comboBoxTipo.getSelectedItem().equals("Hechizo")){
      //coste de un conjuro o hechizo
      if(coste==1)
        puntos = 100;
      else if(coste==2)
        puntos = 200;
      else if(coste==3)
        puntos = 500;
      else if(coste==4)
        puntos = 700;
      else if(coste==5)
        puntos = 1000;
      else
        puntos = 2000;
    }
    else {
      //coste de mana o cualquier otro tipo de carta que se a�ada
      puntos = 500;
    }
    this.textoPuntos.setText(new Integer(puntos).toString());

    //el nivel 3 es el m�s bajo, el nivel 1 el m�s alto
    if (puntos < 250)
      this.textoNivel.setText("3");
    else if (puntos < 800)
      this.textoNivel.setText("2");
    else
      this.textoNivel.setText("1");
  }

  /**
   * Funci�n actionPerfomed que controla cuando se pulsa el bot�n de botonAnadir
   * @param e
   */
  void botonAnadir_actionPerformed(ActionEvent e) {
    String codigo, raza, tipo, nombre, descripMov, descripHab;
    Integer nivel, puntos, ataque, defensa, coste, vida;
    this.botonMostrar_actionPerformed(e);
    codigo = this.textoCodigo.getText();
    raza = (String)this.comboBoxRaza.getSelectedItem();
    tipo = (String)this.comboBoxTipo.getSelectedItem();
    nombre = this.textoNombre.getText();
    nivel = new Integer(this.textoNivel.getText());
    puntos = new Integer(this.textoPuntos.getText());
    ataque = (Integer)this.comboBoxAtaque.getSelectedItem();
    defensa = (Integer)this.comboBoxDefensa.getSelectedItem();
    coste = (Integer)this.comboBoxCoste.getSelectedItem();
    if (this.boton1Vida.isSelected())
      vida = new Integer(1);
    else if (this.boton2Vidas.isSelected())
      vida = new Integer(2);
    else
      vida = new Integer(3);
    descripMov = this.textoComenMovil.getText();
    descripHab = this.textoComenHab.getText();
    Carta cartaNueva = new Carta(codigo, raza, tipo, nombre, nivel, puntos, ataque,
                                 defensa, coste, vida, descripMov, descripHab);
    try{
      //a�adimos la nueva carta a la colecci�n
      this.BD.anadir(cartaNueva);
      if (raza.equals("Angeles"))
        this.textoCodigo.setText( this.BD.getCodigoA());
      else if (raza.equals("Demonios"))
        this.textoCodigo.setText( this.BD.getCodigoD());
      else if (raza.equals("Humanos"))
        this.textoCodigo.setText( this.BD.getCodigoH());
      else if (raza.equals("Inmortales"))
        this.textoCodigo.setText( this.BD.getCodigoI());
    }
    catch(Exception error) {
      //mostramos con un JOptionPane el error producido
      JOptionPane.showMessageDialog(this, error.getMessage(), "Error",
                                    JOptionPane.ERROR_MESSAGE);
    }
  }

  //M�todo Main
  public static void main(String[] args) {
    try {
      UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
    }
    catch(Exception error) {
      error.printStackTrace();
    }
    JFrame jf=new EditorImp();
    jf.pack();

    //Centrar la ventana
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = jf.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }
    jf.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
    jf.setVisible(true);
  }
}