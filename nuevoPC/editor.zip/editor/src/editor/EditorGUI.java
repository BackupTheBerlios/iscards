package editor;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * <p>T�tulo: Editor</p>
 * <p>Descripci�n: Editor de la base de datos de las cartas para G�nesis</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Empresa: </p>
 * @author Miguel Cayeiro Garc�a
 * @version 2.0
 */

/**
 * Clase que usamos para los gr�ficos del editor
 */
abstract public class EditorGUI extends JFrame {
  JPanel contentPane;
  BorderLayout borderLayout1 = new BorderLayout();

  //Variables pertenecientes al menu
  JMenuBar jMenuBar1 = new JMenuBar();
  JMenu jMenuFile = new JMenu();
  JMenuItem jMenuFileNuevo = new JMenuItem();
  JMenuItem jMenuFileCargar = new JMenuItem();
  JMenuItem jMenuFileGuardar = new JMenuItem();
  JMenuItem jMenuFileGuardarComo = new JMenuItem();
  JMenuItem jMenuFileExit = new JMenuItem();
  JMenu jMenuCartas = new JMenu();
  JMenuItem jMenuCartasNueva = new JMenuItem();
  JMenuItem jMenuCartasCargar = new JMenuItem();
  JMenuItem jMenuCartasEliminar = new JMenuItem();
  JMenu jMenuHelp = new JMenu();
  JMenuItem jMenuHelpAyuda = new JMenuItem();
  JMenuItem jMenuHelpAbout = new JMenuItem();

  //Variables de los separadores
  JSplitPane jSplitPane1 = new JSplitPane();
  JSplitPane jSplitPane2 = new JSplitPane();
  JSplitPane jSplitPane3 = new JSplitPane();
  JSplitPane jSplitPane4 = new JSplitPane();
  JSplitPane jSplitPane5 = new JSplitPane();
  JSplitPane jSplitPane6 = new JSplitPane();
  JSplitPane jSplitPane7 = new JSplitPane();
  JSplitPane jSplitPane8 = new JSplitPane();
  JSplitPane jSplitPane9 = new JSplitPane();
  JSplitPane jSplitPane10 = new JSplitPane();
  JSplitPane jSplitPane11 = new JSplitPane();
  JSplitPane jSplitPane12 = new JSplitPane();
  JSplitPane jSplitPane13 = new JSplitPane();
  JSplitPane jSplitPane14 = new JSplitPane();

  //Variables de las cajas contenedoras
  Box box1;
  Box box2;
  Box box3;
  Box box4;
  Box box5;
  Box box6;
  Box box7;
  Box box8;
  Box box9;
  Box box10;
  Box box11;
  Box box12;

  //Variables de los componentes
  JLabel labelNombre = new JLabel();
  JLabel labelRaza = new JLabel();
  JLabel labelTipo = new JLabel();
  JLabel labelAtaque = new JLabel();
  JLabel labelDefensa = new JLabel();
  JLabel labelCoste = new JLabel();
  JLabel labelPuntos = new JLabel();
  JLabel labelVida = new JLabel();
  JLabel labelNivel = new JLabel();
  JLabel labelComenHab = new JLabel();
  JLabel labelComenMovil = new JLabel();
  JLabel labelCodigo = new JLabel();

  JTextField textoNombre = new JTextField();
  JTextField textoPuntos = new JTextField();
  JTextField textoNivel = new JTextField();
  JTextField textoCodigo = new JTextField();

  JComboBox comboBoxRaza = new JComboBox();
  JComboBox comboBoxTipo = new JComboBox();
  JComboBox comboBoxAtaque = new JComboBox();
  JComboBox comboBoxDefensa = new JComboBox();
  JComboBox comboBoxCoste = new JComboBox();

  JRadioButton boton1Vida = new JRadioButton();
  JRadioButton boton2Vidas = new JRadioButton();
  JRadioButton boton3Vidas = new JRadioButton();

  JScrollPane jScrollPane1 = new JScrollPane();
  JTextPane textoComenHab = new JTextPane();
  JScrollPane jScrollPane2 = new JScrollPane();
  JTextPane textoComenMovil = new JTextPane();

  JButton botonMostrar = new JButton();
  JButton botonAnadir = new JButton();
  JButton botonImagen = new JButton();

  /**
   * Constructor la pantalla del editor
   */
  public EditorGUI() {
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    try {
      jbInit();
      crearMenu();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  /**
   * Funci�n que inicializa todos los componentes de la pantalla del editor
   */
  private void jbInit() throws Exception  {
    contentPane = (JPanel) this.getContentPane();
    box1 = Box.createVerticalBox();
    box2 = Box.createHorizontalBox();
    box3 = Box.createHorizontalBox();
    box4 = Box.createHorizontalBox();
    box5 = Box.createHorizontalBox();
    box6 = Box.createHorizontalBox();
    box7 = Box.createHorizontalBox();
    box8 = Box.createVerticalBox();
    box9 = Box.createHorizontalBox();
    box10 = Box.createVerticalBox();
    box11 = Box.createVerticalBox();
    box12 = Box.createHorizontalBox();
    contentPane.setLayout(borderLayout1);
    this.setEnabled(true);
    this.setLocale(java.util.Locale.getDefault());
    this.setResizable(false);
    this.setSize(new Dimension(750, 600));
    this.setState(Frame.NORMAL);

    contentPane.setMinimumSize(new Dimension(750, 600));
    contentPane.setPreferredSize(new Dimension(750, 600));
    contentPane.setRequestFocusEnabled(true);

    //color para el fondo de los botones
    Color colorFondo = new Color(58,110,165);

    //componentes para el c�digo
    labelCodigo.setForeground(Color.blue);
    labelCodigo.setFont(new java.awt.Font("Dialog", 0, 20));
    labelCodigo.setText(" Codigo: ");
    textoCodigo.setHorizontalAlignment(SwingConstants.CENTER);
    textoCodigo.setForeground(Color.white);
    textoCodigo.setEditable(false);
    textoCodigo.setBackground(colorFondo);
    textoCodigo.setEnabled(true);
    textoCodigo.setFont(new java.awt.Font("Dialog", 1, 15));

    //componentes para la raza
    labelRaza.setText(" Raza: ");
    labelRaza.setFont(new java.awt.Font("Dialog", 0, 20));
    labelRaza.setForeground(Color.blue);
    comboBoxRaza.setBackground(colorFondo);
    comboBoxRaza.setFont(new java.awt.Font("Dialog", 0, 20));
    comboBoxRaza.setForeground(Color.white);
    comboBoxRaza.addItem("�ngeles");
    comboBoxRaza.addItem("Demonios");
    comboBoxRaza.addItem("Humanos");
    comboBoxRaza.addItem("Inmortales");
    comboBoxRaza.addActionListener(new EditorGUI_comboBoxRaza_actionAdapter(this));

    //componentes para el tipo
    labelTipo.setText(" Tipo: ");
    labelTipo.setFont(new java.awt.Font("Dialog", 0, 20));
    labelTipo.setForeground(Color.blue);
    comboBoxTipo.setBackground(colorFondo);
    comboBoxTipo.setFont(new java.awt.Font("Dialog", 0, 20));
    comboBoxTipo.setForeground(Color.white);
    comboBoxTipo.addActionListener(new EditorGUI_comboBoxTipo_actionAdapter(this));
    comboBoxTipo.addItem("Conjuro");
    comboBoxTipo.addItem("Criatura");
    comboBoxTipo.addItem("Hechizo");
    comboBoxTipo.addItem("Mana");

    //componentes para el nombre
    labelNombre.setFont(new java.awt.Font("Dialog", 0, 22));
    labelNombre.setForeground(Color.blue);
    labelNombre.setText(" Nombre de la carta:");
    textoNombre.setBackground(colorFondo);
    textoNombre.setFont(new java.awt.Font("Dialog", 0, 22));
    textoNombre.setForeground(Color.white);
    textoNombre.setHorizontalAlignment(SwingConstants.LEFT);

    //componentes para el nivel
    labelNivel.setText(" Nivel: ");
    labelNivel.setFont(new java.awt.Font("Dialog", 0, 20));
    labelNivel.setForeground(Color.blue);
    textoNivel.setHorizontalAlignment(SwingConstants.CENTER);
    textoNivel.setForeground(Color.white);
    textoNivel.setEditable(false);
    textoNivel.setBackground(colorFondo);
    textoNivel.setEnabled(true);
    textoNivel.setFont(new java.awt.Font("Dialog", 1, 15));

    //componentes para los puntos
    labelPuntos.setText(" Puntos: ");
    labelPuntos.setFont(new java.awt.Font("Dialog", 0, 20));
    labelPuntos.setForeground(Color.blue);
    textoPuntos.setHorizontalAlignment(SwingConstants.CENTER);
    textoPuntos.setForeground(Color.white);
    textoPuntos.setEditable(false);
    textoPuntos.setBackground(colorFondo);
    textoPuntos.setEnabled(true);
    textoPuntos.setFont(new java.awt.Font("Dialog", 1, 15));

    //componentes para el ataque
    labelAtaque.setText(" Ataque: ");
    labelAtaque.setFont(new java.awt.Font("Dialog", 0, 20));
    labelAtaque.setForeground(Color.blue);
    comboBoxAtaque.setBackground(colorFondo);
    comboBoxAtaque.setFont(new java.awt.Font("Dialog", 1, 17));
    comboBoxAtaque.setForeground(Color.white);
    comboBoxAtaque.setMaximumSize(new Dimension(130, 30));
    comboBoxAtaque.setMinimumSize(new Dimension(20, 21));
    comboBoxAtaque.setPreferredSize(new Dimension(70, 21));
    comboBoxAtaque.addItem(new Integer(0));
    comboBoxAtaque.addItem(new Integer(1));
    comboBoxAtaque.addItem(new Integer(2));
    comboBoxAtaque.addItem(new Integer(3));
    comboBoxAtaque.addItem(new Integer(4));
    comboBoxAtaque.addItem(new Integer(5));
    comboBoxAtaque.addItem(new Integer(6));
    comboBoxAtaque.addItem(new Integer(7));
    comboBoxAtaque.addItem(new Integer(8));
    comboBoxAtaque.addItem(new Integer(9));
    comboBoxAtaque.addItem(new Integer(10));
    comboBoxAtaque.addItem(new Integer(11));
    comboBoxAtaque.addItem(new Integer(12));
    comboBoxAtaque.addItem(new Integer(13));
    comboBoxAtaque.addItem(new Integer(14));
    comboBoxAtaque.addItem(new Integer(15));
    comboBoxAtaque.addItem(new Integer(16));
    comboBoxAtaque.addItem(new Integer(17));

    //componentes para la defensa
    labelDefensa.setText(" Defensa: ");
    labelDefensa.setFont(new java.awt.Font("Dialog", 0, 20));
    labelDefensa.setForeground(Color.blue);
    labelDefensa.setMaximumSize(new Dimension(91, 26));
    comboBoxDefensa.setBackground(colorFondo);
    comboBoxDefensa.setFont(new java.awt.Font("Dialog", 1, 17));
    comboBoxDefensa.setForeground(Color.white);
    comboBoxDefensa.setAutoscrolls(false);
    comboBoxDefensa.setMaximumSize(new Dimension(120, 30));
    comboBoxDefensa.setMinimumSize(new Dimension(50, 21));
    comboBoxDefensa.setPreferredSize(new Dimension(50, 21));
    comboBoxDefensa.addItem(new Integer(0));
    comboBoxDefensa.addItem(new Integer(1));
    comboBoxDefensa.addItem(new Integer(2));
    comboBoxDefensa.addItem(new Integer(3));
    comboBoxDefensa.addItem(new Integer(4));
    comboBoxDefensa.addItem(new Integer(5));
    comboBoxDefensa.addItem(new Integer(6));
    comboBoxDefensa.addItem(new Integer(7));
    comboBoxDefensa.addItem(new Integer(8));
    comboBoxDefensa.addItem(new Integer(9));
    comboBoxDefensa.addItem(new Integer(10));
    comboBoxDefensa.addItem(new Integer(11));
    comboBoxDefensa.addItem(new Integer(12));
    comboBoxDefensa.addItem(new Integer(13));
    comboBoxDefensa.addItem(new Integer(14));
    comboBoxDefensa.addItem(new Integer(15));
    comboBoxDefensa.addItem(new Integer(16));
    comboBoxDefensa.addItem(new Integer(17));

    //componentes para el coste
    labelCoste.setText(" Coste: ");
    labelCoste.setFont(new java.awt.Font("Dialog", 0, 20));
    labelCoste.setForeground(Color.blue);
    comboBoxCoste.setBackground(colorFondo);
    comboBoxCoste.setFont(new java.awt.Font("Dialog", 1, 17));
    comboBoxCoste.setForeground(Color.white);
    comboBoxCoste.setMaximumSize(new Dimension(141, 30));
    comboBoxCoste.setMinimumSize(new Dimension(20, 21));
    comboBoxCoste.setPreferredSize(new Dimension(50, 21));
    comboBoxCoste.setMaximumRowCount(6);
    comboBoxCoste.addItem(new Integer(0));
    comboBoxCoste.addItem(new Integer(1));
    comboBoxCoste.addItem(new Integer(2));
    comboBoxCoste.addItem(new Integer(3));
    comboBoxCoste.addItem(new Integer(4));
    comboBoxCoste.addItem(new Integer(5));
    comboBoxCoste.addItem(new Integer(6));
    comboBoxCoste.addItem(new Integer(7));
    comboBoxCoste.addItem(new Integer(8));

    //componentes para la vida
    labelVida.setText(" Vida: ");
    labelVida.setFont(new java.awt.Font("Dialog", 0, 20));
    labelVida.setForeground(Color.blue);
    boton1Vida.setText("  1 Vida");
    boton1Vida.addActionListener(new EditorGUI_boton1Vida_actionAdapter(this));
    boton1Vida.setFont(new java.awt.Font("Dialog", 0, 13));
    boton1Vida.setForeground(Color.blue);
    boton1Vida.setSelected(true);
    boton2Vidas.setText("  2 Vidas");
    boton2Vidas.addActionListener(new EditorGUI_boton2Vidas_actionAdapter(this));
    boton2Vidas.setFont(new java.awt.Font("Dialog", 0, 13));
    boton2Vidas.setForeground(Color.blue);
    boton3Vidas.setText("  3 Vidas");
    boton3Vidas.addActionListener(new EditorGUI_boton3Vidas_actionAdapter(this));
    boton3Vidas.setFont(new java.awt.Font("Dialog", 0, 13));
    boton3Vidas.setForeground(Color.blue);

    //componentes para el comentatio para el movil
    labelComenMovil.setText("Comentario para el movil:");
    labelComenMovil.setFont(new java.awt.Font("Dialog", 0, 20));
    labelComenMovil.setForeground(Color.blue);
    textoComenMovil.setBackground(colorFondo);
    textoComenMovil.setFont(new java.awt.Font("Dialog", 1, 13));
    textoComenMovil.setForeground(Color.white);
    textoComenMovil.setText("");

    //componentes para el comentario de las habilidades extras
    labelComenHab.setText("Comentario de habilidades:");
    labelComenHab.setFont(new java.awt.Font("Dialog", 0, 20));
    labelComenHab.setForeground(Color.blue);
    textoComenHab.setBackground(colorFondo);
    textoComenHab.setFont(new java.awt.Font("Dialog", 1, 13));
    textoComenHab.setForeground(Color.white);
    textoComenHab.setText("");

    //componente para mostrar el nivel y los puntos de la carta
    botonMostrar.setText("Mostrar nivel y puntos");
    botonMostrar.setFont(new java.awt.Font("Dialog", 1, 15));
    botonMostrar.addActionListener(new EditorGUI_botonMostrar_actionAdapter(this));
    botonMostrar.setFocusable(false);

    //componente para a�adir la carta
    botonAnadir.setText("A�adir carta");
    botonAnadir.setFont(new java.awt.Font("Dialog", 1, 15));
    botonAnadir.addActionListener(new EditorGUI_botonAnadir_actionAdapter(this));
    botonAnadir.setFocusable(false);

    //componente para mostrar la imagen de la carta
    botonImagen.setText("Pinche aqui para ver la imagen");
    botonImagen.setFont(new java.awt.Font("Dialog", 1, 16));
    botonImagen.addActionListener(new EditorGUI_botonImagen_actionAdapter(this));
    botonImagen.setFocusable(false);


    //componentes contenedores de otros componentes
    jScrollPane2.getViewport().add(textoComenMovil, null);
    jScrollPane1.getViewport().add(textoComenHab, null);

    box1.add(labelNombre, null);
    box1.add(textoNombre, null);
    box2.add(labelRaza, null);
    box2.add(comboBoxRaza, null);
    box3.add(labelTipo, null);
    box3.add(comboBoxTipo, null);
    box4.add(labelAtaque, null);
    box4.add(comboBoxAtaque, null);
    box5.add(labelDefensa, null);
    box5.add(comboBoxDefensa, null);
    box6.add(labelCoste, null);
    box6.add(comboBoxCoste, null);
    box7.add(labelPuntos, null);
    box7.add(textoPuntos, null);
    box8.add(labelVida, null);
    box8.add(boton1Vida, null);
    box8.add(boton2Vidas, null);
    box8.add(boton3Vidas, null);
    box9.add(labelNivel, null);
    box9.add(textoNivel, null);
    box10.add(labelComenHab, null);
    box10.add(jScrollPane1, null);
    box11.add(labelComenMovil, null);
    box11.add(jScrollPane2, null);
    box12.add(labelCodigo, null);
    box12.add(textoCodigo, null);

    jSplitPane1.setOrientation(JSplitPane.HORIZONTAL_SPLIT);
    jSplitPane1.setBorder(null);
    jSplitPane1.setEnabled(false);
    jSplitPane1.setDividerSize(10);
    jSplitPane1.setDividerLocation(420);
    jSplitPane2.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane2.setBorder(null);
    jSplitPane2.setEnabled(false);
    jSplitPane2.setDividerSize(10);
    jSplitPane2.setDividerLocation(310);
    jSplitPane3.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane3.setBorder(null);
    jSplitPane3.setEnabled(false);
    jSplitPane3.setDividerLocation(140);
    jSplitPane4.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane4.setBorder(null);
    jSplitPane4.setEnabled(false);
    jSplitPane4.setDividerSize(10);
    jSplitPane4.setDividerLocation(65);
    jSplitPane5.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane5.setBorder(null);
    jSplitPane5.setEnabled(false);
    jSplitPane5.setDividerSize(5);
    jSplitPane5.setDividerLocation(75);
    jSplitPane6.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane6.setBorder(null);
    jSplitPane6.setEnabled(false);
    jSplitPane6.setDividerSize(5);
    jSplitPane6.setDividerLocation(35);
    jSplitPane7.setOrientation(JSplitPane.HORIZONTAL_SPLIT);
    jSplitPane7.setBorder(null);
    jSplitPane7.setEnabled(false);
    jSplitPane7.setDividerSize(5);
    jSplitPane7.setDividerLocation(220);
    jSplitPane8.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane8.setBorder(null);
    jSplitPane8.setEnabled(false);
    jSplitPane8.setDividerSize(5);
    jSplitPane8.setDividerLocation(75);
    jSplitPane9.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane9.setBorder(null);
    jSplitPane9.setEnabled(false);
    jSplitPane9.setDividerSize(5);
    jSplitPane9.setDividerLocation(35);
    jSplitPane10.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane10.setBorder(null);
    jSplitPane10.setEnabled(false);
    jSplitPane10.setDividerSize(5);
    jSplitPane10.setDividerLocation(35);
    jSplitPane11.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane11.setBorder(null);
    jSplitPane11.setEnabled(false);
    jSplitPane11.setDividerSize(5);
    jSplitPane11.setDividerLocation(115);
    jSplitPane12.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane12.setBorder(null);
    jSplitPane12.setEnabled(false);
    jSplitPane12.setDividerSize(5);
    jSplitPane12.setDividerLocation(30);
    jSplitPane13.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane13.setBorder(null);
    jSplitPane13.setEnabled(false);
    jSplitPane13.setDividerSize(10);
    jSplitPane13.setDividerLocation(450);
    jSplitPane14.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane14.setBorder(null);
    jSplitPane14.setEnabled(false);
    jSplitPane14.setDividerSize(10);
    jSplitPane14.setDividerLocation(45);

    jSplitPane1.add(jSplitPane2, JSplitPane.LEFT);
    jSplitPane1.add(jSplitPane12, JSplitPane.RIGHT);
    jSplitPane2.add(jSplitPane4, JSplitPane.TOP);
    jSplitPane2.add(jSplitPane3, JSplitPane.BOTTOM);
    jSplitPane3.add(box10, JSplitPane.TOP);
    jSplitPane3.add(box11, JSplitPane.BOTTOM);
    jSplitPane4.add(box1, JSplitPane.TOP);
    jSplitPane4.add(jSplitPane5, JSplitPane.BOTTOM);
    jSplitPane5.add(jSplitPane6, JSplitPane.TOP);
    jSplitPane5.add(jSplitPane7, JSplitPane.BOTTOM);
    jSplitPane6.add(box2, JSplitPane.TOP);
    jSplitPane6.add(box3, JSplitPane.BOTTOM);
    jSplitPane7.add(jSplitPane8, JSplitPane.LEFT);
    jSplitPane7.add(jSplitPane11, JSplitPane.RIGHT);
    jSplitPane8.add(jSplitPane9, JSplitPane.TOP);
    jSplitPane8.add(jSplitPane10, JSplitPane.BOTTOM);
    jSplitPane9.add(box4, JSplitPane.TOP);
    jSplitPane9.add(box5, JSplitPane.BOTTOM);
    jSplitPane10.add(box6, JSplitPane.TOP);
    jSplitPane10.add(box7, JSplitPane.BOTTOM);
    jSplitPane11.add(box8, JSplitPane.TOP);
    jSplitPane11.add(box9, JSplitPane.BOTTOM);
    jSplitPane12.add(jSplitPane13, JSplitPane.RIGHT);
    jSplitPane13.add(botonImagen, JSplitPane.TOP);
    jSplitPane13.add(jSplitPane14, JSplitPane.BOTTOM);
    jSplitPane12.add(box12, JSplitPane.LEFT);
    jSplitPane14.add(botonMostrar, JSplitPane.LEFT);
    jSplitPane14.add(botonAnadir, JSplitPane.RIGHT);

    contentPane.add(jSplitPane1, BorderLayout.CENTER);
  }

  /**
   * Funci�n que crea el menu de la pantalla del editor
   */
  private void crearMenu(){
    //menu desplegable Archivo
    jMenuFile.setText("Archivo");
    jMenuFileNuevo.setText("Nuevo");
    jMenuFileNuevo.addActionListener(new jMenuFileNuevo_ActionAdapter(this));
    jMenuFileCargar.setText("Cargar");
    jMenuFileCargar.addActionListener(new jMenuFileCargar_ActionAdapter(this));
    jMenuFileGuardar.setText("Guardar");
    jMenuFileGuardar.addActionListener(new jMenuFileGuardar_ActionAdapter(this));
    jMenuFileGuardarComo.setText("Guardar Como");
    jMenuFileGuardarComo.addActionListener(new jMenuFileGuardarComo_ActionAdapter(this));
    jMenuFileExit.setText("Salir");
    jMenuFileExit.addActionListener(new jMenuFileExit_ActionAdapter(this));
    jMenuFile.add(jMenuFileNuevo);
    jMenuFile.add(jMenuFileCargar);
    jMenuFile.addSeparator();
    jMenuFile.add(jMenuFileGuardar);
    jMenuFile.add(jMenuFileGuardarComo);
    jMenuFile.addSeparator();
    jMenuFile.add(jMenuFileExit);
    //menu desplegable Cartas
    jMenuCartas.setText("Cartas");
    jMenuCartasNueva.setText("Nueva Carta");
    jMenuCartasNueva.addActionListener(new jMenuCartasNueva_ActionAdapter(this));
    jMenuCartasCargar.setText("Cargar Carta");
    jMenuCartasCargar.addActionListener(new jMenuCartasCargar_ActionAdapter(this));
    jMenuCartasEliminar.setText("Eliminar Carta");
    jMenuCartasEliminar.addActionListener(new jMenuCartasEliminar_ActionAdapter(this));
    jMenuCartas.add(jMenuCartasNueva);
    jMenuCartas.add(jMenuCartasCargar);
    jMenuCartas.add(jMenuCartasEliminar);
    //menu desplegable Ayuda
    jMenuHelp.setText("Ayudas");
    jMenuHelpAyuda.setText("Ayuda");
    jMenuHelpAyuda.addActionListener(new jMenuHelpAyuda_ActionAdapter(this));
    jMenuHelpAbout.setText("Acerca de ..");
    jMenuHelpAbout.addActionListener(new jMenuHelpAbout_ActionAdapter(this));
    jMenuHelp.add(jMenuHelpAyuda);
    jMenuHelp.add(jMenuHelpAbout);
    //a�adimos al menu los menus desplegables
    jMenuBar1.add(jMenuFile);
    jMenuBar1.add(jMenuCartas);
    jMenuBar1.add(jMenuHelp);
    //a�adimos el menu a la pantalla
    this.setJMenuBar(jMenuBar1);
  }

  /**
   * Funci�n abstracta para controlar la pulsaci�n del boton jMenuFileNuevo
   * Realizar Archivo | Nuevo
   * @param e
   */
  abstract void jMenuFileNuevo_actionPerformed(ActionEvent e);

  /**
   * Funci�n abstracta para controlar la pulsaci�n del boton jMenuFileCargar
   * Realizar Archivo | Cargar
   * @param e
   */
  abstract void jMenuFileCargar_actionPerformed(ActionEvent e);

  /**
   * Funci�n abstracta para controlar la pulsaci�n del boton jMenuFileGuardar
   * Realizar Archivo | Guardar
   * @param e
   */
  abstract void jMenuFileGuardar_actionPerformed(ActionEvent e);

  /**
   * Funci�n abstracta para controlar la pulsaci�n del boton jMenuFileGuardarComo
   * Realizar Archivo | Guardar Como
   * @param e
   */
  abstract void jMenuFileGuardarComo_actionPerformed(ActionEvent e);

  /**
   * Funci�n abstracta para controlar la pulsaci�n del boton jMenuFileExit
   * Realizar Archivo | Salir
   * @param e
   */
  abstract void jMenuFileExit_actionPerformed(ActionEvent e);

  /**
   * Funci�n abstracta para controlar la pulsaci�n del boton jMenuCartasNueva
   * Realizar Cartas | Nueva Carta
   * @param e
   */
  abstract void jMenuCartasNueva_actionPerformed(ActionEvent e);

  /**
   * Funci�n abstracta para controlar la pulsaci�n del boton jMenuCartasCargar
   * Realizar Cartas | Cargar Carta
   * @param e
   */
  abstract void jMenuCartasCargar_actionPerformed(ActionEvent e);

  /**
   * Funci�n abstracta para controlar la pulsaci�n del boton jMenuCartasEliminar
   * Realizar Cartas | Eliminar Carta
   * @param e
   */
  abstract void jMenuCartasEliminar_actionPerformed(ActionEvent e);

  /**
   * Funci�n abstracta para controlar la pulsaci�n del boton jMenuHelpAyuda
   * Realizar Ayuda | Ayuda
   * @param e
   */
  abstract void jMenuHelpAyuda_actionPerformed(ActionEvent e);

  /**
   * Funci�n abstracta para controlar la pulsaci�n del boton jMenuHelpAbout
   * Realizar Ayuda | Acerca de ..
   * @param e
   */
  abstract void jMenuHelpAbout_actionPerformed(ActionEvent e);

  /**
   * Funci�n abstracta para controlar la pulsaci�n del boton1Vida
   * @param e
   */
  abstract void boton1Vida_actionPerformed(ActionEvent e);

  /**
   * Funci�n abstracta para controlar la pulsaci�n del boton2Vidas
   * @param e
   */
  abstract void boton2Vidas_actionPerformed(ActionEvent e);

  /**
   * Funci�n abstracta para controlar la pulsaci�n del boton3Vidas
   * @param e
   */
  abstract void boton3Vidas_actionPerformed(ActionEvent e);

  /**
   * Funci�n abstracta para controlar la pulsaci�n del comboBoxRaza
   * @param e
   */
  abstract void comboBoxRaza_actionPerformed(ActionEvent e);

  /**
   * Funci�n abstracta para controlar la pulsaci�n del comboBoxTipo
   * @param e
   */
  abstract void comboBoxTipo_actionPerformed(ActionEvent e);

  /**
   * Funci�n abstracta para controlar la pulsaci�n del botonImagen
   * @param e
   */
  abstract void botonImagen_actionPerformed(ActionEvent e);

  /**
   * Funci�n abstracta para controlar la pulsaci�n del botonMostrar
   * @param e
   */
  abstract void botonMostrar_actionPerformed(ActionEvent e);

  /**
   * Funci�n abstracta para controlar la pulsaci�n del botonAnadir
   * @param e
   */
  abstract void botonAnadir_actionPerformed(ActionEvent e);

  /**
   * Funci�n abstracta para poder salir cuando se cierra la ventana
   * @param e
   */
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      jMenuFileExit_actionPerformed(null);
    }
  }
}