package editor;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

/**
 * <p>T�tulo: Editor</p>
 * <p>Descripci�n: Editor de la base de datos de las cartas para G�nesis</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Empresa: </p>
 * @author Miguel Cayeiro Garc�a
 * @version 1.0
 */

class jMenuCartasModificar_ActionAdapter implements ActionListener {
  EditorGUI adaptee;

  jMenuCartasModificar_ActionAdapter(EditorGUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jMenuCartasModificar_actionPerformed(e);
  }
}