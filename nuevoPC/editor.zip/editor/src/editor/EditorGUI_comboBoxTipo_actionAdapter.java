package editor;

import java.awt.event.ActionEvent;

/**
 * <p>T�tulo: Editor</p>
 * <p>Descripci�n: Editor de la base de datos de las cartas para G�nesis</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Empresa: </p>
 * @author Miguel Cayeiro Garc�a
 * @version 2.0
 */

class EditorGUI_comboBoxTipo_actionAdapter implements java.awt.event.ActionListener {
  EditorGUI adaptee;

  EditorGUI_comboBoxTipo_actionAdapter(EditorGUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.comboBoxTipo_actionPerformed(e);
  }
}