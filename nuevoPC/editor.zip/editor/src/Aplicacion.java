
import java.awt.*;
import javax.swing.*;
import editor.*;

/**
 * <p>T�tulo: Editor</p>
 * <p>Descripci�n: Editor de la base de datos de las cartas para G�nesis</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Empresa: </p>
 * @author Miguel Cayeiro Garc�a
 * @version 2.0
 */

public class Aplicacion {
  public Aplicacion() {
    JFrame editor=new EditorImp();
    editor.pack();

    //Centrar la ventana
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = editor.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }
    editor.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
    editor.setVisible(true);

  }
  public static void main(String[] args) {
    try {
      UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
    }
    catch(Exception error) {
      error.printStackTrace();
    }
    Aplicacion aplicacion1 = new Aplicacion();
  }

}