


instalacion de las librerias de audio para Genesis (proyecto de IS)


nota: la carpeta jre se  refiere a la del jsdk 1.4.2
      (depende de la ruta donde halla sido intalada la maquina virtual, en el caso del laboratorio 
	3 est� en c:\Archivos de Programa\Java\j2re1.4.2_05\)	

* Copiar NativeFmod.dll, NativeFmodDyn.dll y fmod.dll en la carpeta jre/bin/

* Copiar NativeFmodApi_v3.00.jar en la carpeta  jre/lib/ext

* Copiar Fmod.dll en nuestra carpeta classes


nota: recordamos que ademas de copiar las librerias, hay que indicarle al netbeans o al creator la ruta de las librerias (Proyecto->Opciones->librerias->... etc�tera