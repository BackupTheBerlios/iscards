/*
 * ContextListener.java
 *
 * Created on 9 de diciembre de 2004, 23:27
 */
package usuarios;
import javax.servlet.*;
/**
 *
 * @author  Javi
 */
public final class ContextListener implements ServletContextListener {
    
    /** Creates a new instance of ContextListener */
   public void contextInitialized (ServletContextEvent servletContextEvent) {
        ServletContext servletContext = servletContextEvent.getServletContext ();
        try {
            UsuariosBD usuariosBD = new UsuariosBD ();
            servletContext.setAttribute ("BaseDatos", usuariosBD);
        }
        catch (Exception e) {
            servletContext.log ("No se pudo crear el atributo BaseDatos: " + e.getMessage ());
        }
    }

    public void contextDestroyed (ServletContextEvent servletContextEvent) {
        ServletContext servletContext = servletContextEvent.getServletContext ();
        UsuariosBD usuariosBD= (UsuariosBD) servletContext.getAttribute ("BaseDatos");
        usuariosBD.close ();
        servletContext.removeAttribute ("BaseDatos");
    }
    
}
