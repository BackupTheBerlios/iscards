/*
 * UsuariosBD.java
 *
 * Created on 8 de diciembre de 2004, 15:46
 */
package usuarios;

import java.sql.*;
import java.util.*;
import javax.sql.*;
import javax.naming.*;
/**
 *
 * @author  Javi
 */
public class UsuariosBD {
    Connection connection;
    private boolean connectionFree = true;
    private ArrayList usuarios;

    public UsuariosBD () throws Exception {
        try {
            InitialContext initialContext = new InitialContext ();
            Context envContext = (Context) initialContext.lookup ("java:comp/env");
            DataSource dataSource = (DataSource) envContext.lookup ("jdbc/genesis");
            this.connection = dataSource.getConnection ();
        }
        catch (Exception e) {
            throw new Exception ("No se pudo abrir la base de datos g�nesis: " + e.getMessage ());
        }
    }

    protected synchronized Connection getConnection () {
        while (this.connectionFree == false) {
            try {
                wait ();
            }
            catch (InterruptedException e) {
            }
        }
        this.connectionFree = false;
        notify ();
        return this.connection;
    }

    protected synchronized void releaseConnection () {
        while (this.connectionFree == true) {
            try {
                wait ();
            }
            catch (InterruptedException e) {
            }
        }
        this.connectionFree = true;
        notify ();
    }

    public Usuario getUsuario (String nick) {
        try {
            this.getConnection ();
            PreparedStatement preparedStatement = this.connection.prepareStatement ("SELECT nick, password,nombre," +
            "  email, sexo, puntos FROM usuarios WHERE nick = ?");
            preparedStatement.setString (1, nick);
            ResultSet resultSet = preparedStatement.executeQuery ();
            if (resultSet.next ()) {
                Usuario usuario = new Usuario (  
                    resultSet.getString (1), resultSet.getString (2), resultSet.getString(3), resultSet.getString(4), resultSet.getString(5), resultSet.getFloat(6) );
                preparedStatement.close ();
                this.releaseConnection ();
                return usuario;
            }
            else {
                preparedStatement.close ();
                this.releaseConnection ();
                return null;
            }
        }
        catch (SQLException e) {
            this.releaseConnection ();
            return null;
        }
    }

    public int insertarUsuario (Usuario usuario) {
        int rowsAffected = 0;
        try {
            this.getConnection ();
            PreparedStatement preparedStatement = this.connection.prepareStatement ("INSERT INTO usuarios (nick, password, nombre, email, sexo, puntos) VALUES (?, ?, ?, ?, ?, ?)");
            preparedStatement.setString (1, usuario.getNick());
            preparedStatement.setString (2, usuario.getPassword());
            preparedStatement.setString (3, usuario.getNombre());
            preparedStatement.setString (4, usuario.getEmail());
            preparedStatement.setString (5, usuario.getSexo());
            preparedStatement.setFloat (6, usuario.getPuntos());
            rowsAffected = preparedStatement.executeUpdate ();
            preparedStatement.close ();
            this.releaseConnection ();
        }
        catch (SQLException e) {
            this.releaseConnection ();
            return 0;
        }
        return rowsAffected;
    }

    public int borrarUsuario (String nick){
        int rowsAffected = 0;
        try {
            this.getConnection ();
            PreparedStatement preparedStatement = this.connection.prepareStatement ("DELETE FROM usuarios WHERE nick = ?");
            preparedStatement.setString (1, nick);
            rowsAffected = preparedStatement.executeUpdate ();
            preparedStatement.close ();
            this.releaseConnection ();
        }
        catch (SQLException e) {
            this.releaseConnection ();
            return 0;
        }
        return rowsAffected;
    }

    public int modificarUsuario (Usuario usuario) {
        int rowsAffected = 0;
        try {
            this.getConnection ();
            PreparedStatement preparedStatement = 
              this.connection.prepareStatement ("UPDATE usuarios SET nick=?, password=?, nombre=?, email=?, sexo=?, puntos=? WHERE nick =?");
            preparedStatement.setString (1, usuario.getNick());
            preparedStatement.setString (2, usuario.getPassword());
            preparedStatement.setString (3, usuario.getNombre());
            preparedStatement.setString (4, usuario.getEmail());
            preparedStatement.setString (5, usuario.getSexo());
            preparedStatement.setFloat (6, usuario.getPuntos());
            preparedStatement.setString (7, usuario.getNick());
            rowsAffected = preparedStatement.executeUpdate ();
            preparedStatement.close ();
            this.releaseConnection ();
        }
        catch (SQLException e) {
            this.releaseConnection ();
            return 0;
        }
        return rowsAffected;
    }

    public Collection getUsuarios () {
        usuarios = new ArrayList ();
        try {
            this.getConnection ();
            PreparedStatement preparedStatement = this.connection.prepareStatement ("SELECT nick, password, nombre, email, sexo, puntos FROM usuarios");
            ResultSet resultSet = preparedStatement.executeQuery ();
            while (resultSet.next ()) {
                Usuario usuario = new Usuario (  
                    resultSet.getString (1), resultSet.getString (2), resultSet.getString(3), resultSet.getString(4), resultSet.getString(5), resultSet.getFloat(6) );
                usuarios.add (usuario);
            }
            preparedStatement.close ();
        }
        catch (SQLException e) {
            return null;
        }
        this.releaseConnection ();

        return usuarios;
    }
    
    public Collection getRanking(){
        usuarios = new ArrayList();
        try {
            this.getConnection ();
            PreparedStatement preparedStatement = this.connection.prepareStatement ("SELECT nick, password, nombre, email, sexo, puntos FROM usuarios ORDER BY puntos DESC");
            ResultSet resultSet = preparedStatement.executeQuery ();
            while (resultSet.next ()) {
                Usuario usuario = new Usuario (  
                    resultSet.getString (1), resultSet.getString (2), resultSet.getString(3), resultSet.getString(4), resultSet.getString(5), resultSet.getFloat(6) );
                usuarios.add (usuario);
            }
            preparedStatement.close ();
        }
        catch (SQLException e) {
            return null;
        }
        this.releaseConnection ();
        return usuarios;

    }

    public void close () {
        try {
            this.connection.close ();
        }
        catch (SQLException e) {
            System.out.println (e.getMessage ());
        }
    }
    
}
