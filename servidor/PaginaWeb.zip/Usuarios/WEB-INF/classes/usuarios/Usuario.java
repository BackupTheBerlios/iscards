/*
 * Usuario.java
 *
 * Created on 8 de diciembre de 2004, 15:48
 */
package usuarios;

public class Usuario {
    private String nick;
    private String password;
    private String nombre;
    private String email;
    private String sexo;
    private String fechaAlta;
    private float puntos;
    
    public Usuario (String nick, String psw, String nombre, String mail, String sex)  {
        this.nick = nick;
        this.password = psw;
        this.nombre = nombre;
        this.email = mail;
        this.sexo = sex;
        this.puntos = 0;
    }

    public Usuario (String nick, String psw, String nombre, String mail, String sex, float puntos)  {
        this.nick = nick;
        this.password = psw;
        this.nombre = nombre;
        this.email = mail;
        this.sexo = sex;
        this.puntos = puntos;
    }

    
    public String getNick(){
        return this.nick;
    }
    
    public String getNombre () {
        return this.nombre;
    }

    public String getPassword () {
        return this.password;
    }

    public String getEmail(){
        return this.email;
    }
    
    public String getSexo(){
        return this.sexo;
    }
    
    public float getPuntos () {
        return this.puntos;
    }
    
    public String getFechaAlta(){
        return this.fechaAlta;
    }

}