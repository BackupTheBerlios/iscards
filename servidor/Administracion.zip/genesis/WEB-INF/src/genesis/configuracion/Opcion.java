package genesis.configuracion;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2005</p>
 * <p>Company: </p>
 * @author David B. Jenkins L�pez
 * @version 1.0
 */

public interface Opcion {
  String getNombre();
  String getDescripcion();
  boolean getCompuesta();
}